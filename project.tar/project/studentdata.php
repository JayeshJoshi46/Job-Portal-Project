<?php
	$rollno = $_POST['rno'];
	$first = $_POST['first_name'];
	$middle = $_POST['middle_name'];
	$last = $_POST['last_name'];
	$gender = $_POST['soperation'];
	$dob=$_POST["date_of_birth"];
	$email=$_POST["email"];
	$username = $_POST['user_name'];
	$password = $_POST['pass2'];
	$flag = 0;
	
	
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	echo "Connected To Database<br>";
	
	$qr="select * from studentreg";
	$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($first==$row[0] && $last==$row[2] )
			{
				echo "Record Already Exist<br>";				
				echo "<a href='StudentRegistration.html'>Back</a>";
				$flag++;
			}	
		}
	
		if($flag==0)
		{
			$q="insert into studentreg(rollno,fname,mname,lname,gender,dob,email,user_name,password) values('$rollno','$first','$middle','$last','$gender','$dob','$email','$username','$password')";
			$rs=pg_query($q) or die("Cannot execute query");
			//echo "Registration Done Successfull!!";
			echo "<script>alert('Registration Done Successfully!!')</script>";
			echo "<script> window.location.assign('Homepage.html'); </script>";
		}
		pg_close($db);
?>




