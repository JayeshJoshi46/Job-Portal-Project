<?php 
	
	session_start();
	$username = $_POST['username'];
	$password = $_POST['password'];
	$_SESSION['teacher_user']=$username; 
	$flag = 0;
	
	if (!isset($_SESSION['teacher_user']))
	{
	     echo "<script>alert('You should log in first'); document.location='TeacherLogin.html'</script>";
	}
			
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	
	
	$qr="select * from teacherreg";
	$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($username==$row[8] && $password==$row[9] )
			{
				echo "<script>alert('Succesfull Login')</script>";
				echo "<script> window.location.assign('teacherprofile.php'); </script>";
				//echo "<script type='text/javascript'>alert('Logged In successfully!')</script>";
				/*echo "<a href='StudentRegistration.html'>Back</a>";*/
				//header('Location: studentprofile.html');				
				$flag++;
			}	
		}
		if($flag==0)
		{
			$_SESSION['login_user']=null;
			echo "<script>alert('Login Not Succesfull')</script>";
			echo "<script> window.location.assign('Homepage.html'); </script>";
		}	
		pg_close($db);
		
?>
