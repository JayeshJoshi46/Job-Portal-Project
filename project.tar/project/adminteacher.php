<?php 
	echo "<body style='background: url(blue.jpg);'>";
	
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	//echo "Connected To Database<br>";
	
	$qr="select * from teacherreg";
	$rs=pg_query($qr) or die("Cannot execute query");
	echo "<center>";
	echo "<table border='2px'>";
	echo "<th colspan='9'bgcolor='#FFFF00'>Teacher Details</th>";
	echo "<tr bgcolor='#FFFF99'><th>TeacherId</th>";
	echo "<th bgcolor='#FFFF99'>First Name</th>";
	echo "<th bgcolor='#FFFF99'>Middle Name</th>";
	echo "<th bgcolor='#FFFF99'>Last Name</th>";
	echo "<th bgcolor='#FFFF99'>Gender</th>";
	echo "<th bgcolor='#FFFF99'>Date of Birth</th>";
	echo "<th bgcolor='#FFFF99'>Email</th>";
	echo "<th bgcolor='#FFFF99'>Username</th>";
	echo "<th bgcolor='#FFFF99'>Password</th></tr>";

	while($row=pg_fetch_row($rs))
	{
		echo "<tr bgcolor='#FFFF99'>";
		echo "<td>".$row[0]."</td>";
		echo "<td>".$row[1]."</td>";
		echo "<td>".$row[2]."</td>";
		echo "<td>".$row[3]."</td>";
		echo "<td>".$row[4]."</td>";
		echo "<td>".$row[5]."</td>";
		echo "<td>".$row[6]."</td>";
		echo "<td>".$row[7]."</td>";
		echo "<td>".$row[8]."</td>";
		echo "</tr>";
	}
	echo "</table></center>";
	pg_close($db);
?>
