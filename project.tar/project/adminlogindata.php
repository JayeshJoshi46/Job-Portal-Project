<?php 
	$username = $_POST['username'];
	$password = $_POST['password'];
	$flag = 0;
	
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	//echo "Connected To Database<br>";
	
	$qr="select * from admin";
	$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($username==$row[0] && $password==$row[1] )
			{
				echo "<script>alert('Succesfull Login')</script>";
				echo "<script> window.location.assign('admin.html'); </script>";
				//echo "<script type='text/javascript'>alert('Logged In successfully!')</script>";
				/*echo "<a href='StudentRegistration.html'>Back</a>";*/
				//header('Location: studentprofile.html');				
				$flag++;
			}	
		}
		if($flag==0)
		{
			echo "<script>alert('Login Not Succesfull')</script>";
			echo "<script> window.location.assign('Homepage.html'); </script>";
		}	
		pg_close($db);
?>
