/**/
function fname()
	{
		a = document.getElementById("first_name").value;
		
                if ( a == "") 
                {
                    	document.getElementById("first_name").style.border= "solid";
			document.getElementById("first_name").style.borderColor = "red";
                    	document.getElementById('ferror').innerHTML = "<br>Please enter your first name.";
                    	a.focus();
            		return false;
       	 	}
       	 	
       	 	else if( !(/^[A-Za-z]+$/.test(a)) )
		{
			document.getElementById("first_name").style.border= "solid";
			document.getElementById("first_name").style.borderColor = "red";
			document.getElementById('ferror').innerHTML = "<br>Please enter characters only.";
			a.focus();
			return false;			
		}
		
		else if(a.length>20)
		{
			document.getElementById("first_name").style.border= "solid";
			document.getElementById("first_name").style.borderColor = "red";
			document.getElementById('ferror').innerHTML = "<br>First name cannot be greater than 20 characters.";
			a.focus();
			return false;
		}
		
		else if((/^[A-Za-z]+$/.test(a)))
		{
			document.getElementById("first_name").style.border= "solid";
			document.getElementById("first_name").style.borderColor = "green";
			document.getElementById("ferror").innerHTML = "";
		
		}		
	}
	
	
/*Middle Name*/	
function mname()
	{
		a = document.getElementById("middle_name").value;
		
                if ( a == "") 
                {
                    	document.getElementById("middle_name").style.border= "solid";
			document.getElementById("middle_name").style.borderColor = "red";
                    	document.getElementById('merror').innerHTML = "<br>Please enter your first name.";
                    	a.focus();
            		return false;
       	 	}
       	 	
       	 	else if( !(/^[A-Za-z]+$/.test(a)) )
		{
			document.getElementById("middle_name").style.border= "solid";
			document.getElementById("middle_name").style.borderColor = "red";
			document.getElementById('merror').innerHTML = "<br>Please enter characters only.";
			a.focus();
			return false;			
		}
		
		else if(a.length>20)
		{
			document.getElementById("middle_name").style.border= "solid";
			document.getElementById("middle_name").style.borderColor = "red";
			document.getElementById('merror').innerHTML = "<br>First name cannot be greater than 20 characters.";
			a.focus();
			return false;
		}
		
		else if((/^[A-Za-z]+$/.test(a)))
		{
			document.getElementById("middle_name").style.border= "solid";
			document.getElementById("middle_name").style.borderColor = "green";
			document.getElementById("merror").innerHTML = "";
		
		}		
	}
	
/*Last Name*/	
function lname()
	{
		a = document.getElementById("last_name").value;
		
                if ( a == "") 
                {
                    	document.getElementById("last_name").style.border= "solid";
			document.getElementById("last_name").style.borderColor = "red";
                    	document.getElementById('lerror').innerHTML = "<br>Please enter your first name.";
                    	a.focus();
            		return false;
       	 	}
       	 	
       	 	else if( !(/^[A-Za-z]+$/.test(a)) )
		{
			document.getElementById("last_name").style.border= "solid";
			document.getElementById("last_name").style.borderColor = "red";
			document.getElementById('lerror').innerHTML = "<br>Please enter characters only.";
			a.focus();
			return false;			
		}
		
		else if(a.length>20)
		{
			document.getElementById("last_name").style.border= "solid";
			document.getElementById("last_name").style.borderColor = "red";
			document.getElementById('lerror').innerHTML = "<br>First name cannot be greater than 20 characters.";
			a.focus();
			return false;
		}
		
		else if((/^[A-Za-z]+$/.test(a)))
		{
			document.getElementById("last_name").style.border= "solid";
			document.getElementById("last_name").style.borderColor = "green";
			document.getElementById("lerror").innerHTML = "";
		}		
	}
	
/*Email*/	
function vemail()
	{

		d = document.getElementById("email").value;
		alpha = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
		
                if ( d == "") 
                {
                    	document.getElementById("email").style.border= "solid";
			document.getElementById("email").style.borderColor = "red";
                    	document.getElementById('eerror').innerHTML = "<br>Please enter your Email ID.";
            		return false;
       	 	}
       	 	
       	 	else if( !(alpha.test(d)) )
		{
			document.getElementById("email").style.border= "solid";
			document.getElementById("email").style.borderColor = "red";
			document.getElementById('eerror').innerHTML = "<br>Please enter a valid email id.";
			return false;			
		}
		
		else if( alpha.test(d) )
		{
			document.getElementById("email").style.border= "solid";
			document.getElementById("email").style.borderColor = "green";
			document.getElementById('eerror').innerHTML = "";
			return true;
		
		}
				
	}
	
/*UserName*/	
function uname()
	{
		u = document.getElementById("user_name").value;
		alpha = /^[a-zA-Z0-9._-]{3,}$/
		
                if ( u == "") 
                {
                    	document.getElementById("user_name").style.border= "solid";
			document.getElementById("user_name").style.borderColor = "red";
                    	document.getElementById('uerror').innerHTML = "<br>Please enter your user name.";
                    	u.focus();
            		return false;
       	 	}
		
		else if(u.length>20)
		{
			document.getElementById("user_name").style.border= "solid";
			document.getElementById("user_name").style.borderColor = "red";
			document.getElementById('uerror').innerHTML = "<br>User name cannot be greater than 20 characters.";
			u.focus();
			return false;
		}
		
		
		else if( alpha.test(u))
		{
			document.getElementById("user_name").style.border= "solid";
			document.getElementById("user_name").style.borderColor = "green";
			document.getElementById('eerror').innerHTML = "";
		
		}		
	}
	

function password()
	{
		 pass1 = document.getElementById('pass1').value;
    		 pass2 = document.getElementById('pass2').value;
    
    
		if(pass1 == pass2)
		{
			document.getElementById("pass1").style.border= "solid";
			document.getElementById("pass1").style.borderColor = "green";
			document.getElementById("pass2").style.border= "solid";
			document.getElementById("pass2").style.borderColor = "green";
			
			document.getElementById('pass').style.color="white";
			document.getElementById('pass').innerHTML = "<br>Passwords Match!"
		}
		
		else
		{
			document.getElementById("pass1").style.border= "solid";
			document.getElementById("pass1").style.borderColor = "red";
			document.getElementById("pass2").style.border= "solid";
			document.getElementById("pass2").style.borderColor = "red";
			document.getElementById('pass').style.color="red";
			document.getElementById('pass').innerHTML = "<br>Passwords don't Match!"
		}
    
	}  
	
