<?php
	session_start();
	$uploader = $_SESSION['login_user'];
	$noticeno = $_POST['noticeno'];
	$notice = $_POST['notice'];
	
	$flag = 0;
	
	
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	
	$qr="select * from notice";
	$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($noticeno==$row[0])
			{
				echo "<script>alert('Notice Already Exists')</script>";				
				echo "<script> window.location.assign('teacherprofile.php'); </script>";
				$flag++;
			}	
		}
	
		if($flag==0)
		{
			$q="insert into notice(noticeno,uploader,noticedetails) values('$noticeno','$uploader','$notice')";
			$rs=pg_query($q) or die("Cannot execute query");
			//echo "Registration Done Successfull!!";
			echo "<script>alert('Notice succesfully uploaded')</script>";
			//echo "<script> window.location.assign('Homepage.html'); </script>";
		}
		pg_close($db);
?>




