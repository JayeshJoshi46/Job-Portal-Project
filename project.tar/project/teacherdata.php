<?php
	$teacher_id = $_POST['teacher_id'];
	$teacher_subjects = $_POST['teaching_subjects'];
	$first = $_POST['first_name'];
	$middle = $_POST['middle_name'];
	$last = $_POST['last_name'];
	$gender = $_POST['toperation'];
	$dob=$_POST['dob'];
	$email=$_POST['email'];
	$username = $_POST['user_name'];
	$password = $_POST['pass2'];
	$flag = 0;
	
	
	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	echo "Connected To Database<br>";
	
	$qr="select * from teacherreg";
	$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($first==$row[0] && $last==$row[2] )
			{
				echo "Record Already Exist<br>";				
				echo "<a href='TeacherRegistration.html'>Back</a>";
				$flag++;
			}	
		}
	
		if($flag==0)
		{
			$q="insert into teacherreg(teacherid,fname,mname,lname,gender,subject,dob,email,user_name,password) values('$teacher_id','$first','$middle','$last','$gender','$teacher_subjects','$dob','$email','$username','$password')";
			$rs=pg_query($q) or die("Cannot execute query");
			//echo "Registration Done Successfull!!";
			echo "<script>alert('Registration Done Successfully!!')</script>";
			echo "<script> window.location.assign('TeacherLogin.html'); </script>";
		}
		pg_close($db);
?>




