<?php

	$fname=$_POST["first_name"];
	$mname=$_POST["middle_name"];
	$lname=$_POST["last_name"];
	$gender=$_POST["gender"];
	$tdate=$_POST["T_date"];
	$temail=$_POST["T_email"];
	$taddr=$_POST["T_address"];
	$tclgname=$_POST["T_college_name"];
	$tsubject=$_POST["subjects"];
	$texperience=$_POST["Texperience"];
	$tqualification=$_POST["Tqualification"];
	$tdocuments=$_POST["Tdocuments"];
	
	$db=pg_connect("host=localhost user=postgres dbname=project password=rahulcool port=5432") or die("Could not connect");
	
	
	$qr="select * from register";
		$rs=pg_query($qr) or die("Cannot execute query");
		
		while($row=pg_fetch_row($rs))
		{	
			if($fname==$row[1] && $lname==$row[3] && $tdate==$row[5] && $temail==$row[6])
			{
				echo "Record Already Exist";				
				echo "<a href='Register.html'>Back</a>";
				$flag++;
			}	
		}
	
		if($flag==0)
		{
		
		$q="insert into register(first_name,middle_name,last_name,gender,date_of_birth,email,address,college_name,subject,experience,qualification,documents) values('$fname','$mname','$lname','$gender','$tdate','$temail','$taddr','$tclgname','$tsubject','$texperience','$tqualification','$tdocuments')";
		
		$rs=pg_query($q) or die("Cannot execute query");
		echo "Registration Done Successfull!!";
		}
		pg_close($db);
?>
