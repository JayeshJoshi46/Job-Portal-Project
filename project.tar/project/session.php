<?php
	echo "Session established";
?>
