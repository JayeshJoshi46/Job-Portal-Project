<html>
<head>
<style>

body
{
	background-image: url(Teacher1.jpg);
}
table
{
	width: 70%;
	background-color:transparent;
	/*background-image: url(blue.jpg);*/
	border: 2px solid white;
	color: white;
}

th
{
	height: 30px;	
}


</style>
</head>
<body>
</body>
</html>
<?php 
	session_start();
	$u = $_SESSION['student_user'];
	

	$db = pg_connect ("host=localhost dbname=project port=5432 user=postgres password=friends@2004") or die("not connected");
	//echo "Connected To Database<br>";
	
	$qr="select * from notice";
	$rs=pg_query($qr) or die("Cannot execute query");
	echo "<center>";
	echo "<table border='2px'>";
	echo "<th colspan='9'>Notices Posted</th>";
	echo "<tr><th>Notice Uploader</th>";
	echo "<th>Notice Details</th>";

	while($row=pg_fetch_row($rs))
	{
		echo "<tr>";
		echo "<td>".$row[1]."</td>";
		echo "<td>".$row[2]."</td>";
		echo "</tr>";
	}
	echo "</table></center>";
	pg_close($db);
?>
