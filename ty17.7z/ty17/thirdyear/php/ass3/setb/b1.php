<?php
$val=$_POST['a'];
/*$rn=$_POST['Roll no'];
$name=$_POST['Name'];
$sys=$_POST['Syspro'];
$tcs=$_POST['TCS'];
$cn=$_POST['CN'];
$php=$_POST['PHP'];
$java=$_POST['JAVA'];
$ba=$_POST['BA'];*/

echo"<table border= 2 height=100 width=100>";
echo "<tr><td>Roll no</td>
<td>Name</td>
<td>Syspro</td>
<td>TCS</td>
<td>CN</td>
<td>PHP</td>
<td>JAVA</td>
<td>BA</td>
<td>PERCEN</td></tr>";

$fp1=fopen("student.dat","r");
$size=filesize("student.dat");

while($arr=fgetcsv($fp1))
{
$r=$arr[0];
$n=$arr[1];
$s=$arr[2];
$t=$arr[3];
$c=$arr[4];
$j=$arr[5];
$p=$arr[6];
$b=$arr[7];

$per=($s+$t+$c+$j+$p+$b)/6;



echo "<tr><td>" .$r."</td>
<td>".$n."</td>
<td>".$s."</td>
<td>".$t."</td>
<td>".$c."</td>
<td>".$p."</td>
<td>".$j."</td>
<td>".$b."</td>
<td>".$p."</td></tr>";



}
echo"</table>";
fclose($fp1);
?>
