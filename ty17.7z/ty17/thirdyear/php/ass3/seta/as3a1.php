

<?php
$f1=$_POST['a1'];
$f2=$_POST['a2'];

$fp1=fopen($f1,"r");
$fp2=fopen($f2,"a");
$size=filesize($f1);
	
	$data=fread($fp1,$size);
	fwrite($fp2,$data);
	echo "completed";
	
fclose($fp1);
fclose($fp2);
?>
