<?php
$dnm=$_POST['f1'];
$val=$_POST['a'];

$d=opendir($dnm);

echo "contents are:";
while(($s=readdir($d))!=false)
echo "".$s."<br>";

?>
