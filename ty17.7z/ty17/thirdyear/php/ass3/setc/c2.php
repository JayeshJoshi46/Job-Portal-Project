<?php

function dir1($dirnm)
{
  $result=array();
  $cdir=scandir($dirnm);
  foreach($cdir as $key=>$value)
  {
    if(!in_array($value,array(".","..")))
    {
      if(is_dir($dirnm.DIRECTORY_SEPARATOR.$value))
      {
        $result[$value]=dir1($dirnm.DIRECTORY_SEPARATOR.$value);
      }
      else
      {
        $result[]=$value;
      }
     }
   }
    return $result;
 }
$n=$_POST['dir'];
$a=dir1($n);
echo "The contents are:<br>";
print_r($a);
?>
