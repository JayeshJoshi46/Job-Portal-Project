<?php
session_start();
$_SESSION["tm"]=time();
?>

<html>
<body>
<form action="21.php" method="POST">
Name:
<input type="text" name="name"><br>
City:
<input type="text" name="city"><br>
Phone no:
<input type="text" name="phn"><br>
<input type="submit" value="submit">
</form>
</body>
</html>
