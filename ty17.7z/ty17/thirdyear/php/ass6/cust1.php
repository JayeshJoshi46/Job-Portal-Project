<html>
<body>
<form action="cust1.php" method="post">
<font color="green" size="6"><center><b><i>Customer Details</i></b>
</center></font>
<br>
<br>
<table align="center">
<tr>
<td>Name:</td><td><input type="text" name="nm"></td>
</tr>
<tr>
<td>Address:</td><td><input type="text" name="addr"></td>
<tr>
<td>Phone no:</td><td><input type="text" name="phn"></td>
</tr>
<tr>
<td><input type="reset" name="reset" value="reset"></td>
<td><input type="submit" name="submit" value="submit"></td>
</tr>
</table>
</form>
</body>
</html>
<?php

session_start();

	$name=$_POST['nm'];
	$address=$_POST['addr'];
	$phone=$_POST['phn'];

	$_SESSION['name']=$name;
	$_SESSION['addr']=$address;
	$_SESSION['phone']=$phone;

	session_write_close();
if(isset($_POST['submit']))
{
	header("location:http://192.168.16.1/ty17/thirdyear/php/ass6/cust2.php");
}
?>

