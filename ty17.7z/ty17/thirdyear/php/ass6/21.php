<?php
session_start();
$new=$_SESSION["tm"]+60;
if($new<time())
echo "Time up";
else
{
	echo "Name:".$_POST['name']."<br>";
 	echo "City:".$_POST['city']."<br>";
	echo "Phone no:".$_POST['phn']."<br>";
}
session_destroy();
?>
 
