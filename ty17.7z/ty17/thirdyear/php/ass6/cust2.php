<html>
<body>
<form action="cust2.php" method="post">
<font color="green" size="6"><center><b>Product Details</b></center>
</font>
<br><br>
<table align="center">
<tr>
<td>Product name:</td><td><input type="text" name="pn"></td>
</tr>
<tr>
<td>Quantity:</td><td><input type="text" name="qty"></td>
</tr>
<tr>
<td>Rate:</td><td><input type="text" name="rt"></td>
</tr>
<tr>
<td><input type="reset" name="reset" value="reset"></td>
<td><input type="submit"name="submit" value="submit"></td>
</tr>
</table>
</form>
</body>
</html>

<?php
session_start();


	$prod_nm=$_POST['pn'];
	$qty=$_POST['qty'];
	$rate=$_POST['rt'];
	
	$_SESSION['product']=$prod_nm;
	$_SESSION['quantity']=$qty;
	$_SESSION['rate']=$rate;
	session_write_close();
	if(isset($_POST['submit']))
	{
		header("location:http://192.168.16.1/ty17/thirdyear/php/ass6/cust3.php");
	}
?>
 
