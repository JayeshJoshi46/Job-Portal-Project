<?php
session_start();

echo "<center><font color=green size=6>	Final Bill </font></center><br><br>";
echo "<table align=center border=1>";
echo "<tr><th>Customer Name</th><th>Address</th><th>Phone</th><th>Product Name</th><th>Quantity</th><th>Rate</th></tr>";

	echo "<tr><td>".$_SESSION['name']."</td>";
	echo "<td>".$_SESSION['addr']."</td>";
	echo "<td>".$_SESSION['phone']."</td>";
	echo "<td>".$_SESSION['product']."</td>";
	echo "<td>".$_SESSION['quantity']."</td>";
	echo "<td>".$_SESSION['rate']."</td>";
	
	echo "</table><br><br>";
	echo "<center>Total Amount:".($_SESSION['quantity']*$_SESSION['rate'])."Rs</center>";
session_write_close();
?>
