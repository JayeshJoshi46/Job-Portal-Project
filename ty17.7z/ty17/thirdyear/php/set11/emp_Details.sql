create table emp_Details(eno int primary key,ename varchar(20),designation varchar(20),salary float);


insert into emp_Details values(1,'Mahesh','pune','50000');
insert into emp_Details values(2,'Scahin','wagholi','60000');
insert into emp_Details values(3,'Ram','nigdi','80000');
insert into emp_Details values(4,'Sham','pimpri','40000');
insert into emp_Details values(5,'Pratik','katraj','90000');

