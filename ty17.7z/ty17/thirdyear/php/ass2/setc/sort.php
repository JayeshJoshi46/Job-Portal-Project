<html>
<body>
<form action="sort.php" method="POST">
Menu<br>
<br><input type="radio" name="a" value="sortasc">Sort in Ascending Order by Changing Keys<br>
<br><input type="radio" name="a" value="sortdesc">Sort in Descending Order by Changing Keys<br>
<br><input type="radio" name="a" value="sort">Sort in Ascending Order without Changing Keys<br>
<br><input type="radio" name="a" value="sort1">Sort in Descending Order without Changing Keys<br>
<br><input type="radio" name="a" value="filter">Filter odd elements from array<br>
<br><input type="radio" name="a" value="sortdiff">Sort Different arrays<br>
<br><input type="radio" name="a" value="merge">Merge arrays<br>
<br><input type="radio" name="a" value="union">Find union of arrays<br>
<br><input type="radio" name="a" value="intersection">Find intersection of arrays<br>
<br><input type="radio" name="a" value="set">Find set difference of arrays<br>
<br><input type="submit" value="Submit"><br>
</form>
</body>
</html>



<?php
	$a=array("a"=>1,"m"=>19,"e"=>36,"d"=>14);
	$b=array("a"=>1,"e"=>3,"x"=>7,"y"=>9);
	if($_POST['a']== "sortasc")
	{
		print_r($a);
		sort($a);
		echo"<br>Array after sorting<br>";
		print_r($a);
	}
	if($_POST['a']== "sortdesc")
	{
		print_r($a);
		rsort($a);
		echo"<br>Array after sorting<br>";
		print_r($a);
	}
	if($_POST['a']== "sort")
	{
		print_r($a);
		asort($a);
		echo"<br>Array after sorting<br>";
		print_r($a);
	}
	if($_POST['a']== "sort1")
	{
		print_r($a);
		arsort($a);
		echo"<br>Array after sorting<br>";
		print_r($a);
	}
	if($_POST['a']== "filter")
	{
		function is_odd($var)
		{
			if(($var%2)!=0)
			return $var;
		}
		print_r($a);
		ksort($a);
		echo"<br>Array after filtering<br>";
		$odd=array_filter($a,"is_odd");
		print_r($odd);
	}
	if($_POST['a']== "sortdiff")
	{
		print_r($a);
		echo"<br>";
		print_r($b);
		array_multisort($a,$b);
		echo"<br>Array after sorting<br>";
		print_r($a);
		echo"<br>";
		print_r($b);
	}
	if($_POST['a']== "merge")
	{
		print_r($a);
		echo"<br>";
		print_r($b);
		$c=array_merge($a,$b);
		echo"<br>Array after merging";
		echo"<br>";
		print_r($c);
	}
	if($_POST['a']== "union")
	{
		print_r($a);
		echo"<br>";
		print_r($b);
		$c=array_merge($a,$b);
		$c=array_unique($c);
		echo"<br>Array after union";
		echo"<br>";
		print_r($c);
	}
	if($_POST['a']== "intersection")
	{
		print_r($a);
		echo"<br>";
		print_r($b);
		$c=array_intersect($a,$b);
		echo"<br>Array after intersection";
		echo"<br>";
		print_r($c);
	}
	if($_POST['a']== "set")
	{
		print_r($a);
		echo"<br>";
		print_r($b);
		$c=array_merge($a,$b);
		echo"<br>Set Difference";
		echo"<br>";
		print_r(array_diff($a,$b));
	}
?>

