<?php
$a=array(array(10,20,30),array("a","b","c"));
$b=$_POST['n1'];
$c=$_POST['n2'];
$d=$_POST['n3'];
$e=$_POST['n4'];
echo"Elements in multidimensional array are:"."<br>";
print_r($a);
print_r($a[$b][$c]);
echo"<br>";
unset($a[$d][$e]);
//print_r($a);
echo"<br>";
echo "elements after deleting:";
print_r($a);
?>
