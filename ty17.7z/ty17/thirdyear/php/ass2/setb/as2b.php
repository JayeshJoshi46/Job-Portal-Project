<?php
$a=array(10,20,30,40,50);
if(in_array($_POST['s1'],$a))
echo "key is:".array_search($_POST['s1'],$a);
else
echo "Required element is not present";
?>
