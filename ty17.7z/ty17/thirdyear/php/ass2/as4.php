<?php
$a=array("a"=>10,"b"=>20,"c"=>30,"d"=>40);
if($_POST['r1']=="key")
print_r($a);
if($_POST['r1']=="size")
echo"Size of the array is".count($a);
if($_POST['r1']=="delete")
{
 echo"Element before deleting:"."<br>";
 print_r($a);
 echo"<br>";
 unset($a[b]);
 echo"Elements after deleting:"."<br>";
 print_r($a);
}
if($_POST['r1']=="reverse")
{
 $r=array_flip($a);
 print_r($r);
}
if($_POST['r1']=="random")
{
 shuffle($a);
 print_r($a);
}
?>

