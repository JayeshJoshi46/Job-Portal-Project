<?php
$a=array("a"=>1,"b"=>2,"c"=>3,"d"=>4);
if($_POST['r1']== "key")
  print_r($a);
else if($_POST['r1']=="size")
  echo"the size of an array is:".count($a);
else if($_POST['r1']=="delete")
  { 
   print_r($a);
   echo"<br>";
   $b=$_POST['s1'];
   unset($a[$b]);
   echo "elements after deleting are:";
   print_r($a);
  }
else if($_POST['r1']=="reverse")
{
$a1=array_reverse($a);
echo "reverse elements are";
print_r($a1);
}
else if($_POST['r1']=="random")
{
shuffle($a);
echo "shuffeld elements are:";
print_r($a);
}
?>
