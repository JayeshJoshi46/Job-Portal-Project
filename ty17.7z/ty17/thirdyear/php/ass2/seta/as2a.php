<?php
$s=$_POST['s1'];
$n=strlen($s);
$a=array();
for($i=0;$i<$n;$i++)
array_push($a,$s[$i]);
for($i=0;$i<$n;$i++)
{
 if($s[$i]!=array_pop($a))
 {
  echo "Entered string is not palindrome";
  return;
 }
}
echo "Entered string is palindrome";
?>
