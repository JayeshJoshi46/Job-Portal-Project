<?php
	//Create a DOMdocument object and set nice formatting
	$doc=new DOMDocument("1.0","UTF-8");
	$doc->formatOutput=true;
	
	//Create root "CD" Store
	$cdstore=$doc->createElement("CD_Store");
	$doc->appendChild($cdstore);
	
	//Create the first element( Movie)
	$mv=$doc->createElement("Movie");
	$cdstore->appendChild($mv);
	//Create title name 
	$title=$doc->createElement("Title","Mr.India");
	$mv->appendChild($title);
	//create release year
	$year=$doc->createElement("Release_year","1987");
	$mv->appendChild($year);

	$mv=$doc->createElement("Movie");
	$cdstore->appendChild($mv);
	//Create title name 
	$title=$doc->createElement("Title","Holiday");
	$mv->appendChild($title);
	//create release year
	$year=$doc->createElement("Release_year","2014");
	$mv->appendChild($year);

	$mv=$doc->createElement("Movie");
	$cdstore->appendChild($mv);
	//Create title name 
	$title=$doc->createElement("Title","LOC");
	$mv->appendChild($title);
	//create release year
	$year=$doc->createElement("Release_year","2003");
	$mv->appendChild($year);

	//Create a file c1.xml and the xml documnet will be stored in the created XML document will be stored in that file 
	$doc->save("movie.xml");
	echo "<h4>movie.xml created</h4>";
?>
