<?php

	header('Content-type:text/xml');
	$str='<?xml version="1.0"?>'."\n";
	$str.="<Course>\n";
	$ComputerScience=array(array('StudentName'=>'Abc','ClassName'=>'TYBsc','percentage'=>'72.0'),array('StudentName'=>'Abcfgf','ClassName'=>'TYBsc','percentage'=>'82.0'),array('StudentName'=>'pooja','ClassName'=>'TYBsc','percentage'=>'52.0'),array('StudentName'=>'anita','ClassName'=>'TYBsc','percentage'=>'78.0'),array('StudentName'=>'viraj','ClassName'=>'TYBsc','percentage'=>'92.0'));

	foreach($ComputerScience as $cs)
	{
		$str.="<ComputerScience>\n";
		foreach($cs as $tag=>$data)
		{
			$str.= "<$tag>".htmlspecialchars($data)."</$tag>\n";
		}
		$str.= "</ComputerScience>\n";
	}
		$str.= "</Course>\n";
	$fp=fopen("course.xml","w");
	fwrite($fp,$str);
?>

