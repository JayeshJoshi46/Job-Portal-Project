<?php
	//create the root "cricketteam" element 
	$cricketTeam=new SimpleXMLElement("<CricketTeam/>");
	$country=$cricketTeam->addChild("Country");
	 $country->addAttribute("name","India");
	 $country->addChild("PlayerName","M Dhoni");
	 $country->addChild("Wickets","36");
	$country->addChild("Runs","10000");
	
	$country=$cricketTeam->addChild("Country");	
	$country->addAttribute("name","England");
         $country->addChild("PlayerName","Alastair");
         $country->addChild("Wickets","2");
        $country->addChild("Runs","9500");
	
//save the created XML document into cricket.xml file

$cricketTeam->asXML("cricket.xml");
echo "<h4>cricket.xml created</h4>";
?>

