<html>
<body>
<form action="as2.php" method="POST">
Menu<br>
<input type="radio" name="r1" value="master">Build Master Table<br> 
<input type="radio" name="r1" value="sort">Sort employee entries<br> 
<input type="radio" name="r1" value="search">Search employee record<br> 
Enter the code:
<input type="text" name="n1"><br>
<input type="radio"name="r1" value="dis_sal">Display salary<br><br>
<input type="submit" value="submit">
<input type="reset" value="reset">
</form>
</body>
</html>

<?php
 
class employee
{
 public $code, $n, $des;
 function employee($code,$n,$des)
 {
   $this->code=$code;
   $this->n=$n;
   $this->des=$des;
  }
}

class emp_account extends employee
{
 public $acc, $join;
 function emp_account($code,$n,$des,$acc,$join)
 {
  parent::employee($code,$n,$des);
  $this->acc=$acc;
  $this->join=$join;
  }
}

class emp_sal extends emp_account
{
 public $b, $e, $ded;
 function emp_sal($code,$n,$des,$acc,$join,$b,$e,$ded)
 {
  parent::emp_account($code,$n,$des,$acc,$join);
  $this->b=$b;
  $this->e=$e;
  $this->ded=$ded;
  //echo $code." ".$n." ".$des." ".$acc." ".$join." ".$b." ".$e." ".$ded;
 }
}

function display($em)
{
 echo "<table border=1>";
echo "<tr><th>code</th><th>Name</th><th>Designation</th><th>Account_no</th><th>Joining_date</th><th>Basic_pay</th><th>Earnings</th><th>Decduction</th></tr>";
for($i=0;$i<count($em);$i++)
 {
  echo "<tr>";
  echo "<td>".$em[$i]->code."</td><td>".$em[$i]->n."</td><td>".$em[$i]->des."</td><td>".$em[$i]->acc."</
td><td>".$em[$i]->join."</td><td>".$em[$i]->b."</td><td>".$em[$i]->ded."</td><td>".$em[$i]->e."</td>";
  echo "</tr>";
 }
 echo "</table>";
}
 

function sort_emp($em)
{
 $temp=new emp_sal();
 for($i=0;$i<count($em);$i++)
 {
  for($j=0;$j<count($em);$j++)
  {
   if($em[$i]->code < $em[$i]->code)
   {
    $temp=$em[$i]->code;
    $em[$i]->code=$em[$j]->code;
    $em[$i]->code=$temp;

    $temp=$em[$i]->n;
    $em[$i]->n=$em[$j]->n;
    $em[$i]->n=$temp;

    $temp=$em[$i]->des;
    $em[$i]->des=$em[$j]->des;
    $em[$i]->des=$temp;

    $temp=$em[$i]->acc;
    $em[$i]->acc=$em[$j]->acc;
    $em[$i]->acc=$temp;

    $temp=$em[$i]->join;
    $em[$i]->join=$em[$j]->join;
    $em[$i]->join=$temp;

    $temp=$em[$i]->b;
    $em[$i]->b=$em[$j]->b;
    $em[$i]->b=$temp;

    $temp=$em[$i]->e;
    $em[$i]->e=$em[$j]->e;
    $em[$i]->e=$temp;

    $temp=$em[$i]->ded;
    $em[$i]->ded=$em[$j]->ded;
    $em[$i]->ded=$temp;

    }
  }
 }
 display($em);
 }

function searchemp($em,$t)
{
 $flag=0;
 for($i=0;$i<count($em);$i++)
 {
  if($em[$i]->code==$t)
  {
   echo "Record found <br>";
   $flag=1;
   echo $em[$i]->code." ".$em[$i]->n." ".$em[$i]->des." ".$em[$i]->acc." ".$em[$i]->join." ". $em[$i]->b." ".$em[$i]->e." ".$em[$i]->ded;
   break;
  }
 }
 if($flag==0)
 echo "Record not found";
 }

function dis_sal($em)
{
 $temp;
 echo "Name Salary <br>";
 for($i=0;$i<count($em);$i++)
 {
  $temp= ($em[$i]->b+$em[$i]->e)-$em[$i]->ded;
  echo $em[$i]->n." ".$temp."<br>";
 } 
}

$e[0]=new emp_sal(1,"puja","msc",11,"21/1/2012",5000,250,100);
$e[1]=new emp_sal(2,"shweta","BE",22,"24/1/2013",6000,150,100);
$e[2]=new emp_sal(3,"akansha","MSC",33,"23/1/2014",7000,300,100);
$e[3]=new emp_sal(4,"vaibhavi","BSC",44,"25/1/2015",8000,450,100);

if($_POST['r1']=="master")
display($e);

if($_POST['r1']=="sort")
{
 sort_emp($e);
 display($e);
}

if($_POST['r1']=="search")
{
 $k=$_POST['n1'];
 searchemp($e,$k);
}

if($_POST['r1']=="dis_sal")
dis_sal($e);
?>
