<?php
define ("PI","3.14");
interface calculate
{
 function area();
 function volume();
}

class cylinder implements calculate
{
 private $r;
 private $h;
 function cylinder($r,$h)
 {
  $this->r=$r;
  $this->h=$h;
 }
 
 function area()
 {
  $ar=(2*PI*$this->r*$this->r)+(2*PI*$this->r*$this->h);
  echo"Area of cylinder=$ar<br>";
 }

 function volume()
 {
  $v=2*PI*$this->r*$this->h;
  echo"Volume of cylinder=$v<br>";
 }
}
 $radius=$_POST['n1'];
 $height=$_POST['n2'];
 $obj=new cylinder($radius,$height);
 $obj->area();
 $obj->volume();

?>
