/*<html>
<body>
<form method="POST" action="2C.php">
<br>Select Options:<br>
<input type="radio" name="a" value="details">Details of cricket player<br>
<input type="radio" name="a" value="disp_avg">Display average <br>
Enter the code of player<input type="text" name="name1"><br>
<input type="radio" name="a" value="avg_player">Average runs of all players<br>
<input type="radio" name="a" value="avg_player">Display list of players in sorted order<br>
<input type="submit" value="Submit">
<input type="reset" value="Reset">
</body>
</html>*/


<?php

class Cricket_player
{
  var $code,$name,$runs,$innings_played,$not_out,$avg;
  
	function Cricket_player()
	{
	}
   function Cricket_player($code,$name,$runs,$innings,$not_out)
   {
   $this->code=$code;
   $this->name=$name;
   $this->runs=$runs;
   $this->innings_played=$innings;
   $this->not_out=$not_out;
  }

   

	/*function display($c)
	{
		echo"<table border=1>";
		for($i=0;$i<count($c);$i++)
		{
			echo"<tr>";
			echo"<td>".$c[$i]->$code."</td>";
			echo"<td>".$c[$i]->$name."</td>";
			echo"<td>".$c[$i]->$runs."</td>";
			echo"<td>".$c[$i]->$innings_played."</td>";
			echo"<td>".$c[$i]->$not_out."</td>";
		}
	}*/


		/*function sort_cricket($c)
		{
			for($i=count($c)-1;$i>0;$i--)
			{
				for($j=0;$j<$i;$j++)
				{
					if($c[$j]->runs>$c[$j+1]->runs)
					{
						$temp=$c[$j]->code;
						$c[$j]->code=$c[j+1]->code;
						$c[$j+1]->code=$temp;
			

						$temp=$c[$j]->name;
						$c[$j]->name=$c[j+1]->name;
						$c[$j+1]->name=$temp;


						$temp=$c[$j]->runs;
						$c[$j]->runs=$c[j+1]->runs;
						$c[$j+1]->runs=$temp;
	
					
						$temp=$c[$j]->not_out;
						$c[$j]->not_out=$c[j+1]->not_out;
						$c[$j+1]->not_out=$temp;

						
						$temp=$c[$j]->innings_played;
						$c[$j]->innings_played=$c[j+1]->innings_played;
						$c[$j+1]->innings_played=$temp
*/





   function details($code,$name,$runs,$innings,$not_out)
   {
   $this->code=$code;
   $this->name=$name;
   $this->runs=$runs;
   $this->innings_played=$innings;
   $this->not_out=$not_out;
   
   if($this->innings_played <= 0) 
    echo "INVALID NO OF INNINGS";
  }
  
  function average()
   {
    $avg=($this->runs)/($this->innings_played);
    echo "<br>Average for player  ".$this->name." : ".$avg."<br>";;
   }
  


   function display()
    {
       echo "<br> Player code: ".$this->player_code." Name : ".$this->name." Runs : ".$this->runs." NO of innings played : ".$this->innings_played." NO of times not out : ".$this->not_out;
    }


 }

$name=$_POST['name'];
$p_name=explode(",",$name);


$code=$_POST['code'];
$p_code=explode(",",$code);

$runs=$_POST['runs'];
$p_runs=explode(",",$runs);

$innings=$_POST['noi'];
$p_innings=explode(",",$innings);

$notout=$_POST['noo'];
$p_notout=explode(",",$notout);


$c=array();

$C=new Cricket_player();
switch($value)
 {
  case 'E':
            for($i=0;$i<2;$i++)
            $c[$i]->details($p_code[$i],$p_name[$i],$p_runs[$i],$p_innings[$i],$p_notout[$i]);
            
            echo "<br>the details are:";
             for($i=0;$i<2;$i++)
               $c[$i]->display();
            break;
    
  case 'As': 
             $player=$_POST['name'];
             for($i=0;$i<count($c);$i++)
              {
               if(($c[$i]->code)===$player)
                {
                 $j=$i;
                }
              }  
              
             $c[$j]->average();          
               break;
               
  case 'A':
     echo "<br>Average";
     for($i=0;$i<2;$i++)
     {
      echo "<br>Player[".$i."]";
      $avg=($c[$i]->runs)/($c[$i]->innings_played);
       echo "<br>".$avg;
      }
       break;
            
  case 'S': echo "---------------";
    break;

 }
?>
