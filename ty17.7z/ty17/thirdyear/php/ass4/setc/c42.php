<html>
  <body>
    <form action="c42.php" method="POST">
       <input type="radio" name="r1" value="accept">Accept Records<br>
       Enter Player Code:=<input type="text" name="n1"><br>
       Enter Player Name:=<input type="text" name="n2"><br>
       Enter Runs:=<input type="text" name="n3"><br>
       Enter innings_played:=<input type="text" name="n4"><br>
       Enter no of times played not out<input type="text" name="n5"><br>
       <input type="radio" name="r1" value="sort">Sort Entries<br>        
       <input type="radio" name="r1" value="search">Display avg run of single player<br>
       Enter Player code=<input type="text" name="n6"><br>
       <input type="radio" name="r1" value="disp">Display Average Runs of all players<br>
       <input type="submit" name="s1" value="OK"> 
       <input type="reset" name="res" value="Reset">
    </form>
  </body>
</html>


<?php

  class Cricket_Player
  {
    public $player_code;
    public $player_name;
    public $runs;
    public $innigs_played;
    public $no_of_times_out;

    function Cricket_Player($pc,$n,$r,$ip,$no)
    {
       $this->player_code=$pc;
       $this->player_name=$n;
       $this->runs=$r;
       $this->innings_played=$ip;
       $this->no_of_times_out=$no;
    }
  }//employee

  function display($cp)
  {
     echo"<table border=1>";
     for($i=0;$i<count($cp);$i++)
     {
       echo"<tr>";
       echo"<td>".$cp[$i]->player_code."</td>";
       echo"<td>".$cp[$i]->player_name."</td>";
       echo"<td>".$cp[$i]->runs."</td>";
       echo"<td>".$cp[$i]->innings_played."</td>";
       echo"<td>".$cp[$i]->no_of_times_out."</td>";
       echo"</tr>";
     }
     echo"</table>";
  }//display

  function sortRecord($cp)
  {
     display($cp);
     echo"<br>";
     for($i=0;$i<count($cp);$i++)
     {
        for($j=0;$j<count($cp);$j++)
        {
           $temp=new Cricket_Player;
           if($cp[$i]->runs<$cp[$j]->runs)
           {
              $temp=$cp[$i];
              $cp[$i]=$cp[$j];
              $cp[$j]=$temp;
           }
        }
     }
     echo"<br><br>";
     display($cp);
  }//sortRecord

  function avg_runs($cp)
  {
     for($i=0;$i<count($cp);$i++)
     {
	$n=$cp[$i]->no_of_innings-$cp[$i]->no_of_times_out;
	$avg=($cp[$i]->runs/$cp[$i]->no_of_innigs)-$n;
	echo $cp[$i]->player_name." average=$avg<br>";
     }
	
  }//avg_run

  function avg_run($cp,$i)
  {
        $n=$cp[$i]->no_of_innings-$cp[$i]->no_of_times_out;
        $avg=($cp[$i]->runs/$cp[$i]->no_of_innigs)-$n;
        echo $cp[$i]->player_name." average=$avg<br>";    
  }//avg_run


  $c[0]=new Cricket_Player(1,"Scahin",1123,100,50);
  $c[1]=new Cricket_Player(2,"Kohali",1456,120,20);
  $c[2]=new Cricket_Player(3,"Dhoni",1789,170,40);
  $c[3]=new Cricket_Player(4,"R Ashw in",1321,160,20);

  
    switch($_POST['r1'])
    {
      case 'accept':
          display($c);
        break;
      case 'sort':
        sortRecord($c);
        break;
      case 'search':
        avg_run($c,$_POST['n6']);
        break;
      case 'disp':
        avg_runs($c);
        break;
    }//switch
 // }//if
?>
