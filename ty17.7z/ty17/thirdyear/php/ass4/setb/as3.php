<?php
define("pi",3.14);

interface calculate
{
 function area();
} 

class Rectangle implements calculate
{
 public $l,$b;
 function Rectangle($l,$b)
 {
  $this->l=$l;
  $this->b=$b;
 }
 
 function area()
 {
  return l*b;
 }

}

class Square extends Rectangle 
{
 public $a;
 function Square($l,$b,$a)
 {
  parent::Square($l,$b)
  {
   $this->a=$a;
  }
 }

 function area()
 {
  return a*a;
 }
 }

class Circle extends Rectangle
{
 public $r;
 function Circle($l,$b,$a,$r)
 {
  parent::Circle($l,$b,$a)
  {
   $this->r=$r;
  }
 }
 
 function area()
 {
  return pi*r*r;
 }
}
 
 
}

class Circle extends Rectangle
{
 public $r;
}

