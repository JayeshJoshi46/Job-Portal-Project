<?php

define('PI','3.14');

interface Shape
{
function area();
}
class Reactangle implements Shape
{
var $l,$b;

function reactangle($l,$b)
{
$this->l=$l;
$this->b=$b;
}
function area()
{
$ar=($this->l)*($this->b);
echo "Area of reactangle is: ".$ar."<br>";
} 
}

class Square extends Reactangle
{
var $side;

function Square($l,$b,$side)
{
parent::Reactangle($l,$b);
$this->side=$side;
}
function area()
{
parent::area();
$as=($this->side)*($this->side);
echo "Area of square is: ".$as."<br>";
}
}

class Circle implements Shape
{
var $radius;

function Circle($radius)
{
$this->radius=$radius;
}
function area()
{
$ac=PI*($this->radius)*($this->radius);
echo "area of circle is: ".$ac."<br>";
}
}
$l=$_POST['r1'];
$b=$_POST['r2'];
$s=$_POST['s'];
$r=$_POST['c'];
$obj1=new Square($l,$b,$s);
$obj1->area();

$obj2=new Circle($r);
$obj2->area();

?>
