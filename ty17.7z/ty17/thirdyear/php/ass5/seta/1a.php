<html>
<body>
<form action="1a.php" method="post">
eno<input type="text" name=eno><br>
ename<input type="text" name=ename><br>
address<input type="text" name=add><br>
phone<input type="text" name=phone><br>
salary<input type="text" name=sal><br>
emp_dno<input type="text" name=edno><br>
Enter the department details:<br>
dept_no<input type="text" name=dno><br>
dname<input type="text" name=dname><br>
loc<input type="text" name=loc><br>
<input type="submit" value="submit"><br>
</form>
</body>
</html>

<?php
$eno=$_POST['eno'];
$ename=$_POST['ename'];
$add=$_POST['add'];
$phone=$_POST['phone'];
$sal=$_POST['sal'];
$dno=$_POST['dno'];
$dname=$_POST['dname'];
$loc=$_POST['loc'];
$edno=$_POST['edno'];

$con=pg_connect("host=192.168.16.1 dbname=ty17 user=ty17") or die("Could not connect");
$ins1="insert into dept values(".$dno.",'".$dname."','".$loc."');";
echo $ins1;

$ins2="insert into emp values(".$eno.",'".$ename."','".$add."','".$phone."',".$sal.",".$edno.");";
echo $ins2;

pg_query($ins1);
pg_query($ins2);
pg_close($con);
?>

<html>
<body>
<form action="1.php" method="post">
<button onclick="goBack()">Go back</button>
<script>
function goBack()
{
  window.history.back();
}
</script>
</form>
</body>
</html>
