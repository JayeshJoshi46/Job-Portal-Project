<html>
<body>
<form action="s1.php" method="post">
Enter the compition name<input type="text" name="name1"><br>

<input type="submit" value="submit">
<input type="reset" name="reset"><br>


</form>
</body>
</html>

<?php
$hostname=$_POST['name1'];
$con=pg_connect("host=192.168.16.1 dbname=ty17 user=ty17") or die("Could not connect");
$q1="select * from student where sno in(select sno from stud_comp where rank=1 and cno in(Select cno from compition where cname='".$hostname."'));";

$rs=pg_query($q1);
echo "<table border=1>";
while($row=pg_fetch_row($rs))
{
  echo "<tr>";
  echo "<td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td>";
  echo "</tr>";
}
echo "</table>";
pg_close($con);
?>

