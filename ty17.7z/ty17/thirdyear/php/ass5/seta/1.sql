drop table emp;
drop table dept;


create table dept(dno int PRIMARY KEY,dname varchar(30),location varchar(30));
create table emp(eno int PRIMARY KEY,ename varchar(30),address varchar(30),phone varchar(30),salary float,dno int REFERENCES dept(dno));


insert into dept values(1,'compsci','kolhapur');
insert into dept values(2,'ele','pune');
insert into dept values(12,'maths','pune');

insert into emp values(1,'shivani','pune',9623425005,6000,2);
