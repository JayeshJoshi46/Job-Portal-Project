<html>
<body>
<form action="2a.php" method="post">
Enter the department name<input type="text" name="dname"><br>
<input type="submit" value="print">
</body>
</html>

<?php
$dname=$_POST['dname'];
$con=pg_connect("host=192.168.16.1 dbname=ty17 user=ty17")or die("could not connect");
$q1="Select max(salary) from emp where dno in (select dno from dept where dname ='".$dname."');";
echo "<br>Max salary is:";
$rs=pg_query($q1);
$row=pg_fetch_row($rs);
echo $row[0]."<br>";
$q2="Select min(salary) from emp where dno in(select dno from dept where dname='".$dname."');";
$q3="Select sum(salary) from emp where dno in(select dno from dept where dname='".$dname."');";

$rs1=pg_query($q2);
$rs3=pg_query($q3);

$row1=pg_fetch_row($rs1);
echo "min salary is:".$row1[0]."<br>";
$row2=pg_fetch_row($rs3);
echo "Sum of salary is:".$row2[0]."<br>";
pg_close($con);
?>

<html>
<body>
<form action="1.php" method="post">
<br>
<input type="submit" name="back" value="back">
</form>
</body>
</html>
<?php
if(isset($_POST['back']))
    header("Location:http://192.168.16.1/ty17/thirdyear/php/set5/seta/1.php");
?>
