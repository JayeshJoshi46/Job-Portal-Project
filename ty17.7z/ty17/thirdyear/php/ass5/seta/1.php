<html>
<body>
<form action="1.php" method="post">
<input type=radio name=r1 value=insert>Insert record<br>
<input type=radio name=r1 value=display>Display salary<br>
<input type=submit value=submit>
</body>
</html>
<?php
if($_POST['r1']=="insert")
{
  header("Location:http://192.168.16.1/ty17/thirdyear/php/ass5/seta/1a.php");
}
else if($_POST['r1']=="display")
{
  header("Location:http://192.168.16.1/ty17/thirdyear/php/ass5/seta/2a.php");
}
?>
