drop table stud_comp;
drop table compition;
drop table student;

create table student(sno int PRIMARY KEY,sname varchar(30),class char(15));
create table compition(cno int PRIMARY KEY,cname varchar(20),type char(15));
create table stud_comp(sno int references student(sno),cno int references compition(cno),rank int);

insert into student values(1,'manjiri','tyA');
insert into student values(2,'anita','tyB');

insert into compition values(21,'vollyball','sports');
insert into compition values(22,'badminton','s2');

insert into stud_comp values(1,21,1);
insert into stud_comp values(2,22,2);
