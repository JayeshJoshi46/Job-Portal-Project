<html>
<body>
<form action="p1.php" method="post">
Enter the project name<input type="text" name="name1"><br>
<input type="submit" value="submit">
<input type="reset" name="reset">
</form>
</body>
</html>


<?php
$hospname=$_POST['name1'];
$con=pg_connect("host=192.168.16.1 dbname=ty17 user=ty17") or die("Could not connect");
$q1="select * from employee where eno in(select eno from pro_emp where pno in(select pno from project where pname='".$hospname."'));";
echo $q1;
$rs=pg_query($q1);
echo "<table border=1>";
while($row=pg_fetch_row($rs))
{
  echo "<tr>";
  echo "<td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td>";
  echo "</tr>";
}
echo "</table>";
pg_close($con);
?>

