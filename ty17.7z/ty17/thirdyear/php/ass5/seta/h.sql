drop table doc_hosp;
drop table hospital;
drop table doctor;

create table doctor(dno int PRIMARY KEY,dname varchar(30),address varchar(30),city varchar(30),area varchar(30));

create table hospital(hno int PRIMARY KEY,hname varchar(30),hcity varchar(30));

create table doc_hosp(dno int REFERENCES doctor(dno),hno int REFERENCES hospital(hno));
 
insert into doctor values(1,'aarti','aundh','pune','a1');

insert into doctor values(3,'prakash','vimannagar','pune','b3');


insert into hospital values(11,'city','pune');
insert into hospital values(12,'ruby','pune');
insert into hospital values(21,'jj','pune');

insert into doc_hosp values(1,11);
insert into doc_hosp values(3,21);
