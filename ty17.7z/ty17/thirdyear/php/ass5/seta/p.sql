drop table pro_emp;
drop table project;
drop table employee;

create table employee(eno int primary key,ename varchar(20),qualification char(15),joindate date);
create table project(pno int primary key,pname varchar(20),ptype char(20),duration int);
create table  pro_emp(eno int references employee(eno),pno int references project(pno));
 

insert into employee values(1,'mita','bsc','05/21/2011');
insert into employee values(3,'anni','bcs','06/22/2012');

insert into project values(21,'wifi','science',20);
insert into project values(22,'bluetooth','ele',30);

insert into pro_emp values(1,21);
insert into pro_emp values(3,22);

