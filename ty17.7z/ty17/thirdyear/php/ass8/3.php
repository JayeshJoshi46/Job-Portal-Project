<?php
$to=$_POST["to"];
$from=$_POST["from"];
$subject=$_POST["subject"];
$message=$_POST["message"];

if(isset($_POST["submit"]))
{
	
	if(ereg("[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z0-9]+)*(\.[a-z]{2,3})$",$to))
	{
		$header="From".$from."\r\n";


	if(!empty($to) && !empty($subject) && !empty($message))
	{
		$mail=mail($to,$subject,$message,$header);
		if($mail)
			{
				echo "Message send successfully";
				echo "<b>To:</b> $to <br>";
				echo "<b>From:</b> $from<br>";
				echo "<b>Subject:</b>$subject<br>";
				echo "<b>Message:</b>$message<br>";
			}
			else 
			{
				echo "Error";
			}
	}

	}
	
else
	echo "Invalid email";
}
?>

