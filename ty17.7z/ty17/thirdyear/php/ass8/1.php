<?php
$to=$_POST["to"];
$from=$_POST["from"];
$subject=$_POST["subject"];
$message=$_POST["message"];

if(isset($_POST["submit"]))
{
	$header="From".$from."\r\n";


if(!empty($to) && !empty($subject) && !empty($message))
{
$mail=mail($to,$subject,$message,$header);
	if($mail)
	{
		echo "Message send successfully";
	}
	else 
	{
 		echo "Error";
	}
}
else
	echo"ERRoR";
}
?>

