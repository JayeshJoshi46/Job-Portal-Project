<html>
<body>
<form action ="4.php" method="post">
<font color="green" size="6"><center><b><i>Intractive webpage</i></b>
</center></font>
<br><br>
<table align="center">
<tr>
<td>Email:</td><td><input type="text" name="em"></td>
</tr>
<tr>
<td>Password:</td><td><input type="password" name="psswd"></td>
</tr>
<tr>
<td><input type="reset" name="reset" value="reset"></td>
<td><input type="submit" name="submit" value="submit"></td>
</tr>
</table>
</body>
</html>

<?php

$email=$_POST['em'];

if(filter_var($email,FILTER_VALIDATE_EMAIL))
	{
		echo "Email is valid";
		if(isset($_POST['submit']))
		{
			header("location:http://192.168.16.1/ty17/thirdyear/php/ass8/login.html");
		}
	}	
else
	{
		echo "Email is not valid";
	}



?>
