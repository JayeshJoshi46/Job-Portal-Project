<?php
	$q = $_GET['q'];
	$conn = pg_connect("host =192.168.16.1 dbname=ty18 user = ty18");
	$res = pg_query($conn,"select * from emp_Details where ename = '$q'")or die("Connection Failed..");
	echo "<table border='1'>
	<tr>
	<th>Name</th>
	<th>Designation</th>
	<th>Salary</th>
	</tr>";
	while($row = pg_fetch_array($res))
	{
		echo "<tr>";
		echo "<td>".$row['ename']."</td>";
		echo "<td>".$row['designation']."</td>";
		echo "<td>".$row['salary']."</td>";
		echo "</tr>";
	}
	echo "</table>";

?>
