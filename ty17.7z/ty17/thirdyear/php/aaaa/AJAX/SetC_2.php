<?php
	$q = $_GET['q'];
	$xml = Simplexml_load_file("SetC_2.xml") or die("Error");
	
	for($i=0;$i<count($xml->book);$i++)
	{
		if($xml->book[$i]->title == $q)
		{
			echo "Title: ".$xml->book[$i]->title."<br>";
			echo "Author: ".$xml->book[$i]->author."<br>";
			echo "Year: ".$xml->book[$i]->year."<br>";
			echo "Price: ".$xml->book[$i]->price."<br>";
		}
	}
?>
