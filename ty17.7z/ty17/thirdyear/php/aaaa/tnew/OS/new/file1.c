/*Hussaina Rangwala
 roll no: ty15*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct info
{
	char fname[10];
	int start,length;
	struct info *next;
};

#define ENTRY (struct info *)malloc((sizeof(struct info)))


struct info *E=NULL,*lastEntry=NULL;
int *D=NULL;


int dsize,used=0;

void init_disk()
{
	int i;
	D=(int *)malloc(sizeof(int)*dsize);
	for(i=0;i<dsize;i++)
	{
		D[i]=1;
	}
}

int search(int length)
{
	int i,j,flag,blknum;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==1)
		{
			flag=1;
			for(blknum=i,j=0;j<length;j++)
			{
				if(D[blknum++]==1)
					continue;
				else
				{
					flag=0;
					break;	
				}
			}
			if(flag==1)
				return i;
		}
	}
	return -1;
}

void allocate()
{
	char fname[30];
	int length,blknum,i,k,cnt=0;
	struct info *t,*s;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==0)
			cnt++;
	}

	if(cnt==dsize)
	{
		printf("\nDisk Full");
		return;
	}
	do
	{
		k=0;
		printf("\nEnter the filename");
		scanf("%s",fname);
		for(s=E;s!=NULL;s=s->next)
		{
			if(strcmp(s->fname,fname)==0)
			{
				printf("\nFile already exists");
				k++;
			}
		}
	}while(k!=0);

	do{
		printf("\nEnter the length of the file: ");
		scanf("%d",&length);
		if(length<=0)
		{
			printf("Invalid file length");
		}
	}while(length<=0);
	if(length<=dsize-used)
	{
		blknum=search(length);	
		
	}
	else
		blknum=-1;
	if(blknum==-1)
		printf("\nERROR: NO DISK SPACE AVAILABLE....");
	else
	{
		printf("\nBLOCK IS ALLOCATED..");
		used=used+length;
		t=ENTRY;
		strcpy(t->fname,fname);
		t->start=blknum;
		t->length=length;
		t->next=NULL;
		if(E==NULL)
			E=lastEntry=t;
		else
		{
			lastEntry->next=t;
			lastEntry=lastEntry->next;
		}
		
		for(i=1;i<=length;i++)
			D[blknum++]=0;
		printf("\nBLOCK STATUS AFTER ALLOCATION..");
		for(i=0;i<dsize;i++)
			printf("%d",D[i]);

		
	}	
}

void deallocate()
{
	struct info *s,*f;
	char fname[10];
	int start,length,i,blknum,flag=0;
	if(E==NULL)
	{
		printf("\nThere is no file to delete");
		return;
	}
	printf("\nenter the filename to delete:");
	scanf("%s",fname);
	for(s=E;s!=NULL;s=s->next)
	{
		if(strcmp(s->fname,fname)==0){
		flag=1;
		start=s->start;
		length=s->length;
		for(blknum=start,i=0;i<length;i++)
			D[blknum++]=1;
		printf("\nBLOCK STATUS AFTER DEALLOCATION...");
		for(i=0;i<dsize;i++)
			printf("%d",D[i]);
		if(s==E)
		{
			E=E->next;
			free(s);
			used=used-length;
			break;
		}
		for(f=E;f->next!=s;f=f->next) //other node deleteing
		{
			
		}

		f->next=s->next;
		free(s);
		used=used-length;
		break;
	}
	}
	if(flag==0)
		printf("\nFILE DOES NOT EXIST");	

}

void display_entry()
{
	struct info *t;
	printf("\nNAME\tSTART\tSIZE");
	for(t=E;t!=NULL;t=t->next)
		printf("\n%s\t  %d\t  %d",t->fname,t->start,t->length);
	printf("\nUSED BLOCK=%d",used);
	printf("\nFREE BLOCK=%d",dsize-used);
	
}

void disp_vector()
{
	int i=0;
	printf("\nThe bit vector is:\n");
	for(i=0;i<dsize;i++)
		printf("%d",D[i]);
}

void display_files()
{
	int i=0;
	struct info *t;
	if(E==NULL)
	{
		printf("\nNo contents");
		return;
	}
	printf("\nThe contents are: ");
	printf("\nNAME\tSTART\tSIZE");
        for(t=E;t!=NULL;t=t->next)
                printf("\n%s\t  %d\t  %d",t->fname,t->start,t->length);	

	for(t=E;t!=NULL;t=t->next)
	{
		
		printf("\n%s",t->fname);
	}
}
int main()
{
	int choice;
	do{
	printf("\nWhat is disk size=");
	scanf("%d",&dsize);
	if(dsize==0||dsize<0)
	{
		printf("Invalid disk size");
	}
	}while(dsize==0||dsize<0);
	init_disk();
	while(1)
	{
		printf("\nMenu:\n1.Show Bit Vector\n2.Create new File\n3.Show Directory\n4.Delete File\n5.Exit");
		printf("\nEnter your choice");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				display_entry();
				disp_vector();
				break;
			case 2:
				allocate();
				break;
			case 3:	
				display_files();
				break;
			case 4:
				deallocate();
				break;
			case 5:
				exit(0);	
				
		}
	}
}
