#include<stdio.h>
#include<stdlib.h>

int **allocation,**max,**need,*available,*sequence,scnt=0,*finish,sent=0,n,r,*process,*work,req[60];
char *rname;

void accept()
{
	int i,j,k;
	
	process=(int *)malloc(n*sizeof(int));
	printf("\nEnter the number of processes: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nEnter the process name P");
		scanf("%d",&process[i]);
		for(j=0;j<i;j++)
		{
			if(process[i]==process[j])
			{
				printf("\nProcess name has been repeated..Please enter again");
				i--;
				break;
			}
		}
	}
	printf("Enter the number of resources");
	scanf("%d",&r);
	rname=(char *)malloc(r*sizeof(char));
	for(i=0;i<r;i++)
        {
                printf("\nEnter the resource name",process[i]);
		getchar();
		scanf("%c",&rname[i]);
                for(j=0;j<i;j++)
                {
                        if(rname[i]==rname[j])
                        {
                                printf("\nResource name has been repeated..Please enter again");
                                i--;
                                break;
                        }
                }
        }
	
	available=(int *)malloc(r*sizeof(int));
	printf("\nEnter the available  resources for each process: ");
	for(i=0;i<r;i++)
	{
		printf("\nFor %c",rname[i]);
		scanf("%d",&available[i]);
	}
	work=(int *)malloc(r*sizeof(int));
	max=(int **)malloc(n*sizeof(int *));
  	for(i=0;i<n;i++)
     		max[i]=(int *)malloc(r*sizeof(int));
	printf("Enter the maximum allocated for each process: \n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<r;j++)
		{
			printf("P%d: Enter the resource for %c\n",process[i],rname[j]);
			scanf("%d",&max[i][j]);
			for(k=0;k<r;k++)
			{
				if(max[i][j]>available[j])
				{
					printf("\nMax allocation cannot exceed than the available amount of resource\n");
					j--;
					break;
				}
				
			}
		}
	}

	allocation=(int **)malloc(n*sizeof(int *));
  	for(i=0;i<n;i++)
     		allocation[i]=(int *)malloc(r*sizeof(int));
	printf("\nEnter the allocation of resources for each process\n" );
	for(i=0;i<n;i++)
	{
		for(j=0;j<r;j++)
		{
			printf("P%d: Enter the allocation of resource %c\n",process[i],rname[j]);
			scanf("%d",&allocation[i][j]);
		
		
			if(allocation[i][j]>max[i][j])
			{
				printf("\n Allocation cannot exceed than the maximum amount of resources\n");
				j--;
		
			}
		}
				
		
	}
	finish=(int *)malloc(n*sizeof(int));
	
}

void calc_need()
{
	int i,j;
	need=(int **)malloc(n*sizeof(int *));
  	for(i=0;i<n;i++)
     		need[i]=(int *)malloc(r*sizeof(int));
	for(i=0;i<n;i++)
	{
		for(j=0;j<r;j++)
			need[i][j]=max[i][j]-allocation[i][j];
	}
}

int check(int s)
{
	int j,i;
	/*for(j=0;j<r;j++)
	{
		if(need[i][j]>available[j])
			return 0;
	}
	return 1;*/
	i=s;
	do{
		if(!finish[i])
		{
			for(j=0;j<r;j++)
				if(need[i][j]>work[j]) break;	
			if(j==r) return i;
		}
		i=(i+1)%n;
		
	}while(i!=s);
	return -1;
}

void banker()
{
	int i,j,k;
	/*int i=0,j,cnt=1;
	while(cnt<=2)
	{
		if(finish[i]==0)
		{
			if(check_need_avail(i))
			{
				finish[i]=1;
				seq[scnt]=i;
				scnt++;
				for(j=0;j<r;j++)
					available[j]=available[j]+allocation[i][j];
			}
		}
		i=(i+1)%n;
		if(i==0)
			cnt++;
	}*/
	for(i=0;i<n;i++)
		finish[i]=0;
	for(j=0;j<r;j++)
		work[j]=available[j];
	i=0;
	while((i=check(i))!=-1)
	{
		finish[i]=1;
		for(j=0;j<r;j++)
			work[j]+=allocation[i][j];
		printf("\nResources granted to process P%d",i);
		printf("\nfinish(");
		for(j=0;j<n;j++)
			printf("%d",finish[j]);
		printf("\b)\nwork(");
		for(j=0;j<r;j++)
			{ printf("%d",work[j]);}
			printf("\n");
		printf("\b");
		sequence=(int *)malloc(n*sizeof(int));
		sequence[k++]=i;
		i=(i+1)%n;
	}
	if(k==n)
	{
		printf("\nSystem is in safe state\nThe safe sequence is:");
		for(i=0;i<n;i++)
			printf("P%d->\t",sequence[i]);
		printf("\b\b ");
	}
	else
		printf("\nThe system is not in safe state");

}

void display()
{
	int i,j;
	printf("\n");
	printf("\nAvailable\n");
	for(i=0;i<r;i++)
		printf("%d\t",available[i]);
	printf("\nProcess\t\tAllocation\t\t\tMaximum\t\t\tNeed\n");
	for(i=0;i<n;i++)
	{
		printf("\nP%d\t\t",process[i]);
		for(j=0;j<r;j++)
			printf("%d\t",allocation[i][j]);
		printf("\t");
                for(j=0;j<r;j++)
                        printf("%d\t",max[i][j]);
                printf("\t");

       	         for(j=0;j<r;j++)
                       	 printf("%d\t",need[i][j]);
                printf("\t");
       	


	}
}

int main()
{
	int i,pno,j;
	accept();
	calc_need();
	display();
	
	banker();
	printf("\nEnter process no:");
	scanf("%d",&pno);
	printf("Enter the resource request:\n");
	for(j=0;j<r;j++)
	{
		printf("%c:",65+j);
		scanf("%d",&req[j]);
	}
	for(j=0;j<r;j++)
		if(req[j]>need[pno][j])
			break;
	if(j==r)
	{
		for(j=0;j<r;j++)
			if(req[j]>available[j])
				break;
		if(j==r)
		{
			for(j=0;j<r;j++)
			{
				available[j]=available[j]-req[j];
				allocation[pno][j]=allocation[pno][j]+req[j];
				need[pno][j]=need[pno][j]-req[j];
			}
			banker();
		}
		else
			printf("P%d must wait\n",pno);
	}
	else printf("Resource cannot be granted");
}
