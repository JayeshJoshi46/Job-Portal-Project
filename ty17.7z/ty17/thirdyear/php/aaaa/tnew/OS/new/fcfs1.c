/*Hussaina Rangwala
 * Roll no: 15*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

typedef struct process_info
{
	char pname[20];
	int at,at1,bt,bt1,ct,cnt;
	struct process_info *link;

}NODE;

struct chart
{
	int start;
	char pname[20];
	int end;
}s[100],s1[100];

NODE *first,*last;
int n,*c_bt,count_s;

void process_info()
{
	int i,flag=0;
	NODE *p,*q;
	do{
		flag=0;
		printf("\nEnter the number of processes");
		scanf("%d",&n);
		if(n<=0)
		{
			printf("\nInvalid number of processes....Please enter again");
			flag++;
		}
	}while(flag!=0);
	for(i=0;i<n;i++)
	{
		p=(NODE *)malloc(sizeof(NODE));
		do{
			flag=0;
			printf("\nEnter the process name: P");
			scanf("%s",&p->pname);
			for(q=first;q!=NULL;q=q->link)
			{
				if(strcmp(p->pname,q->pname)==0)
				{
					printf("\nProcess name has been repeated...Please Enter again");
					flag++;
					break;
				}
			}
		}while(flag!=0);
		do{
			flag=0;
			printf("\nEnter the arrival time: ");
			scanf("%d",&p->at);
			if(p->at<0)
			{
				printf("\nInvalid arrival time...Please enter again");
				flag++;
			}
		}while(flag!=0);
		do{
			flag=0;
			printf("\nEnter CBT");
			scanf("%d",&p->bt);
			if(p->bt<=0)
			{
				printf("\nInvalid CBT...Please enter again");  flag++;
			}
		}while(flag!=0);
		p->at1=p->at;
		p->bt1=p->bt;
		p->ct=p->cnt=0;
		p->link=NULL;
		if(first==NULL)
			first=p;
		else
			last->link=p;
		last=p;
	}
	c_bt=(int *)malloc(n*sizeof(int));
}

void output_table()
{
	NODE *p=first;
	float avgWT=0,avgTAT=0,tat,wt;
	int i=0,count_p=0,j;
	printf("\nProcess\t|Arrival_time\t|CPU_Burst_Time\t|CT\t|TAT\t|WT\n");
	while(p!=NULL)
	{
		count_p=0;
		for(j=0;j<count_s;j++)
		{
			if(strcmp(s[j].pname,p->pname)==0)
			{
				if(count_p==0)
					wt=(s[j].start-p->at);
				else
					wt+=(s[j].start-p->at1);
				count_p++;
			}
		}
		tat=wt+(p->bt+c_bt[i])+2;
		printf("P%s\t|%d\t%d\t|%d\t%d\t|%d\t|%.2f\t|%.2f\n",p->pname,p->at,p->at1,p->bt,c_bt[i],p->ct,tat,wt);
		avgTAT+=tat;
		avgWT+=wt;
		p=p->link;
		i++;
	}
	printf("------------------------------------------------------------\n");
	printf("AVG TAT=%f \t AVG WT=%f\n",(avgTAT/n),(avgWT/n));
	
}


void sort()
{
	NODE *p,*q;
	p=first;
	while(p->link!=NULL)
	{
		q=p->link;
		while(q!=NULL){
		if(p->at1>q->at1)
		{
			char tname[20];
			int t;
			strcpy(tname,p->pname);
			strcpy(p->pname,q->pname);
			strcpy(q->pname,tname);

			t=p->at;
			p->at=q->at;
			q->at=t;

			t=p->bt;
			p->bt=q->bt;
			q->bt=t;
	
			t=p->ct;
                        p->ct=q->ct;
                        q->ct=t;


			t=p->at1;
                        p->at1=q->at1;
                        q->at1=t;

			t=p->bt1;
                        p->bt1=q->bt1;
                        q->bt1=t;
		
			t=p->cnt;
                        p->cnt=q->cnt;
                        q->cnt=t;

		}
		q=q->link;
		
	}
	p=p->link;
	}
}

int time;

int is_arrived()
{
	NODE *p;
	p=first;
	while(p!=NULL)
	{
		if(p->bt1!=0&&p->at1<=time)
			return 1;
		p=p->link;
	}
	return 0;
}

NODE * get_fcfs()
{
        NODE *p;
        p=first;
        while(p!=NULL)
        {
                if(p->bt1!=0&&p->at1<=time)
                        return p;
                p=p->link;
        }
        return NULL;
}

int finish,prev,i;

void fcfs()
{
	NODE *p;
	int k=0;
	i=0;
	count_s=0;
	while(finish!=n)
	{
		if(!is_arrived())
		{
			count_s++;
			time++;
			s[i].start=prev;
			strcpy(s[i].pname,"*");
			s[i++].end=time;
			prev=time;
		}
		else
		{
			count_s++;
			//prev=time;
			p=get_fcfs();
			time+=p->bt1;
			p->ct=time;
			p->bt1=0;
			s[i].start=prev;
			strcpy(s[i].pname,p->pname);
			s[i++].end=time;
			prev=time;
			if(p->bt1==0&&p->cnt==0)
			{
				p->cnt++;
				p->at1=p->ct+2;
				p->bt1=rand()%10;
				c_bt[k++]=p->bt1;
			}
			if(p->bt1==0&&p->cnt==1)
				finish++;

			sort();
		}
	}
}

void print_gantt_chart()
{
	int j,k,l;
	printf("\nGantt Chart: ");
	s1[0]=s[0];
	for(j=1,k=0;j<i;j++)
	{
		if(strcmp(s[i].pname,s1[k].pname)==0)
			s1[k].end=s[j].end;
		else
			s1[++k]=s[j];
	}
	printf("%d",s1[0].start);
	for(j=0;j<=k;j++)
	{
		int m=s1[j].end-s[j].start;
		for(l=0;l<m/2;l++)
			printf("-");
		if(strcmp(s[j].pname,"*")!=0)
			printf("P%s",s1[j].pname);
		else
			printf("%s",s1[j].pname);
		for(l=0;l<(m+1)/2;l++)
			printf("-");
		printf("%d",s1[j].end);
	}
	printf("\n");
}

void main()
{
	system("clear");
	process_info();
	sort();
	fcfs();
	print_gantt_chart();
	output_table();
}
