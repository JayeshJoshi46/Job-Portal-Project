#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct dir_entry
{
  char fname[20];
  int start, end, flag;
  struct dir_entry *link;
} DIR;

DIR *first=NULL, *last;

int fat[200], d, free_blocks,g=0;

void
print_dir ()
{
  DIR *p;
  int i;
  if(first!=NULL)
  	printf ("\nName\tStart\tEnd\tBlocks\n");
  p = first;
  while (p != NULL)
    {
      if (p->flag == 0)
	{
	  if(first!=NULL)
	  	printf ("%s\t%d\t%d\t", p->fname, p->start, p->end);
	  i = p->start;
	  do
	    {
	      printf ("%d->", i);
	      i = fat[i];
	    }
	  while (i != -1);
	  printf ("NULL\n");
	}
      p = p->link;
    }
  printf ("--------------\n");
}

void create()
{
	DIR *p,*s,*q,*f;
	  char fname[20];
	  int bno, i, j, ch,k,flag=0;
	do
	  {
		flag=0;		
		if(free_blocks!=0)
		{
			k=0;
			printf("\nEnter the filename");
			scanf("%s",fname);
			for(s=first;s!=NULL;s=s->link)
			{
				if(strcmp(s->fname,fname)==0)
				{
					printf("\nFile already exists");
					k++;
				}
			}
		}
		else
		{
			printf("\nBlocks full cannot create a new file");
			flag++;
			return;
		}
	  }while(k!=0);
	  do{	
		
		k=0;
		  	printf ("Enter no.of blocks:");
		  	scanf ("%d", &bno);
			if(bno<=0)
			{
				printf("\nInvalid block size..please enter again");
				k++;
			}
			else if(bno>d)
			{
				printf("\nBlock size exceeding than the total number of blocks");
				k++;
			}
		
		
	  }while(k!=0);
  
	  if (free_blocks >= bno)
	    {
	      free_blocks -= bno;
	      p = (DIR *) malloc (sizeof (DIR));
	      strcpy (p->fname, fname);
	      p->flag = 0;
	      p->link = NULL;
	      for (i = 0; i < d; i++)
		{
		  if (fat[i] == -999)
		    {
		      bno--;
		      break;
		    }
		}
	      p->start = i;
	      j = i;
	      i++;
	      while (bno != 0)
		{
		  if (fat[i] == -999)
		    {
		      fat[j] = i;
		      j = i;
		      bno--;
		    }
		  i++;
		}
	      fat[j] = -1;
	      p->end = j;
	      if (first == NULL)
		first = p;
	      else
		last->link = p;
	      last = p;
		g=d;
	      printf ("File %s created successfully.\n", fname);
	    }
	  else
	    {
	      printf ("Failed to create file %s \n", fname);
	    }
	  
}
void
print_free_list ()
{
  int i;
  printf ("\nFree List:");
  for (i = 0; i < d; i++)
    if (fat[i] == -999)
      printf ("%d->", i);
  printf ("NULL\n");
}

void
main ()
{
  DIR *p,*s,*q,*f;
  char fname[20];
  int bno, i, j, ch,k,flag=0;
  system ("clear");
  do{
	k=0;
  	printf ("\nEnter no. of disk blocks:");
  	scanf ("%d", &d);
	if(d<=0)
	{
		printf("\nInvalid block size..please enter again");
		k++;
	}
  }while(k!=0);
   g=d;
  for (i = 0; i < d; i++)
    fat[i] = -999;
  free_blocks = d;
  while (1)
    {
      
      printf ("\n1.create\n");
      printf ("2.Delete\n");
      printf ("3.Display Free/Dir list \n");
      printf ("4.Display Contents \n");
      printf ("5.Exit\n");
      printf ("Enter ur choice(1-5):");
      scanf ("%d", &ch);

      switch (ch)
	{
	case 1:
	  
	  create();
		break;
	case 2:
	  if(first==NULL)
	  {
		printf("\nNo file in directory");
		break;
          }
	  else 
	  {
		k=0;
	  	printf ("Enter file name to delete:");
	  	scanf ("%s", fname);
		for(s=first;s!=NULL;s=s->link)
		{
			if(strcmp(s->fname,fname)==0)
			{
				k++;
				
			}
			
			
		}
		if(k==0)
		{
			printf("File does not exist");
			break;
		}
	  }
	  
	  p = first;
	  while (p != NULL)
	    {
	      if (strcmp (p->fname, fname) == 0 && p->flag == 0)
		break;
	      p = p->link;
	    }
	  if (p == NULL)
	    {
	      printf ("File %s not found.\n", fname);
	    }
	  else
	    {
	      p->flag = 1;
	      bno = 0;
	      i = p->start;
	      do
		{
		  j = fat[i];
		  fat[i] = -999;
		  i = j;
		  bno++;
		}
	      while (i != -1);
	      free_blocks += bno;  
	      for(f=first,q=NULL;f!=NULL;f=f->link)
	      {
			if(strcmp(f->fname,fname)==0)
			{
				if(q==NULL)
				{
					first=f->link;
				}
				else
					q->link=f->link;
			}
			q=f;
	      }
		free(f);
			      
	      printf ("File %s deleted successfully.\n", fname);
	    }
	  break;

	case 3:
	  print_dir ();
	  print_free_list ();
	  break;
	case 4:
	  if(first==NULL)
	  {
		printf("Directory is empty");
	  }
	  else
	  {
		printf("\nThe contents of the directory are:");
	  	for(s=first;s!=NULL;s=s->link)
			printf("\n%s",s->fname);
	  }
	   break;
	case 5:
	  exit (0);
	}			//switch
    }
}
