#include<stdio.h>
#include<stdlib.h>

#define newnode (struct node *)malloc(sizeof(struct node))

struct node{
	int jobno,arvl_time,burst_time,completion_time,rem_time,sub_time;
	struct node * next;;
}*JOBQ=NULL,*finish=NULL;

int jobs=0;
struct node * Append(struct node *F,struct node *t)
{
	struct node *S;
	if(F==NULL)
		F=t;
	else
	{
		for(S=F;S->next!=NULL;S=S->next);
		S->next=t;
	}
	return F;
}

void createJOBQ()
{
	struct node *t;
	int i;
	do{
	printf("\nHow many jobs?");
	scanf("%d",&jobs);
	for(i=0;i<jobs;i++)
	{
		t=newnode;
		t->next=NULL;
		t->jobno=i;
		t->completion_time=0;
		printf("\nJob%d>enter arrival time",i);
		scanf("%d",&t->arvl_time);
		do{
		printf("\nJob%d>enter cpu burst time",i);
		scanf("%d",&t->burst_time);
		}while(t->burst_time==0);
		t->sub_time=t->arvl_time;
		t->rem_time=t->burst_time;
		JOBQ=Append(JOBQ,t);
	}
	}while(jobs==0);
}

void Display()
{
	struct node *t;
	if(JOBQ==NULL)
		printf("\nJOBQ is empty!!");
	else
	{
		printf("\n\njob\tArrival\tCPU_burst");
		for(t=JOBQ;t!=NULL;t=t->next)
			printf("\njob%d\t%4d\t%3d",t->jobno,t->arvl_time,t->burst_time);
		
	}
}

/*For execution*/

struct node * firstJob(struct node *F,int time)
{
	struct node *S=NULL,*t;
	int min=1000;
	for(t=F;t!=NULL;t=t->next)
	{
		if(t->arvl_time<=time&&t->arvl_time<min)
		{
			min=t->arvl_time;
			S=t;
		}
	}
	return S;
}	

void delNode(struct node *s)
{
	struct node *t;
	if(s==JOBQ)
		JOBQ=JOBQ->next;
	else
	{
		for(t=JOBQ;t->next!=s;t=t->next)
		{
			t->next=s->next;
		}
	}
	s->next=NULL;
	finish=Append(finish,s);
}

void Execute()
{
	struct node *T,*S=NULL;
	int time=0;
	int turnaround,TATsum=0,WTsum=0,n=0;
	if(JOBQ==NULL)
	{
		printf("\nJob q is empty!!");
		return;
	}
	printf("\nclock CPU JOBQ");
	while(JOBQ!=NULL)
	{
		S=firstJob(JOBQ,time);
		//printf("\n jobno: %d time : %d",S->jobno,time);
		if(S==NULL)
			printf("\n%3d -idle- ",time++);
		else
		{
			printf("\n%3d j%d (%d) ",time,S->jobno,S->rem_time);
		/*	for(T=JOBQ;T!=NULL;T=T->next)
			{
				if(T!=S&&T->arvl_time<=time)
					printf("%d -j%d (%d) ",T->arvl_time,T->jobno,T->rem_time);
			}*/
			time+=S->rem_time;
			if(S->completion_time==0)
			{
				S->completion_time=time;
				S->arvl_time=time+2;
				S->rem_time=(rand()%10)+1;
				//printf("\n$$$$$$$$$cpu: %d\n",S->burst_time);
				S->burst_time+=S->rem_time;
			//	printf("\n\n*********job%d: s->arvl_time=%d s->rem_time=%d s->burst_time=%d*******\n\n",S->jobno,S->arvl_time,S->rem_time,S->burst_time);
			}
			else
			{
				S->completion_time=time;
				delNode(S);
			}
		}
	}
//	printf("\n%3d -idle-",time);
	printf("\n\nJob  Arrival  Burst  Completion  TAT  WT");
	for(T=finish;T!=NULL;T=T->next)
	{
		turnaround=T->completion_time-T->sub_time;
		printf("\n%3d%5d%5d%8d",T->jobno,T->sub_time,T->burst_time,T->completion_time);
		printf("%8d %5d",turnaround,(turnaround-T->burst_time));
		TATsum+=turnaround;
		WTsum+=turnaround-T->burst_time;
		n++;
	}
//	printf("\nAvg TAT=%6.2f",TATsum/(float)n);
//	printf("\nAvg WT=%6.2f",WTsum/(float)n);
}

void main()
{
	createJOBQ();
	Display();
	Execute();
}
