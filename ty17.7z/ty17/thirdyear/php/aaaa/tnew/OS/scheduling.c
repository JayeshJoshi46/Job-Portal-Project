#include<stdio.h>
int cpu_burst,arr_time;

void accept()
{
	printf("");
}	


main() 
