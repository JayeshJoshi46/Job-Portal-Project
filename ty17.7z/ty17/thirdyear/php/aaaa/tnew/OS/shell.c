#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<dirent.h>

void list(char *dn,char op)
{
	DIR *dirp;
	struct dirent *entry;
	int dc=0,fc=0;
	dirp=opendir(dn);
	if(dirp==NULL)
	{
		printf("Directory %s not found\n",dn);
		return;
	}
	switch(op)
	{
		case 'F':
			while(entry=readdir(dirp))
			{
				if(entry->d_type==DT_REG)
					printf("%s\n",entry->d_name);
			}
			break;
		case 'N':
			while(entry=readdir(dirp))
                        {
                                if(entry->d_type==DT_REG) fc++;
				if(entry->d_type==DT_DIR)
					dc++;
                        }
			printf("%d File(s)\t %d Dir(s)\n",fc,dc);
                        break;
		case 'I':
			while(entry=readdir(dirp))
                        {
                                if(entry->d_type==DT_REG)
                                        printf("%s\t%u\n",entry->d_name,entry->d_fileno);
                        }
                        break;
		default:
			printf("Invalid parameter\n");
	}
}

void parse_cmd(char *cmd,char *args[])
{
	char *p,delim[]=" ";
	int i=0;
	p=strtok(cmd,delim);
	while(p!=NULL)
	{
		args[i++]=p;
		p=strtok(NULL,delim);
	}
	args[i]=NULL;
}

void typeline(char *fn,char *op)
{
	char ch;
	int fd,n,i,j;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("\nFile %s not found\n",fn);
		return;
	}
	if(strcmp(op,"a")==0)
	{
		while(read(fd,&ch,1)>0)
			printf("%c",ch);
		close(fd);
		return;
	}
	n=atoi(op);
	if(n>0)
	{
		i=0;
		while(read(fd,&ch,1)>0)
		{
			printf("%c",ch);
			if(ch=='\n')
				i++;
			if(i==n) break;
		}
	}
	if(n<0)
	{
		i=0;
		while(read(fd,&ch,1)>0)
		{
			if(ch=='\n')  i++;
		}
		lseek(fd,0,SEEK_SET);
		j=0;
		while(read(fd,&ch,1)>0)
		{
			if(ch=='\n')  j++;
			if(j==i+n)   break;
		}
		while(read(fd,&ch,1)>0)
		{
			printf("%c",ch);
		}
	}
	close(fd);
}

void search(char *fn,char op,char *pattern)
{
	int fd,count=0,i=0,j=0;
	char ch,line[80],*p;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("File %s not found\n",fn);
                return;

	}
	switch(op)
	{
		case 'F':
			while(read(fd,&ch,1)>0)
			{
				if(ch=='\n')
				{
					j++;
					line[i]='\0';
					i=0;
					if(strstr(line,pattern)!=NULL)
					{
						printf("%d:%s\n",j,line);
						break;
					}
				}
				else
					line[i++]=ch;
			}
			break;
		case 'A':
			while(read(fd,&ch,1)>0)
                        {
				if(ch=='\n')
				{
					j++;
					line[i]='\0';
					i=0;
                                        if(strstr(line,pattern)!=NULL)
                                        {
                                                printf("%d:%s\n",j,line);
                                        }
				}
				else
					line[i++]=ch;
			}
			break;
		case 'C':
			while(read(fd,&ch,1)>0)
                        {
                                if(ch=='\n')
                                {
                                        j++;
                                        line[i]='\0';
                                        i=0;
					p=line;
                                        if((p=strstr(line,pattern))!=NULL)
                                        {
						count++;
						p++;
                                        }
                                }
                                else
                                        line[i++]=ch;
                        }
			printf("%d\n",count);
                        break;
		default:
			printf("Invalid parameter\n");
	}
	close(fd);
}

void count(char *fn,char op)
{
	int cc=0,wc=0,lc=0,fd;
	char ch;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("File %s not found\n",fn);
                return;

	}
	while(read(fd,&ch,1)>0)
	{
		if(ch==' ') 
			wc++;
		if(ch=='\n') 
		{
			wc++;
			lc++;
		}
		cc++;
	}
	close(fd);

	switch(op)
	{
		case 'C':
			printf("%d\t%s\n",cc,fn);
			break;		
		case 'W':
                        printf("%d\t%s\n",wc,fn);
                        break;
		case 'L':
                        printf("%d\t%s\n",lc,fn);
                        break;
		default:
			printf("Invalid parameter");

	}
}

void main()
{
	int pid;
	char command[80],*args[20];
	while(1)
	{
		printf("myshell$");
		fflush(stdin);
		fgets(command,80,stdin);
		command[strlen(command)-1]='\0';
		parse_cmd(command,args);
		if(strcmp(args[0],"list")==0)
		{
			list(args[2],args[1][0]);
		}
		else if(strcmp(args[0],"count")==0)
                {
                        count(args[2],args[1][0]);
                }
		else if(strcmp(args[0],"typeline")==0)
                {
			typeline(args[2],args[1]);
                }

		else if(strcmp(args[0],"search")==0)
                {
			//printf("\nargs[3]=%s args[1][0]=%s args[2]=%s ",args[3],args[1][0],args[2]);
                        search(args[2],args[1][0],args[3]);
                }
		else if(strcmp(args[0],"exit")==0)
			exit(0);
		else
		{
			pid=fork();
			if(pid>0)
			{
				wait();
			}
			else
				if(execvp(args[0],args)==-1)
					printf("\nBad Command\n");
		}

	}
}
