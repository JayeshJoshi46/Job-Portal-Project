#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<dirent.h>

void list(char *dn,char op)
{
	DIR *dirp;
	struct dirent *entry;
	int dc=0,fc=0;
	dirp=opendir(dn);
	if(dirp==NULL)
	{
		printf("Directory %s not found\n",dn);
		return;
	}
	switch(op)
	{
		case 'F':
			while(entry=readdir(dirp))
			{
				if(entry->d_type==DT_REG)
					printf("%s\n",entry->d_name);
			}
			break;
		case 'N':
			while(entry=readdir(dirp))
                        {
                                if(entry->d_type==DT_REG) fc++;
				if(entry->d_type==DT_DIR)
					dc++;
                        }
			printf("%d File(s)\t %d Dir(s)\n",fc,dc);
                        break;
		case 'I':
			while(entry=readdir(dirp))
                        {
                                if(entry->d_type==DT_REG)
                                        printf("%s\t%u\n",entry->d_name,entry->d_fileno);
                        }
                        break;
		default:
			printf("Invalid parameter\n");
	}
}

void parse_cmd(char *cmd,char *args[])
{
	char *p,delim[]=" ";
	int i=0;
	p=strtok(cmd,delim);
	while(p!=NULL)
	{
		args[i++]=p;
		p=strtok(NULL,delim);
	}
	args[i]=NULL;
}

void main()
{
	int pid;
	char command[80],*args[20];
	while(1)
	{
		printf("myshell$");
		fflush(stdin);
		fgets(command,80,stdin);
		command[strlen(command)-1]='\0';
		parse_cmd(command,args);
		if(strcmp(args[0],"list")==0)
		{
			list(args[2],args[1][0]);
		}
		else
		{
			pid=fork();
			if(pid>0)
			{
				wait();
			}
			else
				if(execvp(args[0],args)==-1)
					printf("\nBad Command\n");
		}
	}
}
