<?php
session_start();
echo "<center><font color='green' size=6> FINAL BILL</font></center><br><br>";
echo"<table align=center border=1>";
echo "<tr><th> Customer Name</th><th>Address</th> <th> Contact no</th> <th> Product Name</th> <th>Quantity</th> <th>Rate</th>";
echo "<tr> <td>".$_SESSION['name']."</td>";
echo "<tr> <td>".$_SESSION['addr']."</td>";
echo "<tr> <td>".$_SESSION['phone']."</td>";
echo "<tr> <td>".$_SESSION['prod_nm']."</td>";
echo "<tr> <td>".$_SESSION['qty']."</td>";
echo "<tr> <td>".$_SESSION['rate']."</td></tr>";
echo "</table> <br><br>";
echo "<center>Total Amount: ".($_SESSION['quantity']*$_SESSION['rate'])."Rs</center>";
?>
