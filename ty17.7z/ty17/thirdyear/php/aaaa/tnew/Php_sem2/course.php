<?php
header('Contem-Type.text/xml');
$str='<?xml version="1.0"?>'."\n";
$str="<Course>\n";
$ComputerScience=array(array('StudentName'=>'Hussaina','ClassName'=>'TYBCS','percentage'=>'76.1'),array('StudentName'=>'Komal','ClassName'=>'TYBCS','percentage'=>'76.1'));

foreach($ComputerScience as $cs)
{
	$str.="<ComputerScience>\n";
	foreach($cs as $tag=>$data)
	{
		$str .="<$tag>".htmlspecialchars($data)."</$tag>\n";
	}
	$str .="</ComputerScience>\n";
}
$str .="</Course>\n";
$fp=fopen("course.xml","w");
fwrite($fp,$str);
?>
