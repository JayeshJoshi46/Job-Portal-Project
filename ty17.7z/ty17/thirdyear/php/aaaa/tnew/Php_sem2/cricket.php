<pre>

<?php
$cricketTeam=new SimpleXMLElement("<CricketTeam/>");
$country=$cricketTeam->addChild("Country");
$country->addAttribute("name","India");
$country->addChild("Playername","M Dhoni");
$country->addChild("Wickets","36");
$country->addChild("Runs","10000");

$country=$cricketTeam->addChild("Country");
//$country=$cricketTeam->addChild("Country");
$country->addAttribute("name","England");
$country->addChild("Playername","Alastair cook");
$country->addChild("Wickets","2");
$country->addChild("Runs","9500");
$cricketTeam->asXML("cricket.xml");
echo"<h4>cricket.xml created</h4>";
?>
</pre>

