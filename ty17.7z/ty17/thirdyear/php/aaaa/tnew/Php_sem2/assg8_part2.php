<?php

$to=$_POST['to'];
	$subject=$_POST['from'];
	$message=$_POST['subject'];;
	$header=$_POST['message'];
	if(mail($to,$subject,$message,$header."\r\n"))
	{
		echo "Message sent successfully";
	}
	else
	{
		echo "Message could not be sent...";
	}
?>
