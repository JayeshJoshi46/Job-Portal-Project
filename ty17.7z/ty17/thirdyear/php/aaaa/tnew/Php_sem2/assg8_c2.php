<html>
<body>
<form action="assg8_c2.php" method="post">
Login<input type='text' name='login'><br>
Password<input type='text' name='password'>
<input type='submit' value='Login' name='submit'>
</form>
</body>
</html>

<?php
$email=$_POST['login'];
if(filter_var($email,FILTER_VALIDATE_EMAIL))	
{
	header("location:http://192.168.16.1/ty15/Php_sem2/assg8_file.html");
}

?>
