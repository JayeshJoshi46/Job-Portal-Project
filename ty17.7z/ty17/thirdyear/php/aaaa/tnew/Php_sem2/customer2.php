<html>
<body>
<form action="customer2.php" method="post">
<font color='green' size='5'><center><b>Product Info</b></center>
Product Name<input type=text name=n1><br>
Quantity<input type=text name=n2><br>
Rate<input type=text name=n3><br>
<input type="submit" value="submit"><br>
</form>
</body>
</html>

<?php
session_start();
if(isset($_POST['submit']))
{
        $prod_nm=$_POST['n1'];
        $qty=$_POST['n2'];
        $rate=$_POST['n3'];

        $SESSION['product']=$prod_nm;
        $SESSION['quantity']=$qty;
        $SESSION['rate']=$rate;
        session_write_close();
        header("location:http://192.168.16.1/ty15/Php_sem2/customer3.php");
}
?>

