<?php
	session_start();
	$_SESSION["tm"]=time()+2;
	
?>
<form method="get" action="new.php">
Roll no: <input type="text" name="rno"><br>
Name: <input type="text" name="nm"><br>
City: <input type="text" name="ct"><br><br>
<input type="submit" value="submit">
</form>
