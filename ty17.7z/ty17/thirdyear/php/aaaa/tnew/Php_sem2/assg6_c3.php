<html>
<body>
<form action="assg6_c3.php" method="post">
<font color='green' size='5'><center><b>Customer Info</b></center>
Name<input type=text name=n1><br>
Address<input type=text name=n2><br>
Phone<input type=text name=n3><br>
<input type="submit" value="submit" name='submit'><br>
</form>
</body>
</html>

<?php
session_start();
if(isset($_POST['submit']))
{
	echo "Hussaina";
	$name=$_POST['n1'];
	$addr=$_POST['n2'];
	$phone=$_POST['n3'];

	$SESSION['name']=$name;
	$SESSION['addr']=$addr;
	$SESSION['phone']=$phone;
	session_write_close();
	header("location:http://192.168.16.1/ty15/Php_sem2/customer2.php");
}	
?>
