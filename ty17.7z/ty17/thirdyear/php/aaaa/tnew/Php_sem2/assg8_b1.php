<html>
<body>
<form action="assg8_b1.php" method="post">
<table>
<tr><td>To:</td>
<td> <input type=text name=to size=50></td>
</tr>
<tr><td>From:</td>
<td> <input type=text name=from size=50></td>
</tr>
<tr><td>Subject:</td>
<td> <input type=text name=subject size=50></td>
</tr>
<tr><td valign="top">Message:</td>
<td>
<textarea cols="60" rows="10" name="message">
enter your message here </textarea></td>
</tr>
<tr><td></td>

<td> <input type=submit value=send name=submit>
<input type="reset" value="Reset"></td>
</tr>
</table>
</form>
</body>
</html>

<?php
$to=$_POST['to'];
	$from=$_POST['from'];
	$subject=$_POST['subject'];
	$message=$_POST['message'];
	if(isset($_POST['submit']))
	{
		if(ereg("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z0-9]+)*(\.[a-z]{2,4})$",$to))
		{
			$headers="From".$from."\r\n";
			$mailsent=mail($to,$subject,$message,$headers);
			if($mailsent)
			{
				echo "hello<br></br>";
				echo "<b>To:</b>$to<br>";
				echo "<b>From:</b>$from<br>";
				echo "<b>Subject:</b>$subject<br>";
				echo "<b>Message:</b><br>$message";


			}
			else{
				echo "There was an error...";
			}
		}
		else
		{
			echo "Email address is invalid";
		}
	}
?>
