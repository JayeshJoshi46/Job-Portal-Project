<?php
$doc=new DOMDocument("1.0");
$doc->formatOutput=true;
$cdstore=$doc->createElement("CDStore");
$doc->appendChild($cdstore);

$movie=$doc->createElement("Movie");
$cdstore->appendChild($movie);
$title=$doc->createElement("Title","Mr. India");
$movie->appendChild($title);
$release=$doc->createElement("ReleaseYear","1987");
$movie->appendChild($release);

$movie=$doc->createElement("Movie");
$cdstore->appendChild($movie);
$title=$doc->createElement("Title","Holiday");
$movie->appendChild($title);
$release=$doc->createElement("ReleaseYear","2014");
$movie->appendChild($release);

$movie=$doc->createElement("Movie");
$cdstore->appendChild($movie);
$title=$doc->createElement("Title","LOC");
$movie->appendChild($title);
$release=$doc->createElement("ReleaseYear","2003");
$movie->appendChild($release);

$doc->save("CDStore.xml");
echo "<h4>CDstore.xml created</h4>";
?>


