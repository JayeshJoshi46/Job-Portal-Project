<?php
	echo "<html><head><link rel='stylesheet' type='text/css' href='course.css'></head></htmpl>";
	$xml=simplexml_load_file("course.xml") or die("ERROR");
	echo "<table border=1>";
	for($i=0;$i<count($xml->ComputerScience);$i++)
	{
		echo "<tr>";
		foreach($xml->ComputerScience[$i]->StudentName as $child)
		echo"<td class=td50>$child</td> ";
			
		
		foreach($xml->ComputerScience[$i]->ClassName as $child)
		echo"<td class=td60>$child</td> ";

		foreach($xml->ComputerScience[$i]->percentage as $child)
		echo"<td class=td70>$child</td> ";
		echo"</tr>";
	}
	echo "</table>";
		

?>
