<html>
<head>
<script>
function change()
{
	var text=document
}
