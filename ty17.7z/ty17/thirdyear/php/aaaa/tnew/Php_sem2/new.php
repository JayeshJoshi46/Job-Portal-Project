<?php
	session_start();
	$newt=$_SESSION['tm'];
	if($newt<time())
		echo "Time out";
	else
	{
		echo "Roll no: $_GET[rno] <br>";
		echo "Name: $_GET[nm] <br>";
		echo "City: $_GET[ct] <br>";
	}
	session_destroy();
?>
