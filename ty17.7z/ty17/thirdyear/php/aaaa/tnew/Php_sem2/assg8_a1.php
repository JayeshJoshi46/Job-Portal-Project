<?php

	$to=$_POST['n1'];
	$subject=$_POST['n2'];
	$message=$_POST['n3'];;
	$header=$_POST['n4'];
	if(is_null($to))
	{
		if(is_null($subject))
		echo "Details no entered..Mail cannot be sent";
	}
	else if(mail($to,$subject,$message,$header."\r\n"))
	{
		echo "Message sent successfully";
	}
	else
	{
		echo "Message could not be sent...";
	}
	
?>
