
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
		private ServerSocket s;
		private ObjectInputStream reader;
		private ObjectOutputStream writer;
		
		public Server()	{
			try {
				s = new ServerSocket(4444);
				System.out.println("\n Server Started");
				Socket socket = s.accept();
				writer = new ObjectOutputStream(socket.getOutputStream());
				writer.flush();
				reader = new ObjectInputStream(socket.getInputStream());
				System.out.println("Waiting for Client Msges: ");
				while(true) {
					Object incoming = reader.readObject();
					String msg = (String) incoming;
					if(msg.equals("END")) {
						System.out.println("Disconnecting Client..");
						break;
					}
					else System.out.println("Client says: "+msg);
				}
				socket.close();
			}catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		public static void main(String[] args) {
			new Server();
		}
}
