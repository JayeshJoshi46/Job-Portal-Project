<?php
	$s1=$_GET['s1'];
	$s2=$_GET['s2'];
	$s3=$_GET['s3'];
	$n1=strlen($s1);
	$n2=strlen($s2);
	$r=array();
	if($n1>0 || $n2>0)
	{
		if($_GET['a']=='compeq')
		{
			if($s1==$s2)
				echo"Equal";
			else
				echo"Not equal";	
		}
		else
		if($_GET['a']=='strcmp')
		{
			if(strcmp($s1,$s2)==0)
				echo"Equal";
			else
				echo"Not equal";	
		}
		else
		if($_GET['a']=='append')
		{
			$res=$s1.$s2;
			echo"Concatenation is".$res;
		}
		else
		if($_GET['a']=='reverse')
		{
			if(strlen($s3)==0|| $s3>strlen($s1) ||$s3<0)
				echo"Please enter correct position";
			else
			if($s3==0)
			echo"Please enter position";
			else
			{
				for($i=$s3,$j=0;$i<strlen($s1);$i++,$j++)
				{
					$r[$j]=$s1[$i];
				}
				echo"<br>Reverse string is";
				for($j=count($r)-1;$j>=0;$j--)
				{
					echo $r[$j];
				}
			}
		}
	}
		else
		echo"Either enter string or position";
?>
		
