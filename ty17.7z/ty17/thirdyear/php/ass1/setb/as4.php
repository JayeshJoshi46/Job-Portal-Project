<?php
$a=$_POST['t1'];
$b=$_POST['t2'];
$c=$_POST['t3'];
var_dump(ereg("^$b","$a"));
$a1=ereg_replace($b,$c,$a);
echo $a1;
$str=split("[ ]",$a);
print_r($str);
?>

