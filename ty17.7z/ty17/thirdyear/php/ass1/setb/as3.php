<?php
  include "as3.inc";
  $n1=$_GET['n1'];
  $n2=$_GET['n2'];
  if($_GET['a']=='add')
   add($n1,$n2);
  if($_GET['a']=='sub')
   sub($n1,$n2);
  if($_GET['a']=='mul')
   mul($n1,$n2);
  if($_GET['a']=='div')
   div($n1,$n2);
?>
