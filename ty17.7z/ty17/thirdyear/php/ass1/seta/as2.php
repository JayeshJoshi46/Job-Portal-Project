<?php
 $s1=$_GET['t1'];
 $s2=$_GET['t2'];
 $s3=$_GET['t3'];
 $cnt=substr_count($s1,$s2);
 echo"Count of small strings in the large string is: $cnt";
 $n=strlen($s3);
 $str=str_replace($s2,$s3,$s1);
 echo"<br>";
 echo"Replaced string is:$str";
?>

