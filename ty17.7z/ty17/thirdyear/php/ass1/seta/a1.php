<?php
 include "q.inc";
 $a=$_POST['n1'];
 if($_POST['r1']=='t')
 count_vow($a);
 else if($_POST['r1']=='o')
 count_occur($a);
 else if($_POST['r1']=='p')
 palindrome($a);
?>
 
