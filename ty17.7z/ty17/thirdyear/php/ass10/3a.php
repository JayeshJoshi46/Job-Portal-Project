<html>
<script>
	function validate()
	{
		var name=document.getElementById("un").value;
		var password=document.getElementById("pwd").value;
	
		var pattern= /^[a-zA-Z]+$/;

		if(name!=" " && password!=" ")
		{
			if(password.length>5)
			{
				if((name.match(pattern))
				{
					return true;;
				}
				else
				{
					alert("User name should only contain alphabets");
				}
			}
			else
			{
				alert("Password can not be less than 5 chars");
			}
		}
		else
		{
			alert("User name or password can not be empty");	
		}
			return false;
	}
</script>
<form onSubmit="return validate()" action="asA1.html">
	Username<input type="text" name="n1" id="un">
	Password<input type="text" name="n2" id="pwd">
<iput type ="submit" value="ok">
</form>
</body>
</html>
	
