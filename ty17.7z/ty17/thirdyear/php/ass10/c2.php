<html>
<head>
<title>JAVASCRIPT</title>
</head>
<body>
<script>
function change()
{
var text = document.form1.sname.value;
if(text!="")
{
alert(text);

document.getElementById("p1").innerHTML=text;
document.getElementById("p1").style.color="Blue";
document.getElementById("p1").style.fontSize="XX-large";
}
}
function changeImg()
{
document.write("<img src = 'image.jpg' id = 'img1' onmouseOver='width=500'>");
}
</script>
<form action="post" name="form1">
<input type="text" id = "id1" name="sname" onblur="change()" ondblClick="changeImg()"><br>
<p id="p1"></p>
</form>
</body>
</html>
