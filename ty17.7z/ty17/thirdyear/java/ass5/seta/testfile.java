/*SHivani kajave. Roll no 17. DIv A. ass 5 set A 1*/
import java.io.*;
public class testfile
{
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String args[]) throws IOException
	{
		int fcount=0,ans;
		try
		{
			String str;
			str=args[0];
			File f=new File(str);
			if(f.isDirectory())
			{
				String s[]=f.list();
				System.out.println("\nContents of directory are:");
				for(int i=0;i<s.length;i++)
				{
					File f1=new File(str,s[i]);
					System.out.println(s[i]);
					if(f1.isFile())
						fcount++;
				}
				System.out.println("The number of files in the directory are"+fcount);
				for(int i=0;i<s.length;i++)
				{
					File f1=new File(str,s[i]);
					if(f1.isFile())
					{
						if(s[i].endsWith("txt"))
						{
							System.out.println("\nDo you want to delete the file"+s[i]+"(yes/no)");
							ans=Integer.parseInt(br.readLine());
							if(ans==1)
							f1.delete();
						}
					}
				}
			}
			if(f.isFile())
			{
				System.out.println("\nThe path of the file is"+f.getPath()+"\nSize is"+f.length()+"\nAbsolute Path is"+f.getAbsolutePath());
			}
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("\nInvalid number of arguments");
		}
	}
}
