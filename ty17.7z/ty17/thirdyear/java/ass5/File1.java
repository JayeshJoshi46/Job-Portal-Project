import java.io.*;
import java.io.File.*;

class File1
{
 public static void main(String args[]) throws IOException
 {
  String str=args[0];
  File f=new File(str);
  if(f.isFile())
  {
   System.out.println("Name:"+f.getName());
   System.out.println("Size:"+f.length());
   System.out.println("Path:"+f.getAbsolutePath());
  }
  else
  if(f.isDirectory())
  {
   File s[]=f.listFiles();
   for(int i=0;i<s.length;i++)
   {
    System.out.println(s[i]);
    if(s[i].isFile())
    {
     String str2=s[i].getName();
     if(str2.endsWith(".txt"))
     {
      System.out.println("Do you want to delete(y/n)");
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      char ch=(char)br.read();
      if(ch=='y' || ch=='Y')
      {
        s[i].delete();
      }
      else
	System.out.println("Can not delete:");
    }
  }
 }
}
else
{
 System.out.println("Invalid input");
}
}
}
