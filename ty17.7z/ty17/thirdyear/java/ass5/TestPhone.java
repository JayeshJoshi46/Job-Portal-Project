import java.io.*;
 
public class TestPhone
{
 static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
 public static void main(String args[]) throws IOException
 {
  int choice=0;
  boolean f=false;
  String name;
  FileInputStream f1=new FileInputStream("phone.txt");
  System.out.println("Total bytes available"+f1.available());
  f1.close();
  while(true)
  {
   FileReader f2=new FileReader("phone.txt");
   System.out.println("\nEnter choice\n1.Search name and display phone number\n2.Add a new name phone number pair.\n3.exit");
   choice=Integer.parseInt(br.readLine());
   switch(choice)
   {
    case 1:
    BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
     System.out.println("\nEnter the name you want to search");
     name=br.readLine();
     String s1=null;
     while((s1=br1.readLine())!=null)
     {
      String tok[]=s1.split("[ ]");
      if(name.compareTo(tok[0]==0)
      {
       f=true;
       System.out.println("\nName"+tok[0]+"\nPhone number"+tok[1]);
       break;
      }
     }
     if(f==false)
     {
      System.out.println("\nRecord not found);
     }
      f2.close();
      break;
     case 2:
      BufferedWriter out=new BufferedWriter(new FileWriter("phone.txt",true));
      System.out.println("Enter the name and phone number");
       name=br.readLine();
     String pn=null;
     do
      {
       System.out.println("\nEnter the phone number:");
       pn=br.readLine();
       if(pn.length()!=10)
       {
        System.out.println("
