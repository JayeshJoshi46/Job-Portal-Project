/*Shivani kajave. Ass 5 set b 1*/
import java.io.*;
public class TestItem
{
	static BufferedReader br =
      new BufferedReader (new InputStreamReader (System.in));
	  public static void main (String args[]) throws IOException
    {
		int choice=0,ans;
		boolean flag=false;
		double max=0.0;
		String name;
		while(true)
		{
			RandomAccessFile f=new RandomAccessFile("item.dat","r");
			FileReader f2=new FileReader("item.dat");
			System.out.println("\nEnter choice\n1.Search a specific item by name\n2.Find the costliest item\n3.Display all items and total cost\n4.exit");
			choice=Integer.parseInt(br.readLine());
			switch(choice)
			{
				
				case 1:
					BufferedReader br1=new BufferedReader(f2);
					System.out.println("\nEnter the name of item you want to search=");
					name=br.readLine();
					String s1=null;
					while((s1=br1.readLine())!=null)
					{
						String tok[]=s1.split("[ ]");
						if(name.compareTo(tok[1])==0)
						{
							flag=true;
							System.out.println("Item no:"+tok[0]+"Item name:"+tok[1]+"price"+tok[2]);
							break;
						}
					}
					if(flag==false)
					{
						System.out.println("\nRecord not found");
					}
					f2.close();
					break;
				case 2:
						BufferedReader br2=new BufferedReader(f2);
						String s2=null,s3=null;
						int i=0;
						double temp;
						while((s2=br2.readLine())!=null)
						{
								String tok1[]=s2.split("[ ]");
								temp=Double.parseDouble(tok1[2]);
								if(temp>max)
								{
									max=temp;
									s3=s2;
								}
						}
						String tok2[]=s3.split("[ ]");
						System.out.println("Costliest Item is=");
						System.out.println("Item_id:"+tok2[0]+"\nItem_name:"+tok2[1]+"Item price:"+tok2[2]+"Qty"+tok2[3]);
						f2.close();	
						break;
					case 3:
						System.out.println("The records are=");
						System.out.println("id name cost qty");
						while((ans=f.read())!=-1)
							System.out.print((char)ans);

						f.seek(0);
						break;
					case 4:
						System.exit(0);
						break;
				default:	
					System.out.println("Invalid choice");
		}
	}
}
}				
