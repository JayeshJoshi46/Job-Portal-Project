/*Shivani kajave. Roll no17.Div A.Ass 2 Set B2*/
import SY.symarks;
import TY.tymarks;
 
import java.io.*;

public class Studenth
{
 int roll;
 String name;
 
 Studenth()
 {
  roll=0;
  name="";
 }
 
  Studenth(int r,String n)
 {
  roll=r;
  name=n;
 }
 
 
 public void accept()
 {
  try
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   System.out.println("Enter rollno=");
   roll=Integer.parseInt(br.readLine());
    System.out.println("Enter name=");
   name=br.readLine();
  }
  catch(IOException e)
  {
  }
 }
  public String toString()
 {
  return roll + "," + name;
 }

 public static void main(String args[])
 {
  int n=Integer.parseInt(args[0]);
  Studenth o[]= new Studenth[n];
  symarks o1[]= new symarks[n];
  tymarks o2[]= new tymarks[n];

 for(int i=0;i<n;i++)
 {
  o[i]=new Studenth();
  o[i].accept();
  o1[i]=new symarks();
  o1[i].accept();
  o2[i]=new tymarks();
  o2[i].accept();
 }
 
  for(int i=0;i<n;i++)
  {
   System.out.println(o[i]);
   System.out.println(o1[i]);
   System.out.println(o2[i]);
  }

  for(int i=0;i<n;i++)
  {
   int sum=0;
   sum+=o1[i].computertotal+o2[i].theory+o2[i].practical;
   int avg=sum/2;
   if(avg>=75)
   {
    System.out.println("Grade A");
   }
   else if(avg>=65&&avg<75)
   {
     System.out.println("Grade B");
   }
   else if(avg<65&&avg>=55)
   {
     System.out.println("Grade C");
   } 
   else if(avg>=40&&avg<55)
   {
     System.out.println("Grade D");
   }
   else
   System.out.println("Fail");
 }
}
}
   
 
 
