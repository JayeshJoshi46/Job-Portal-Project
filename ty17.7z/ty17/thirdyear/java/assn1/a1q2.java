import java.util.*;

public class a1q2
{
public static void main(String args[])
{
LinkedList l1 = new LinkedList();
l1.add("RED");
l1.add("BLUE");
l1.add("YELLOW");
l1.add("ORANGE");

ListIterator i1 = l1.listIterator();
System.out.println("Forward Iteration ::");
while(i1.hasNext())
{
	String color =(String)i1.next();
	System.out.println("\t"+color);
}
System.out.println("Backward Iteration ::");
while(i1.hasPrevious())
{
	String color =(String)i1.previous();
	System.out.println("\t"+color);
}
LinkedList l2 = new LinkedList();
l2.add("PINK");
l2.add("GREEN");

l1.addAll(2,l2);
ListIterator i2 = l1.listIterator();
System.out.println("After Modifying LL 1 ::");
while(i2.hasNext())
{
	String color =(String)i2.next();
	System.out.println("\t"+color);
}
}
}
