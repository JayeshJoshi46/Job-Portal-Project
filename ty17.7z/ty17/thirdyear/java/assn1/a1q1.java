
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.TreeSet;

public class a1q1 {
	TreeSet<Integer> set = new TreeSet<Integer>();
	int n;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public a1q1() {
		try {
			System.out.println("Enter Number of Elements :: ");
			n = Integer.parseInt(br.readLine());
			System.out.println("Enter Elements :: ");
			for (int i=0;i<n;i++) {
				set.add(Integer.parseInt(br.readLine()));
			}
			System.out.println("TREESET :: "+set);
			
			System.out.println("Enter Element to be Searched: ");
			int key = Integer.parseInt(br.readLine());
			if(Arrays.binarySearch(set.toArray(), key) < 0)
				System.out.println("NOT found");
			else 
			System.out.println("Element: "+ key + " found at Position: "+Arrays.binarySearch(set.toArray(), key));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new a1q1();
	}

}
