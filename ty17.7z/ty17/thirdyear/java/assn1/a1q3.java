

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Hashtable;

public class a1q3 {
	Hashtable<String, Double> record =  new Hashtable<String, Double>();
	
	public a1q3() throws IOException {
		record.put("RASHMI",88.0);
		record.put("PRAJAKTA",85.3);
		record.put("XYZ",74.3);
		record.put("ABC",50.5);
		
		Enumeration<String> keys = record.keys();
		Enumeration<Double>Elements = record.elements();
		
		while(keys.hasMoreElements() && Elements.hasMoreElements()){
			System.out.println(keys.nextElement()+" "+ Elements.nextElement());
		}	
			//search
			System.out.println("Enter the name of Student :: ");
			BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
			String name = br.readLine();
			
			System.out.println("Percentage secured by "+name+ " is :: "+record.get(name));
		
	}
	
	public static void main(String[] args) throws IOException {
		new a1q3();
	}
}
