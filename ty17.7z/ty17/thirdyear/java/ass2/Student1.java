/*Shvani Kajave.ROll no 17.Div A. ass2 set A 1 */
import java.io.*;
class Student1
{
 	int rollno;
	String name;
	float perc;
 	static int cnt;

 	Student1() //default constructor
 	{
  		rollno=0;
		name="";
		perc=0;
 	}

 	static
 	{
  		cnt=0;
 	}

 	Student1(int rno,String nm,float p) //parametrized constructor
 	{
 		rollno=rno;
 		name=nm;
 		perc=p;
 		cnt++;
 	}


 	public void function()
 	{
  		System.out.println("The object is created:");
 		System.out.println("The count is:"+cnt);
 	}

 	void accept() throws Exception
 	{
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
		 System.out.println("Enter roll no=");
 		 rollno=Integer.parseInt(br.readLine());
		 int k,n;
 
  		System.out.println("Enter name="); 
  		n=Integer.parseInt(br.readLine());
  		for(int i=0;i<strlen;i++)
  		if(isalpha(name))
 		System.out.println("invalid");
  
  		System.out.println("Percentage is=");
 		perc=Float.parseFloat(br.readLine());
 	}


 	void display()
 	{
  		System.out.println("Rollno="+rollno+"\nName is="+name+"\npercentage are="+perc);
 	}

 	public static void sort_stud(Student1 s[],int n)
 	{ 
		float temp; int r; String nme;

  		for(int i=0;i<=n;i++)
  		{
   			for(int j=0;j<n-1;j++)
   			{
    				if(s[j].perc>s[j+1].perc)
    				{
     					temp=s[j].perc;
     					s[j].perc=s[j+1].perc;
   					s[j+1].perc=temp;
  
     					r=s[j].rollno;
     					s[j].rollno=s[j+1].rollno;
     					s[j+1].rollno=r;
 
					nme=s[j].name;
    					s[j].name=s[j+1].name;
     					s[j+1].name=nme;
    				}
   			}
  		}
 	}


 public static void main(String args[]) throws Exception
 { 
	int i;
  	int n=Integer.parseInt(args[0]);
  	Student1 []s1=new Student1[n];
  	for( i=0;i<n;i++)
  	{
  		 s1[i]=new Student1();
  		 s1[i].accept();
  	}
  
  	System.out.println("Before sorting.\n");
 	 for(i=0;i<n;i++)
	 {
   		 s1[i].display();
   	 }
   
   	System.out.println("\n\nAfter sorting.\n");
   	for(i=0;i<n;i++)
   	{  
		  Student1.sort_stud(s1,n);
    		  s1[i].display();
	}

  }
 }
