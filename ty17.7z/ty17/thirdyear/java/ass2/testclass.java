import Series.*

class testclass
{
 public static void main(String args[])
 {
 int n=Integer.parseInt(args[0]);
 
 Prime o1=new Prime();
 Fibonacci o2=new Fibonacci();
 Square o3=new Square();
 o1.Prime(n);
 o2.Fibonacci(n);
 o3.Square(n);
 }
}

