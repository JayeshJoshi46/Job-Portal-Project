/*Shvani Kajave. ROll no 17. Div A.  ass 2 Set A 1 */

class Student
{
 	int rollno;
 	String name;
 	float perc;
	static int cnt;

 	Student() //default constructor
	{
		  rollno=0;
		  name="";
		  perc=0;
	}

 	static
 	{
  		cnt=0;
 	}

 	Student(int rno,String nm,float p) //parametrized constructor
 	{
 		rollno=rno;
 		name=nm;
 		perc=p;
 		cnt++;
	}


	 public void function()
 	{
  		System.out.println("The object is created:");
  		System.out.println("The count is:"+cnt);
 	}

 	void display()
 	{
 		 System.out.println("Rollno="+rollno+"\nName is="+name+"\npercentage are="+perc);
 	}

	 public static void main(String args[])
 	{
// int n=Integer.parseInt(args[0]);
 		Student s1=new Student();
		s1=new Student(3,"shivnai",90);
 		s1.function();
  		s1.display();
 	}
 
}
