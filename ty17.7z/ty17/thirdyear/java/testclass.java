/*Shivani kajave. Roll no 17 .DIv A aSS 2 SET B 1*/

import Series.*;

class testclass
{
 public static void main(String args[])
 {
 int n=Integer.parseInt(args[0]);
 
 Prime o1=new Prime();
 Fibonacci o2=new Fibonacci();
 Square o3=new Square();
 o1.prime(n);
 o2.fibonacci(n);
 o3.square(n);
 }
}

