/*Shivani kajave. Roll no17.Div A.Ass 2 Set B SYMARKS*/
package SY;
import java.io.*;

public class symarks
{
 public int computertotal;
 public int mathstotal;
 public int electronictotal;

 public symarks()
 {
  computertotal=0;
  mathstotal=0;
  electronictotal=0;
 }
 
  public symarks(int c,int m,int e)
 {
  computertotal=c;
  mathstotal=m;
  electronictotal=e;
 }

 public void accept()
 {
  try
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   System.out.println("Enter computer total=");
   computertotal=Integer.parseInt(br.readLine());
   System.out.println("Enter maths total=");
   mathstotal=Integer.parseInt(br.readLine());

   System.out.println("Enter electronics total=");
   electronictotal=Integer.parseInt(br.readLine());
  }
  catch(IOException e)
  {
  }
 }

 public String toString()
 {
  return computertotal + "," + mathstotal + "," +electronictotal;
 }
}
