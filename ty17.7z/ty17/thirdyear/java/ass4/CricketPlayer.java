/*Shivani kajave.Roll no 17.Div A, Ass 4 set A 1*/
import java.io.*;

 class NegativeNumberException extends Exception
 {
  NegativeNumberException()
  {
  }
  NegativeNumberException(int n)
  {
   System.out.println("Negative number is not accepted");
  }
 }

 class InvalidNameException extends Exception
 {
 }
  

 class CricketPlayer
 {
  static BufferedReader br=new BufferedReader (new InputStreamReader(System.in));

  String name;
  int i,no_of_inn,not_out,tot_runs;
  float bat_avg;
  
  void accept() throws IOException
  {
   int f;
   try
   {
    System.out.println("Enter the name:");
    name=br.readLine();
    for(i=0;i<name.length();i++)
    {
      if(!((name.charAt(i)>=65 && name.charAt(i)<=91)||(name.charAt(i)>=97 && name.charAt(i)<=122)))
    throw new InvalidNameException();
    }
    do
    {
     f=0;
     System.out.println("Enter the number of innings:");
     no_of_inn=Integer.parseInt(br.readLine());
     if(no_of_inn<0)
     {  
      System.out.println("Negative number is not acceptable:plz enter again:");
   f++;
    }
   }while(f!=0);

   do
   {
    f=0;
    System.out.println("Enter the number of times out:");
     not_out=Integer.parseInt(br.readLine());
     if(not_out<0)
     {
      System.out.println("Negative number is not acceptable:plz enter again:");
   f++;  
    }
   }while(f!=0);
   
   do
   {
    f=0;
    System.out.println("Enter the total runs:");
     tot_runs=Integer.parseInt(br.readLine());
     if(tot_runs<0)
     {
      System.out.println("Negative number is not acceptable:plz enter again:");
   f++;
    }
   }while(f!=0);
  
   }

   catch (NumberFormatException nfe) 
   {
  
   }
 
   catch(InvalidNameException ine)
   {
    System.out.println("Invalid name:");
   }
   
   catch(IOException e)
   {
   }
   }

   static void avg(CricketPlayer c[])
   {
    for(int i=0;i<c.length;i++)
     {
      try
       {
        if(((c[i].no_of_inn)-(c[i].not_out))<0)
         throw new NegativeNumberException();
 	  c[i].bat_avg=(c[i].tot_runs)/((c[i].no_of_inn)-(c[i].not_out));
	}
       catch(NegativeNumberException nfe)
       {
         System.out.println("Negative number not acceptable");
       }
       
       catch(ArithmeticException e)
       {
        System.out.println("Divide by zero not possible");
       }
      }
     }

 void display() 
 {
  System.out.println(name + "\t" +no_of_inn + "\t" + not_out + "\t" +tot_runs + "\t" +bat_avg);
 }

static void sort1(CricketPlayer c[])
 {
  int i,j,temp1;
 float temp2;
 String temp;
 for(i=c.length-1;i>0;i--)
 {
  for (j=0;j<i;j++)
  {
   if(c[j].bat_avg>c[j+1].bat_avg) 
   {
    temp=c[j].name;
    c[j].name=c[j+1].name;
    c[j+1].name=temp;
  
    temp1=c[j].no_of_inn;
    c[j].no_of_inn=c[j+1].no_of_inn;
    c[j+1].no_of_inn=temp1;

     temp1=c[j].not_out;
    c[j].not_out=c[j+1].not_out;
    c[j+1].not_out=temp1;

     temp1=c[j].tot_runs;
    c[j].tot_runs=c[j+1].tot_runs;
    c[j+1].tot_runs=temp1;

      temp2=c[j].bat_avg;
    c[j].bat_avg=c[j+1].bat_avg;
    c[j+1].bat_avg=temp2;
    }
    }
    }
   }

  }

 class cricket
 {
   static BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
   public static void main(String s[]) throws IOException
   {
    System.out.println("\nEnter number of players you want:");
    int n=Integer.parseInt(br.readLine());
    CricketPlayer c[]=new CricketPlayer[n];
    for(int i=0;i<n;i++)
    {
     System.out.println("Enter the" + (i+1) + "record");
     c[i]=new CricketPlayer();
     c[i].accept();
     }
   
   CricketPlayer.sort1(c);
   for(int i=0;i<n;i++)
   {
    c[i].display();
   }
  }
 }
