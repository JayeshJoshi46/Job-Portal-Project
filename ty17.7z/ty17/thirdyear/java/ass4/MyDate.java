/*Shivani kajave.Roll no 17.Div A, Ass 4 set A 1*/
import java.io.*;

class InvalidMonthException extends Exception
{
 private String code;
 public InvalidMonthException(String s)
 {
  code=s;
 }
 String getcode()
 {
 return code;
 }
}

class InvalidDayException extends Exception
{
  private String code;
 public InvalidDayException(String s)
 {
  code=s;
 }
  String getcode()
 {
 return code;
 }
}

class InvalidYearException extends Exception
{
  private String code;
 public InvalidYearException(String s)
 {
  code=s;
 }
  String getcode()
 {
 return code;
 }
}

class MyDate
{
 static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
 int d,m,y;
 MyDate()
 {
  d=m=y=0;
 }
 
 MyDate(int d,int m,int y)
 {
  this.d=d;
  this.m=m;
  this.y=y;
 }

 void accept() throws IOException
 {
  try
  {
   System.out.println("\nEnter the date\nEnter the year");
   y=Integer.parseInt(br.readLine());
   if(y<0)
    throw new InvalidYearException("\nINVALID YEAR");
    boolean leap=(((y%400)!=0)&&(y%4==0 && y%100!=0));
    System.out.println("\nEnter the month");
    m=Integer.parseInt(br.readLine());
    if(m<1||m>12)
    {
     throw new InvalidMonthException("INvalid month");
    }
    System.out.println("\nEnter the day");
    d=Integer.parseInt(br.readLine());
    switch(m)
    {
     case 1:case 3:case 5:case 7:case 8:case 10:case 12:
      if(d<1||d>31)
      throw new InvalidDayException("Invalid Day");
      break;
     case 4:case 6:case 9:case 11:
      if(d<1||d<30)
      throw new InvalidDayException("Invalid Day");
      break;
     case 2:if(leap && d>=29)
            throw new InvalidDayException("Invalid Day");
            else if(!(leap)&& d>=29)
            throw new InvalidDayException("Invalid Day");
	    break;
     }
    }
    catch(InvalidDayException e)
    {
     System.out.println(e.getcode());
    }
  
    catch(InvalidMonthException e)
    {
     System.out.println(e.getcode());
    }
   
     catch(InvalidYearException e)
    {
     System.out.println(e.getcode());
    }
  }  
    void display()
    {
     System.out.println(d+"\t"+m+"\t"+y);
    }
}

class month
{
 public static void main(String s[]) throws IOException
 {
  MyDate md=new MyDate();
  md.accept();
  md.display();
 }
 }
  


