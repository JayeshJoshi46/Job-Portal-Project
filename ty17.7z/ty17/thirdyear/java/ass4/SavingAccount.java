/*Shivani kajave.Roll no 17.Div A, Ass 4 set A 1*/

import java.io.*;
 
class InsufficientFundsException extends Exception
{
  InsufficientFundsException()
  {
  }
  InsufficientFundsException(int n)
  {
  System.out.println("\nTransaction not possible due to low balance:");
  }
} 

class InvalidNameException extends Exception
{
}


class SavingAccount
{
 static  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
 String acno;
 String name;
 float balance;
 
 SavingAccount()
 {
  acno="";
  name="";
  balance=0.0f;
 } 
 
 SavingAccount(String a,String n,float b)
 {
  acno=a;
  name=n;
  balance=b;
 }
 
 void accept() throws IOException
 {
  int k=0;
  try
  {
   do
   {  
    System.out.println("Enter account number:");
    k=0;
    acno=br.readLine(); 
    if(acno.length()!=11)
    {
     k++;
     System.out.println("Invalid acount number:");
    }
   }while(k!=0);
   System.out.println("Enter the name :");
   name=br.readLine();
   for(int i=0;i<name.length();i++)
   {
    if(!((name.charAt(i)>=65 && name.charAt(i)<=91)||(name.charAt(i)>=97 && name.charAt(i)<=122)))
    throw new InvalidNameException();
   }
 }
  

 catch (InvalidNameException e)
 { 
 System.out.println("\nInvalid name:");
 System.exit(0);
 }
 catch (NumberFormatException e)
 {
  
 }
 
 catch (IOException e)
 {
 }
 
 do
 {
  k=0;
  System.out.println("Enter curent balance:"); 
  balance=Float.parseFloat(br.readLine());
  if(balance<500)
  {
   System.out.println("Balance cannot be less than 500");
   k++;
  } 
 }while(k!=0);
}
   

 public void withdraw() throws IOException
 {
  float amt;
  try
  { 
   System.out.println("Enter amount you want withdraw");
   amt=Float.parseFloat(br.readLine());
  
   float q=balance-amt;
   if(q<500)
   {
    throw new InsufficientFundsException();
   }
   balance-=amt;
  }
 catch(InsufficientFundsException e)
 {
  System.out.println(e.getMessage());
 }
 }

 public void deposit() throws IOException
 {
  float amt;
  
  System.out.println("Enter the amount to be deposit");
  amt=Float.parseFloat(br.readLine());
  balance+=amt;
 }
 
 void viewbalance()
 { 
  System.out.println("Balance:"+balance);
 }
 
 void display()
 {
  System.out.println(name+"\t"+acno+"\t"+balance);
 }
 }

  class Saving
 {
 static  BufferedReader br= new BufferedReader (new InputStreamReader(System.in));

  public static void main(String args[]) throws Exception
  {
   int n;
   SavingAccount sa=new SavingAccount();
   System.out.println("Enter the customer details:");
   sa.accept();
   do
   {
    System.out.println("\nEnter your choice:\n1.Withdraw\n2.Deposit.\n3.viewBalance.4.details.\n.5.exit");
    n=Integer.parseInt(br.readLine());
    switch(n)
    { 
     case 1:
           sa.withdraw(); break;
     case 2: sa.deposit();break;
     case 3: sa.viewbalance();break;
     case 4:sa.display();break;
     case 5:System.exit(0);
            break;
     default:System.out.println("enter valid choice:");
   }
  }while(n!=5);
}
}
  
  
 
   
