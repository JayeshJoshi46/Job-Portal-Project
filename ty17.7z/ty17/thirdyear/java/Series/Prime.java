/*Shivani Kajave.ROll no 17 .Div A.Ass 2 Set B prime*/
package Series;


public class Prime
{
  int n;
 
 public void prime(int n)
 {
  int i,j=0,k=0,flag;
  System.out.println("The prime numbers are:");
  for(i=2;j<n;i++)
  {
   flag=0;
   for(k=2;k<i;k++)
   {
    if(i%k==0)
    { 
     flag=1;
     break;
    }
   }

   if(flag==0)
   {
    j++;
    System.out.println(+i);
   }
  }
}
}
