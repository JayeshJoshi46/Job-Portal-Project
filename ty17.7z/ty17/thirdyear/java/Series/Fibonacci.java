/*Shivani Kajave.ROll no 17 .Div A.Ass 2 Set B fibonacci*/
 
package Series;
 
public class Fibonacci
{
 public void fibonacci(int n)
 {
  int f1=0,f2=1,f3=0;
  System.out.println("series is");

  for(int i=1;i<=n;i++)
  {
  f3=f1+f2;
 
  System.out.println(f2);
  f1=f2;
  f2=f3;
  }
 }
}

