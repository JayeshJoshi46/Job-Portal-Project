/*Shivani Kajave.ROll no 17 .Div A.Ass 2 Set B square*/
package Series;


public class Square
{
 public void square(int n)
 {
  int r;
  r=n*n;
  System.out.println("The square is"+r);
 }
 
}

