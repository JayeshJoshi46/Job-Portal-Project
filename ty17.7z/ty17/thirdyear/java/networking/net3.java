import java.net.*;
import java.io.*;

class FileServer
{
	ServerSocket sob;
	Socket cob;
	InputStream is;
	OutputStream os;
	DataInputStream dis;
	DataOutputStream dos;
	
	FileServer
	{
		sob=new ServerSocket(13000);
		System.out.println("Server is stored");
		cob=sob.accept();
		System.out.println("Client is connected");
		is=cob.getInputStream();
		os=cob.getOutputStream();
		dis=new DataInputStream(is);
		dos=new DataOutputStream(os);
	}
	
	public void echo() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader(f));
