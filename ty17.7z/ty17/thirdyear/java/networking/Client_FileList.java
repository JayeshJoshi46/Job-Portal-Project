//package A6.setB;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class Client_FileList {
		private ObjectInputStream reader;
		private ObjectOutputStream writer;
		private ArrayList<String> fileList= new ArrayList<String>();
		private String response;
		
		public Client_FileList() {
			try {
				System.out.println("\n Client Started");
				Socket socket = new Socket("localhost",4444);
				System.out.println("\n Connection Established!");
				writer = new ObjectOutputStream(socket.getOutputStream());
				writer.flush();
				reader = new ObjectInputStream(socket.getInputStream());

				System.out.println("Enter File names (Enter .. to stop): ");
				while(true) {
					String string = new BufferedReader(new InputStreamReader(System.in)).readLine();
					if(string.equals(".."))
						break;
					fileList.add(string);
				}
				
				writer.writeObject(fileList);
				System.out.println("Waiting for Server to Respond: ");
				do {
					response = (String)reader.readObject();
					System.out.println(response);
				}while(!response.equals("Completed!"));
				socket.close();
			}catch(Exception e) {
				System.out.println(e);
			}
		}
		public static void main(String[] a) {
			new Client_FileList();	
		}
	} 
