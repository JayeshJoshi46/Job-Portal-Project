package A6.setB;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client {
	private ObjectOutputStream writer;

	public Client() {
		try {
			System.out.println("\n Client Started");
			Socket socket = new Socket("localhost",4444);
			System.out.println("\n Connection Established!");
			writer = new ObjectOutputStream(socket.getOutputStream());
			writer.flush();

			System.out.println("Send Messages to Server: (END to stop) ");
			while(true) {
				String string = new BufferedReader(new InputStreamReader(System.in)).readLine();
				writer.writeObject(string);
				writer.flush();
				if(string.equals("END"))
					break;
			}
			socket.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public static void main(String[] a) {
		new Client();	
	}
} 
