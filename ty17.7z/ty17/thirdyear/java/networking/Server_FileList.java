//package A6.setB;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server_FileList {
	private ServerSocket s;
	private ObjectInputStream reader;
	private ObjectOutputStream writer;
	private ArrayList<String> fileList;
	
	@SuppressWarnings("unchecked")
	public Server_FileList()	{
		try {
			s = new ServerSocket(4444);
			System.out.println("\n Server Started");
			Socket socket = s.accept();
			writer = new ObjectOutputStream(socket.getOutputStream());
			writer.flush();
			reader = new ObjectInputStream(socket.getInputStream());
			System.out.println("Waiting for File name: ");
			Object incoming = reader.readObject();
			fileList = (ArrayList<String>) incoming;
			
			for(String file:fileList) {
				File f = new File("./",file);
				if(f.exists() && f.isFile()) {
					System.out.println("Client Requested for file :" +f + "\n Status: File Found..!");
					writer.writeObject(file + " Found on Server.");
					writer.flush();
				}
				else {
					System.out.println("Client Requested for file :" +f + "\n Status: File NOT Found..!");
					writer.writeObject(file + " NOT Found on Server.");
					writer.flush();
				}
			}
			writer.writeObject("Completed!");
			socket.close();
			s.close();	
		}catch(IOException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] a) {
		new Server_FileList();	
	} 

}
