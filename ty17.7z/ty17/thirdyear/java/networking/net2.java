import java.io.*;
import java.net.*;
//import java.util.*;

class FileServer
{
	ServerSocket sob;
	Socket cob;
	InputStream is;
	OutputStream os;
	DataInputStream dis;
	DataOutputStream dos;

	FileServer() throws Exception
	{
		sob=new ServerSocket(13000);
		System.out.println("Server is stored");
		cob=sob.accept();
		System.out.println("Client is connected");
		is=cob.getInputStream();
		os=cob.getOutputStream();
		dis=new DataInputStream(is);
		dos=new DataOutputStream(os);
	}
	
	void send() throws Exception
	{
		String fname=dis.readUTF();
		File f=new File(fname);
		if(!f.exists())
			dos.writeUTF("File not found");
		else
		{
			BufferedReader br=new BufferedReader(new FileReader(f));
			String line=null;
			while((line=br.readLine())!=null)
				
				dos.writeUTF("End");
		}
			dos.writeUTF("END");
			cob.close();
			sob.close();
		
	}
	
	
	public static void main(String args[]) throws Exception
	{
		FileServer obs= new FileServer();
		obs.send();
	}
}
class FileClient
{
	Socket cob;
	InputStream is;
	OutputStream os;
	DataInputStream dis;
	DataOutputStream dos;

	FileClient() throws Exception
	{
		cob=new Socket("localhost",13000);
		is=cob.getInputStream();
		os=cob.getOutputStream();
		dis=new DataInputStream(is);
		dos=new DataOutputStream(os);
	}

	void request() throws Exception
	{	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file name");
		String fname=br.readLine();
		dos.writeUTF(fname);
		while(true)
		{
			String line=dis.readUTF();
			if(line.equals("END"))
				break;
			System.out.println(line);	
		}
	
		cob.close();
	}
	public static void main(String args[]) throws Exception
	{
		FileClient obc= new FileClient();
                obc.request();
	}
}
