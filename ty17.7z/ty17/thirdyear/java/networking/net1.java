import java.io.*;
import java.net.*;
import java.util.*;

class DateServer
{
	ServerSocket sob;
	Socket cob;
	OutputStream os;
	DataOutputStream dos;

	DateServer() throws Exception
	{
		sob=new ServerSocket(13000);
		System.out.println("Server is stored");
		cob=sob.accept();
		System.out.println("Client is connected");
		os=cob.getOutputStream();
		dos=new DataOutputStream(os);
	}
	
	void echo() throws Exception
	{
		String msg=new Date().toString();
		dos.writeUTF(msg);
		cob.close();
		sob.close();
	}
	
	public static void main(String args[]) throws Exception
	{
		DateServer obd= new DateServer();
		obd.echo();
	}
}
class DateClient
{
	Socket cob;
	InputStream is;
	DataInputStream dis;
	
	DateClient() throws Exception
	{
		cob=new Socket("localhost",13000);
		is=cob.getInputStream();
		dis=new DataInputStream(is);
	}

	void request() throws Exception
	{
		String msg=dis.readUTF();
		System.out.println("SErver date and time is"+msg);
		cob.close();
	}
	public static void main(String args[]) throws Exception
	{
		DateClient obc= new DateClient();
                obc.request();
	}
}
