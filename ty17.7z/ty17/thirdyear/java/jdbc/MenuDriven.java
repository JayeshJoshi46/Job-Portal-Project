import java.io.*;
import java.sql.*;

class MenuDriven
{
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	BufferedReader br;

	MenuDriven()
	{
		br=new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://192.168.16.1:5432/ty18","ty18","");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}


	void insert()throws Exception
	{
		System.out.print("\nEnter student's name= ");
		String sname=br.readLine();
		System.out.print("\nEnter Roll Number= ");
		int rno=Integer.parseInt(br.readLine());
		System.out.print("\nEnet Percentage= ");
		double per=Double.parseDouble(br.readLine());
		//try
		//{
			ps=con.prepareStatement("insert into student values(?,?,?)");
			ps.setInt(1,rno);
			ps.setString(2,sname);	ps.setDouble(3,per);
			int i=ps.executeUpdate();
			if(i>0)
			{
				System.out.println("\nRECORD INSERTED SUCCESSFULY!!!");
			}
			ps.close();
		//}
		/*catch(Exception e)
		{
		}*/
	}//insert

	void modify()throws Exception
	{
		System.out.print("\nEnter Roll Number= ");
		int rno=Integer.parseInt(br.readLine());

		ps=con.prepareStatement("select * from student where rno=?");	ps.setInt(1,rno);
		rs=ps.executeQuery();
		int f=0;
		while(rs.next()){f=1;}
		if(f==0)
		{
			System.out.println("\nNo records found for student having roll number "+rno);
			return;
		}
		else
		{
			System.out.print("\nEnter Student's name= ");	String sname=br.readLine();
			System.out.print("\nEnter Percentage name= ");
			double per=Double.parseDouble(br.readLine());
			ps=con.prepareStatement("update student set name=?,percentage=? where rno=?");
			ps.setString(1,sname);	ps.setDouble(2,per);	ps.setInt(3,rno);
			int i=ps.executeUpdate();
			if(i>0)
				System.out.println("\nRecorde Updated Successfully!!");
		}
		rs.close();	ps.close();
	}//modify


	void delete_rec()throws Exception
	{
                System.out.print("\nEnter Roll Number= ");
                int rno=Integer.parseInt(br.readLine());

                ps=con.prepareStatement("select * from student where rno=?");   ps.setInt(1,rno);
                rs=ps.executeQuery();
                int f=0;
                while(rs.next()){f=1;}
                if(f==0)
                {
                        System.out.println("\nNo records found for student having roll number "+rno);
                        return;
                }
                else
                {
                        ps=con.prepareStatement("delete from student where rno=?");
                        ps.setInt(1,rno);
                        int i=ps.executeUpdate();
                        if(i>0)
                                System.out.println("\nRecord Deleted Successfully!!");
                }
                rs.close();     ps.close();
	}//delete_rec

	void search()throws Exception
	{
	        System.out.print("\nEnter Roll Number= ");
                int rno=Integer.parseInt(br.readLine());

                ps=con.prepareStatement("select * from student where rno=?");   ps.setInt(1,rno);
                rs=ps.executeQuery();
                int f=0;
                while(rs.next())
		{
			f=1;
			System.out.println("\nRoll Number= "+rs.getString(1)+"\nName= "+rs.getString(2)+"\nPercentage= "+rs.getString(3));
		}
                if(f==0)
                {
                        System.out.println("\nNo records found for student having roll number "+rno);
                        return;
                }
		rs.close();	ps.close();
	}//search

	void viewAll()throws Exception
	{
		ps=con.prepareStatement("select * from student");
                rs=ps.executeQuery();
                int f=0;
                while(rs.next())
                {
                        f=1;
                        System.out.println("\nRoll Number= "+rs.getString(1)+"\nName= "+rs.getString(2)+"\nPercentage= "+rs.getString(3));
                }
                if(f==0)
                {
                        System.out.println("\nNo records found");
                        return;
                }
		rs.close();	ps.close();
	}


	public static void main(String args[])throws Exception
	{
		int ch;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		MenuDriven ob=new MenuDriven();
		while(true)
		{
			System.out.print("1.Insert\n2.Modify\n3.Delete\n4.Search\n5.View All\n6.Exit\nEnter tour choice= ");
			ch=Integer.parseInt(br.readLine());
			switch(ch)
			{
				case 1:
					ob.insert();	break;
				case 2:
					ob.modify();	break;
				case 3:
					ob.delete_rec();	break;
				case 4:
					ob.search();	break;
				case 5:
					ob.viewAll();	break;
				case 6:
					ob.rs.close();
					ob.ps.close();
					ob.con.close();
					System.exit(0);
				default:
					System.out.println("\nInvalid choice");
			}
		}
		
		
	}
}//MenuDriven
