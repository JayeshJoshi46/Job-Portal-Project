create table phone(name varchar(20),address varchar(20),phone int primary key,email varchar(20));

insert into phone values(shivani,pune,9623425005,shivanikajave@gmail.com);
insert into phone values(anita,angvi,8087245247,shivan@gmail.com);



