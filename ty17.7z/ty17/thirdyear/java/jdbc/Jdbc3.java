import java.io.*;
import java.sql.*;

class Jdbc3
{
        public static void main(String args[]) throws Exception
        {
                Class.forName("org.postgresql.Driver");
                Connection con=DriverManager.getConnection("jdbc:postgresql://192.168.16.1:5432/ty17","ty17","");
                Statement s=con.createStatement();


                ResultSet rst=s.executeQuery("select * from student");
		ResultSetMetaData rsmd=rst.getMetaData();
		
		int c=rsmd.getColumnCount();
                System.out.println("\nNumber of columns="+c);
		System.out.println("\n\nColumn No ColumnName ColumnType ColumnDisplaySize\n");
		for(int i=1;i<=c;i++)
		{
			System.out.println(i + "\t");
                        System.out.println(rsmd.getColumnName(i)+"\t");
                        System.out.println(rsmd.getColumnType(i)+"\t");
                        System.out.println(rsmd.getColumnDisplaySize(i)+"\n");
		}
		System.out.println("\n\n");
                rst.close();
		s.close();
		con.close();
        }
}                                                                 
