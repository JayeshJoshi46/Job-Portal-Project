create table student(rno int primary key,name varchar[30],percentage numeric(6,3));

\d student

insert into student values(1,"Hussu",89);
insert into student values(2,"shiv",80);
insert into student values(3,"anni",85);
insert into student values(4,"manjiri",82);
insert into student values(5,"meeta",81);

select * from student;


