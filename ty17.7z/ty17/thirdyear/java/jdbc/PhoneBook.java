import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

class PhoneBook extends JFrame implements ActionListener
{

	JLabel l_name,l_phone,l_addr,l_email;
	JTextField t_name,t_phone,t_addr,t_email;
	JButton b_back,b_next,b_delete,b_update,b_exit;
	Connection con;
	PreparedStatement ps;
	Statement s;
	ResultSet rs,rs1,rs2;
	int flag1,flag2;
	PhoneBook()
	{
		setLayout(null);

		l_name=new JLabel("Name");
		l_name.setBounds(80,30,200,30);
		add(l_name);

                l_phone=new JLabel("Phone");
                l_phone.setBounds(80,110,200,30);
                add(l_phone);

                l_addr=new JLabel("Address");
                l_addr.setBounds(80,70,200,30);
                add(l_addr);

                l_email=new JLabel("E-mail");
                l_email.setBounds(80,150,200,30);
                add(l_email);

		t_name=new JTextField();
		t_name.setBounds(200,30,200,30);	add(t_name);

		t_addr=new JTextField();
		t_addr.setBounds(200,70,200,30);        add(t_addr);

		t_phone=new JTextField();
		t_phone.setBounds(200,110,200,30);      add(t_phone);
		/*t_phone.addKeyListener(new KeyAdapter()
		{
			public void keyTyped(keyEvent ke)
			{
				char c=ke.getKeyChar();
				if(!c.isDigit() || c!='\b')
				{
					JOptionPane.showMessageDialog(null,"Phone number must be digit");
					ke.setKeyChar('\b');
				}
			}
		});*/

		t_email=new JTextField();
		t_email.setBounds(200,150,200,30);	add(t_email);


		b_back=new JButton("<<");
		b_back.setBounds(20,220,100,30);	add(b_back);	b_back.addActionListener(this);
		flag1=0;

                b_delete=new JButton("Delete");
		b_delete.setBounds(140,220,100,30);        add(b_delete);	b_delete.addActionListener(this);

                b_update=new JButton("Update");
		b_update.setBounds(260,220,100,30);        add(b_update);	b_update.addActionListener(this);

                b_next=new JButton(">>");
		b_next.setBounds(380,220,100,30);        add(b_next);		b_next.addActionListener(this);
		flag2=0;

                b_exit=new JButton("Exit");
		b_exit.setBounds(500,220,100,30);        add(b_exit);		b_exit.addActionListener(this);

		try
		{
			Class.forName("org.postgresql.Driver");
			con=DriverManager.getConnection("jdbc:postgresql://192.168.16.1:5432/ty18","ty18","");
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}

		setVisible(true);
		setSize(800,500);
		setLocation(100,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Phone Book");
	}//Constructor

	public void actionPerformed(ActionEvent ae)
	{

		if(t_name.getText()==null)
		{
			JOptionPane.showMessageDialog(null,"Name cannot be null");	return;
		}


		if(ae.getActionCommand().equals("<<"))
		{
			try
			{
				if(flag1==0)
				{
					s=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					rs1=s.executeQuery("select * from phone_book");
					flag1=1;
					rs1.last();
					t_name.setText(rs1.getString(1));
					t_addr.setText(rs1.getString(2));
					t_phone.setText(rs1.getString(3));
					t_email.setText(rs1.getString(4));
				}
				else
				{
					rs1.previous();
					t_name.setText(rs1.getString(1));
                                        t_addr.setText(rs1.getString(2));
                                        t_phone.setText(rs1.getString(3));
                                        t_email.setText(rs1.getString(4));
				}
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,e);
			}
		}//prev


		if(ae.getActionCommand().equals("Delete"))
		{
			try
                        {
                                ps=con.prepareStatement("delete from phone_book where phone=?");
				ps.setString(1,t_phone.getText());
				int i=ps.executeUpdate();
				if(i>0)
				{
					JOptionPane.showMessageDialog(null,"Record Deleted Successfully!!");
				}
                        }
                        catch(Exception e)
                        {
                                JOptionPane.showMessageDialog(null,e);
                        }

		}//delete

		if(ae.getActionCommand().equals("Update"))
                {
                        try
                        {
                                ps=con.prepareStatement("update phone_book set name=?,address=?,phone=?,email=? where phone=?");
				ps.setString(1,t_name.getText());
				ps.setString(2,t_addr.getText());
                                ps.setString(3,t_phone.getText());
				ps.setString(4,t_email.getText());
				ps.setString(5,t_phone.getText());
                                int i=ps.executeUpdate();
                                if(i>0)
                                {
                                        JOptionPane.showMessageDialog(null,"Record Updated Successfully!!");
                                }
                        }
                        catch(Exception e)
                        {
                                JOptionPane.showMessageDialog(null,e);
                        }

                }//update

		if(ae.getActionCommand().equals(">>"))
                {
                        try
                        {
				if(flag2==0)
				{
                               		s=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
	                                rs2=s.executeQuery("select * from phone_book");
					flag2=1;
					rs2.first();
					t_name.setText(rs2.getString(1));
                                        t_addr.setText(rs2.getString(2));
                                        t_phone.setText(rs2.getString(3));
                                        t_email.setText(rs2.getString(4));
				}
				else
				{
					rs2.next();
					t_name.setText(rs2.getString(1));
                                        t_addr.setText(rs2.getString(2));
                                        t_phone.setText(rs2.getString(3));
                                        t_email.setText(rs2.getString(4));

				}
                        }
                        catch(Exception e)
                        {
                                JOptionPane.showMessageDialog(null,e);
                        }
                }//prev

		if(ae.getActionCommand().equals("Exit"))
                {
                        try
                        {
				rs.close();	ps.close();	/*s.close();*/	con.close();
				System.exit(0);
                        }
                        catch(Exception e)
                        {
                                //JOptionPane.showMessageDialog(null,e);
                        }

                }//exit
	
	}//actionPerformed

	public static void main(String args[])
	{
		new PhoneBook();
	}//main
}//PhoneBook
