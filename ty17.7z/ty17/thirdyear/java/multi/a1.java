/*Shivani Kajave
  Roll no 17
  Div A
  MultiThreading q 1*/

class Mythread extends Thread
{
	String message;
	Mythread(String message)
	{
		this.message=message;
	}
	public void run()
	{
		 try
		 {
			for( ; ;)
			{
			     System.out.println(message);
			     Thread.sleep(1000);
			}
		}
		catch(InterruptedException ie)
		{
		}
	}
}

public class a1
{
	public static void main(String[] args)
	{
		Mythread t1=new Mythread("HI");
		Mythread t2=new Mythread("BYE");
		
                t1.start();
		t2.start();
        }
}

