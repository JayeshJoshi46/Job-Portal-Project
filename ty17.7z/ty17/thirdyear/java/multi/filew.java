/*Shivani Kajave. Roll no 17. DIv A. Multithreading setc 1*/

import java.io.*;

class filew extends Thread
{
	File fp;
	filew(String f)
	{
		fp=new File(f);
	}

	public void run()
	{
		try
		{
			if(fp.exists())
			{
				if(fp.isFile())
				{
					System.out.println("\n"+fp.getName()+"is a file");
				}
			}
			else
			{
				sleep(5000);
			}
		}	
		catch(Exception e)
		{
			System.out.println("\n Exception:"+e);
		}
	}

	public static void main(String args[]) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int i,n;
		System.out.println("How many files?");
		n=Integer.parseInt(br.readLine());

		filew t[]=new filew[n];
		for(i=0;i<n;i++)
		{
			System.out.println("\n\n Enter a filename:");
			String f=br.readLine();
			t[i]=new filew(f);
			t[i].start();
			sleep(100);
		}
	}
}
