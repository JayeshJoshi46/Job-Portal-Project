/*Shivani Kajave
  Roll no 17
  Div A
  Multithreading seta q2)
*/
import java.util.Random;
public class AverageCal extends Thread
{       int nos;
        static int i;
	static int sum=0,total=0,n=0;
        int NosIntoArray[]=new int[100];

	public void run()
	{    
		try
		{
	
			for(i=0;i<100 && n<=1000;i++,n++)
			{
				Random rand=new Random();
				nos=rand.nextInt(99);
                     		NosIntoArray[i]=nos;
				total+=NosIntoArray[i];
			}
	  }
	catch(Exception e)
		{
		}
	
          }	
	    
        public static void main(String args[])
	{
          Thread t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
          
          t1=new AverageCal();
	  t1.start();
	  
	  t2=new AverageCal();
	  t2.start();

          t3=new AverageCal();
          t3.start();

          t4=new AverageCal();
          t4.start();

          t5=new AverageCal();
          t5.start();

          t6=new AverageCal();
          t6.start();

          t7=new AverageCal();
          t7.start();

          t8=new AverageCal();
          t8.start();

          t9=new AverageCal();
          t9.start();

          t10=new AverageCal();
          t10.start();
           
           System.out.println("Sum is="+total);
           sum=sum+total;

            System.out.println("Average is="+sum/10);
         }
}
