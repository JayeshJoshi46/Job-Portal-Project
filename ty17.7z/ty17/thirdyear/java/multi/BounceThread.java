/*Shivani kajave Assn 5 set b 2*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.geom.*;
public class BounceThread
{
	public static void main(String args[])
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				JFrame frame=new BounceFrame();
				frame.setLocationRelativeTo(null);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}

class BounceFrame extends JFrame
{
	private BallComponent comp;
	public static final int DEFAULT_WIDTH=450;
	public static final int DEFAULT_HIEGHT=350;
	public static final int START=1000;
	public static final int DELAY=3;
	int x1 = 0;
	int c = -1;
	
	public BounceFrame()
	{
		setSize(DEFAULT_WIDTH,DEFAULT_HIEGHT);
		setTitle("BounceThread");
		comp=new BallComponent();
		add(comp,BorderLayout.CENTER);
		JPanel buttonPanel=new JPanel();
		addButton(buttonPanel,"Start",new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				addBall();
			}
		});
		addButton(buttonPanel,"Close",new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				System.exit(0);
			}
		});
		add(buttonPanel,BorderLayout.SOUTH);
	}
	public void addButton(Container c,String title,ActionListener listener)
	{
		JButton button=new JButton(title);
		c.add(button);
		button.addActionListener(listener);
	}
	public void addBall()
	{
		x1+=50;
		System.out.println(x1);
		Ball b=new Ball(x1,selectColor());
		comp.add(b);
		Runnable r=new BallRunnable(b,comp);
		Thread t=new Thread(r);
		t.start();
	}
	// Thread for ball
	
	private Color selectColor() {
		c++;
		switch(c) {
		case 0:
			return (Color.MAGENTA);
		case 1:
			return(Color.BLUE);
		case 2:
			return(Color.GREEN);
		case 3:
			return(Color.RED);
		case 4:
			return(Color.ORANGE);
		case 5:
			return(Color.YELLOW);
		case 6:
			return(Color.CYAN);
		case 7:
			return(Color.DARK_GRAY);
		default:
			return(Color.BLACK);
		}
	}

	class BallRunnable implements Runnable
	{
		private Ball ball;
		private Component component;
		public static final int DELAY=5;
		
		public BallRunnable(Ball aBall,Component aComponent)
		{
			ball=aBall;
			component=aComponent;
		}
		public void run()
		{
			try
			{
				while(true)
				{
					ball.move(component.getBounds());
					component.repaint();
					Thread.sleep(DELAY);
				}
			}
			catch(InterruptedException e)
			{
			}
		}
	}
}
class Ball
{
	private static final int XSIZE=15;
	private static final int YSIZE=15;
	private double x=0;
	private double y=0;
	private double dy=1;
	private Color color;
	
	
	public int getX() {
		return (int) x;
	}
	
	public int getY() {
		return (int) y;
	}
	public static int getYsize() {
		return YSIZE;
	}
	public static int getXsize() {
		return XSIZE;
	}
	
	public Ball(int x,Color color){
		this.x = x;
		this.color = color;
		//while(((y = (int)(Math.random()*400)) < 10) && ((y = (int)(Math.random()*400)) > 500));
	}
	
	public void move(Rectangle2D bounds)
	{
		y+=dy;
		if(y<bounds.getMinY())
		{
			y=bounds.getMinY();
			dy=-dy;
		}
		if(y+YSIZE>=bounds.getMaxY())
		{
			//x=bounds.getMaxY()-YSIZE;
			dy=-dy;
		}
	}
	public Ellipse2D getShape()
	{
		return new Ellipse2D.Double(x,y,XSIZE,YSIZE);
	}

	public Color getColor() {
		return color;
	}
}
class BallComponent extends JPanel
{
	private ArrayList<Ball> balls=new ArrayList<Ball>();
	public void add(Ball b)
	{
		balls.add(b);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D)g;
		for(Ball b:balls)
		{
			//g2.fill(b.getShape());
			g2.fillOval(b.getX(), b.getY(), b.getXsize(), b.getYsize());
			g2.setColor(b.getColor());

		}
	}
	
}

