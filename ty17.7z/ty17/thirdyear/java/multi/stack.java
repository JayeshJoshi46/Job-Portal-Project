/*Shivani Kajave. Roll no 17. Div A. MUltithreading setc 1*/

import java.io.*;

interface Stack
{
	public void push(int d);
	public void pop();
}

class StackImplementation implements Stack
{
	int Stack[],top,max;
	StackImplementation()
	{
		Stack=new int[5];
		top=-1;
		max=5;
	}
	public void push(int d)
	{
		if(top<max)
			Stack[++top]=d;
		else
			System.out.println("\n Stack full");
	}
	public void pop()
	{
		if(top>=0)
			System.out.println("\n Popped element:"+Stack[top--]);
		else
			System.out.println("\n Stack is empty:");
	}
}

class PopThread extends StackImplementation implements Runnable
{
	StackImplementation ob1;
	PopThread(StackImplementation t)
	{
		ob1=t;
	}
	synchronized public void run()
	{
		try
		{
			while(true)
			{
				ob1.pop();
				Thread.sleep(3000);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception is:"+e);
		}
	}
}

class stack extends StackImplementation implements Runnable
{
	StackImplementation ob;
	int i;
	stack(StackImplementation t) 
	{
		ob=t;
		i=1;
	}
	synchronized public void run()
	{
		try
		{
			while(true)
			{
				System.out.println("pushed element is :"+i);
				ob.push(i++);
				Thread.sleep(2000);
			}
		}
		catch(Exception e)
		{
			System.out.println("\n\n Exception push:"+e);
		}
	}
		public static void main(String args[])
		{
			StackImplementation ob=new StackImplementation();
			stack t1=new stack(ob);
			stack t2=new stack(ob);
			PopThread t3=new PopThread(ob);

			Thread tob1=new Thread(t1);
			Thread tob2=new Thread(t2);
			Thread tob3=new Thread(t3);

			tob1.start();
			tob2.start();
			tob3.start();
		}
	}

