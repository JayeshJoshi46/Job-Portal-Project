import java.io.*;

class a3 extends Thread
{
	String word,name;
        int cnt=0;	
	a3(String word,String name)
	{
		this.word=word;
		this.name=name;
	}
	public void run()
	{
		String str;
                cnt=0;
		boolean done=false;
		try
		{
			BufferedReader br=new BufferedReader(new FileReader(name));
			while(((str=br.readLine())!=null)&&done==false)
			{
                                cnt++;
				if(str.equals(word))
 				{
					System.out.println("Word found on line:"+cnt+"\nWord found in File:"+name);
					done=true;
				}
                                
                       }
		}
		catch(Exception e)
		{
		}
	}

	public static void main(String args[]) throws Exception
	{
		File f1=new File(".");
		System.out.println("Enter a string");
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		String str=br1.readLine();

		String []l=f1.list();
		a3 readThread[]=new a3[l.length];
		int j=0;
		for(int i=0;i<l.length;i++)
		{
			File f=new File(l[i]);
			if(f.isFile()&&l[i].endsWith("txt"))
			{
				readThread[j]=new a3(str,l[i]);
				readThread[j++].start();
			}
		}
	}
}
