/*Shivani kajave. Ass 6. set B 3*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

class Registration extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField tf1,tf2,tf3,tf4;
	JButton b1;
	JPasswordField p1,p2;
	int pick;
	int pick1[]=new int[2];

	Registration()
	{
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		l1=new JLabel("Registration Form",JLabel.CENTER);
		l2=new JLabel("Name");
		l3=new JLabel("Login Name");
		l4=new JLabel("Password");
		l5=new JLabel("Confirm Password");
		l6=new JLabel("Captcha");
		tf1=new JTextField();
		tf2=new JTextField();
		p1=new JPasswordField();
		p2=new JPasswordField();
		tf3=new JTextField();
		tf4=new JTextField();
		b1=new JButton("SUBMIT");
		b1.addActionListener(this);
		l1.setBounds(100,30,400,30);
		l2.setBounds(80,70,200,30);
		l3.setBounds(80,110,200,30);
		l4.setBounds(80,150,200,30);
		l5.setBounds(80,190,200,30);
		l6.setBounds(80,230,200,30);
		tf1.setBounds(300,70,200,30);
		tf2.setBounds(300,110,200,30);
		p1.setBounds(300,150,200,30);
		p2.setBounds(300,190,200,30);
		tf3.setBounds(300,230,90,30);
		tf4.setBounds(390,230,100,30);
		b1.setBounds(250,270,100,30);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(l6);
		add(tf1);
		add(tf2);
		add(tf3);
		add(tf4);
		add(p1);add(p2);
		add(b1);

		Random rand=new Random();
		String s="";
		for(int i=0;i<2;i++)
		{
			pick=rand.nextInt(9);
			pick1[i]=pick;
			s+=pick+" ";
			if(i==0)
				s+="+";
			if(i==1)
				s+="=";
			tf3.setText(s);
		}

		setSize(500,500);
		setTitle("Registration Form");
		setVisible(true);
	}//constructor

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			int x=0,i;
			char s3[]=p1.getPassword();
			char s4[]=p1.getPassword();
			String s1=new String(s3);
			String s2=new String(s4);

			if(!s3.equals(s4))
			{
				p1.setText(null);
				p2.setText(null);
			}
                        

			String test=tf4.getText();
			int test_no=Integer.parseInt(test);
			if(test_no!=(pick1[0]+pick1[1]))
			{
				tf4.setText(null);
			}

		}
	}//actionPerformed

	public static void main(String args[])
	{
		new Registration();
	}
}//Registration
