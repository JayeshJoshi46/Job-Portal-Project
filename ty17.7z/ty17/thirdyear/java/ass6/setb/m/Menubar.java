/* 6 setb 2 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
import java.io.*;

class Menubar extends JFrame
{
	int pick;
	int pick1[]=new int[50];
	JMenuBar m;
	JLabel l;
	JMenu me1,me2,me3,me4;
	JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9;
	JRadioButtonMenuItem c1,c2;
	JTextArea tf;

	Menubar()
	{
		setLayout(null);
		tf=new JTextArea(5,10);
		tf.setBounds(20,190,350,100);
		m=new JMenuBar();
		m.setBounds(0,0,400,30);
		me1=new JMenu("File");
		m1=new JMenuItem("Load");
		m2=new JMenuItem("Save");
		me1.add(m1);
		me2=new JMenu("Compute");
		me2.add(m2);
		me1.addSeparator();
		m3=new JMenuItem("Exit");
		me1.add(m3);
		//me2=new JMenu("Compute");
		m4=new JMenuItem("Sum");
		m5=new JMenuItem("Average");
		m6=new JMenuItem("MAximum");
		m7=new JMenuItem("Minimum");
		m8=new JMenuItem("Median");
		me2.add(m4);
		me2.add(m5);
		me2.add(m6);
		me2.add(m7);
		me2.add(m8);
		me3=new JMenu("Operations");
		m9=new JMenuItem("Search");
		me4=new JMenu("Sort");
		c1=new JRadioButtonMenuItem("Ascending");
		c2=new JRadioButtonMenuItem("Descending");
		me4.add(c1);
		me4.add(c2);
		me3.add(m9);
		me3.add(me4);

		m.add(me1);
		m.add(me2);
		m.add(me3);
		add(m);
		l=new JLabel("Numbers");
		l.setBounds(20,130,100,100);
		add(l);
		add(tf);
		setSize(400,350);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		m1.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				Random rand=new Random();
				String s=" ";
				for(int i=0;i<50;i++)
				{
					pick=rand.nextInt(99);
					pick1[i]=pick;
					s+=pick+" , ";
					tf.setText(s);
					if((i+1)%10==0)
						s+="\n";
				}	
			}
		});

		m2.addMouseListener(new MouseAdapter(){
                        public void mousePressed(MouseEvent me)
                        {
				try
				{
					int i;
					String file1=JOptionPane.showInputDialog("Enter File name u want to save in");
					BufferedWriter out=new BufferedWriter(new FileWriter(file1));
					for(i=0;i<50;i++)
					{
						out.write(pick1[i]+",");
						if((i+1)%10==0)
							out.write("\n");
					}
					out.close();
				}
				catch(Exception e)
				{
				}
                        }
                });

		

		m3.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				System.exit(0);
			}
		});

		m4.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int sum=0;
				for(int i=0;i<50;i++)
				{
					sum+=pick1[i];
				}
				tf.setText("Sum is: "+sum);
			}	
		});

		m5.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int sum=0;
				for(int i=0;i<50;i++)
					sum+=pick1[i];
				float avg=sum/50;
				tf.setText("Average is: "+avg);
			}
		});

		m6.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int max=0;
				for(int i=0;i<50;i++)
				{
					if(max<pick1[i])
						max=pick1[i];
				}
				tf.setText("Max is: "+max);
			}
		});

		m7.addMouseListener(new MouseAdapter(){
		public void mousePressed(MouseEvent me)
		{
			int min=1000;
			for(int i=0;i<50;i++)
			{
				if(min>pick1[i])
					min=pick1[i];
			}
			tf.setText("Min is: "+min);
		}
		});

		m8.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int i,j,temp,med=0;
				String s=" ";
				for(i=49;i>0;i--)
				{
					for(j=0;j<i;j++)
					{
						if(pick1[j]>pick1[j+1])
						{
							temp=pick1[j];
							pick1[j]=pick1[j+1];
							pick1[j+1]=temp;
						}
					}
				}
				i=(50/2)+1;
				med=pick1[i];

				tf.setText("Median is: "+med);
			}
		});

		m9.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int i;
				String number=JOptionPane.showInputDialog("Enter the number you want to search");
				int no=Integer.parseInt(number);
				for(i=0;i<50;i++)
				{
					if(pick1[i]==no)
					{
						tf.setText("Number is present and found at "+(i+1)+" position");
						break;
					}
				}
				if(i==50)
					tf.setText("Number not found");
			}
		});

		c1.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent me)
			{
				int i,j,temp;
				String s=" ";
				for(i=49;i>0;i--)
				{
					for(j=0;j<i;j++)
					{
						if(pick1[j]>pick1[j+1])
						{
							temp=pick1[j];
							pick1[j]=pick1[j+1];
							pick1[j+1]=temp;
						}
					}
				}
				for(i=0;i<50;i++)
				{
					s+=pick1[i]+" , ";
					tf.setText(s);
					if((i+1)%10==0)
						s+="\n";
				}
			}
		});

		c2.addMouseListener(new MouseAdapter(){
                        public void mousePressed(MouseEvent me)
                        {
                                int i,j,temp;
                                String s=" ";
                                for(i=49;i>0;i--)
                                {
                                        for(j=0;j<i;j++)
                                        {
                                                if(pick1[j]<pick1[j+1])
                                                {
                                                        temp=pick1[j];
                                                        pick1[j]=pick1[j+1];
                                                        pick1[j+1]=temp;
                                                }
                                        }
                                }
                                for(i=0;i<50;i++)
                                {
                                        s+=pick1[i]+" , ";
                                        tf.setText(s);
                                        if((i+1)%10==0)
                                                s+="\n";
                                }
                        }
                });

	}

	public static void main(String s[])
	{
		new Menubar();
	}

}//Menubar
