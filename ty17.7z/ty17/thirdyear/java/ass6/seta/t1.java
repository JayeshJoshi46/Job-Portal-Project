/*Shivani kajave. Ass 6. set A 2*/
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;


class frame2 extends JFrame implements ActionListener,ItemListener
{
 JFrame f;
 JLabel l1,l2,l3,l4,l5,l6;
 JTextField t1,t2,t3,t4;
 JRadioButton r1,r2,r3;
 JCheckBox c1,c2,c3;
 JPanel p1,p2,p3,p4;
 ButtonGroup bg;
 
 frame2()
 {
  f=new JFrame("User INformation");
  f.setBounds(400,400,400,400);
  
  p1=new JPanel();
  f.add(p1,BorderLayout.NORTH);
  t1=new JTextField(30);
  l1=new JLabel("Your Name");
  p1.add(l1);
  p1.add(t1);
 
  l2=new JLabel("Your Class");
  r1=new JRadioButton("FY");
  r2=new JRadioButton("SY");
  r3=new JRadioButton("TY");
  bg=new ButtonGroup();
  bg.add(r1);
  bg.add(r2);
  bg.add(r3);
  
  l3=new JLabel("Your Hobbies");
  c1=new JCheckBox("Music");
  c2=new JCheckBox("Dance");
  c3=new JCheckBox("Sports");
  p2=new JPanel();
  p2.setLayout(new GridLayout(4,2));
  f.add(p2);
  p2.add(l2);
  p2.add(l3);
  p2.add(r1);
  p2.add(c1);
  p2.add(r2);
  p2.add(c2);
  p2.add(r3);
  p2.add(c3);
  
  l4=new JLabel("Name");
  l5=new JLabel("Class");
  l6=new JLabel("Hobbies");
  t2=new JTextField(20);
  t3=new JTextField(20);
  t4=new JTextField(20);
  p3=new JPanel();
  f.add(p3,BorderLayout.SOUTH);
  p3.add(l4);
  p3.add(t2);
  p3.add(l5);
  p3.add(t3);
  p3.add(l6);
  p3.add(t4);
 
  r1.addActionListener(this);
  r2.addActionListener(this);
  r3.addActionListener(this);
  c1.addItemListener(this);
  c2.addItemListener(this);
  c3.addItemListener(this);
  
  t1.addKeyListener(new KeyAdapter()
  {
   public void keyReleased(KeyEvent e)
   {
    t2.setText(t1.getText());
   }
  });
  
  f.setVisible(true); 
  f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 }
 
 public void actionPerformed(ActionEvent e)
 {
  if(e.getSource()==r1||e.getSource()==r2||e.getSource()==r3)
  t3.setText(e.getActionCommand());
 }

 public void itemStateChanged(ItemEvent e)
 {
  String text="";
  if(c1.isSelected())
  text=text+c1.getText();
  if(c2.isSelected())
  text=text+c2.getText();
  if(c3.isSelected())
  text=text+c3.getText()+",";
  t4.setText(text);
 }
 
 public static void main(String args[])
 {
  frame2 obj=new frame2();
 }
}
  
