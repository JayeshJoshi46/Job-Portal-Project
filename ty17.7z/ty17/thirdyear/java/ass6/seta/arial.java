/*Shivani kajave. Ass 6. set A 1*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class GUI extends JFrame implements ItemListener
{
	JFrame f;
	JLabel l1,l2,l3;
	JTextField t1;
	JComboBox c1,c2;
	JCheckBox j1,j2,j3;
	JPanel p1,p2,p3;
	GUI()
	{
		f=new JFrame("Font Change");
		f.setBounds(400,400,400,400);
		f.setVisible(true);
		p1=new JPanel(new GridLayout(4,2,30,30));
		f.add(p1,BorderLayout.CENTER);

		l1=new JLabel("Font");
		l2=new JLabel("Style");
		l3=new JLabel("Size");
		

		c1=new JComboBox();
		c1.addItem("Utopia");
		c1.addItem("Monospace");

		c2=new JComboBox();
		c2.addItem("10");
		c2.addItem("20");

		j1=new JCheckBox("Bold");
		j2=new JCheckBox("Italic");
		j3=new JCheckBox("Underline");

		p1.add(l1);
		p1.add(l2);
		p1.add(c1);
		p1.add(j1);
		p1.add(l3);
		p1.add(j2);
		p1.add(c2);
		p1.add(j3);
		p2=new JPanel(new FlowLayout());
		f.add(p2,BorderLayout.SOUTH);
		t1=new JTextField(30);
		p2.add(t1);
                f.pack();
		j1.addItemListener(this);
		j2.addItemListener(this);
		j3.addItemListener(this);
		f.pack();
		
	}
	public void itemStateChanged(ItemEvent ie)
	{
          String s1=(String)c1.getSelectedItem();
          String s2=(String)c2.getSelectedItem();
             int no=Integer.parseInt(s2);
         if(j1.isSelected())
         {
          Font f=new Font(s1,Font.BOLD,no);
          String temp=t1.getText();
          t1.setFont(f);
          t1.setText(temp);
	}
        if(j2.isSelected())
        {
          Font f=new Font(s1,Font.ITALIC,no);
          String temp=t1.getText();
          t1.setFont(f);
          t1.setText(temp);
	}
      

       }
	public static void main(String args[])
	{
		GUI o=new GUI();
	}
}
