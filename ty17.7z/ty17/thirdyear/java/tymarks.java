/*Shivani kajave. Roll no17.Div A.Ass 2 Set B ty MARKS*/
package TY;
import java.io.*;
 
public class tymarks
{
 public int theory;
 public int practical;
 
 public tymarks()
 {
  theory=0;
  practical=0;
 }
 
 public tymarks(int t,int p)
 {
  theory=t;
  practical=p;
 }

 public void accept()
 {
  try
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    System.out.println("Enter theory marks=");
    theory=Integer.parseInt(br.readLine());
   System.out.println("Enter practical marks=");
    practical=Integer.parseInt(br.readLine());
  }
  catch(IOException e) 
  {
  }
 }
 
  public String toString()
 {
  return theory + "," + practical;
 }
}
