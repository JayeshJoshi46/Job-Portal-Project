 
class MyNumber
 {
  private int num;
  
  MyNumber()
  {
   num=0;
  }
 
  MyNumber(int num)
  {
   this.num=num;
  }
 
 void isNegative(int n)
  {
   if(n<0)
   {
    System.out.println("The Number is Negative.");
   }
  }

 void isPositive(int n)
  {
   if(n>0)
    {
     System.out.println("The Number is Postive.");
    }
  }
 
 void isZero(int n)
  {
   if(n==0)
    {
     System.out.println("The Number is zero");
    }
  }

 void isEven(int n)
  {
   if(n%2==0)
    {
    System.out.println("The number is even.");
    }
  }
 
 void isOdd(int n)
  {
   if(n%2!=0)
    {
     System.out.println("The number is Odd.");
    }
  }

public static void main(String args[])
  {
//   MyNumber object=new MyNumber();
   int n=Integer.parseInt(args[0]);
   MyNumber object=new MyNumber();

   object.isNegative(n);
   object.isPositive(n);
   object.isZero(n);
   object.isEven(n);
   object.isOdd(n);
  }
 }
   
