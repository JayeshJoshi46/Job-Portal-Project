import java.util.Date;
import java.text.SimpleDateFormat;


class date_p
 {
  public static void main(String args[])
  {
   Date d=new Date();
   SimpleDateFormat dmy=new SimpleDateFormat("dd/MM/yyyy");
   String str=dmy.format(d);
   
   System.out.println("Current date is:"+str);
   System.out.println("Current date is:"+new SimpleDateFormat("MM/dd/yyyy").format(d));
   System.out.println("Current date is:"+new SimpleDateFormat("EEEE MMMM dd/yyyy").format(d));
   System.out.println("The Current date is:"+d);
   System.out.println("The Current date and time is:"+new SimpleDateFormat("dd/MM/yy HH:mm:ss a Z").format(d));
   System.out.println("The Current Time is:"+new SimpleDateFormat("HH:mm:ss").format(d));
   System.out.println("The Current week of the year is:"+new SimpleDateFormat("w").format(d));
   System.out.println("The Current week of the Month is:"+new SimpleDateFormat("W").format(d));
   System.out.println("The Current day of the Year is:"+new SimpleDateFormat("D").format(d));
}
}    
