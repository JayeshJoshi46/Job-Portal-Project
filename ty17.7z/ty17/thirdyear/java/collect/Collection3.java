/*Shivani Kajave
 *   Collection
 *     Set A q3*/

import java.util.*;
import java.io.*;

class Collection3
{
	Hashtable <String,Double>ht;
	
	Collection3()
	{
		ht=new  Hashtable<String,Double>();
	}
	
	void add() throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter name=");
		String name=br.readLine();
		System.out.println("Enter percentage=");
		Double per=Double.parseDouble(br.readLine());
		ht.put(name,per);
		
	}
	void display()
	{
		System.out.println("Name\tPercentage");
		Enumeration k=ht.keys();
		while(k.hasMoreElements())
		{
			String name=(String)k.nextElement();
			System.out.println(name+"\t"+ht.get(name));
		}
	}
	void search(String sname)
	{
		 Enumeration k=ht.keys();
                while(k.hasMoreElements())
                {
		 	String name=(String)k.nextElement();
			if(name.equals(sname))
			{
				System.out.println("\nRecord found");
				 System.out.println(name+"\t"+ht.get(name));
                	return;
			}
		//	return;
		}
		System.out.println("\nRecord not found");
	}
	
	public static void main(String args[]) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nHow many records:");
		int n=Integer.parseInt(br.readLine());

		Collection3 c=new Collection3();
		for(int i=0;i<n;i++)
			c.add();
			c.display();
			System.out.println("\n\nEnter Student's name to search=");
		
			String name=br.readLine();
			c.search(name);
	}
}
