/*Shivani Kajave
  Collection
  Set A q1*/

import java.util.*;
import java.io.*;

class Collection1
{
	public static void main(String args[]) throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nHow many numbers:");
		int n=Integer.parseInt(br.readLine());

		ArrayList<Integer>aob=new ArrayList<Integer>();
		for(int i=1;i<=n;i++)
		{
			System.out.println("\n\nEnter the number=");
			int num=Integer.parseInt(br.readLine());

			if(aob.contains(num))
			{
				System.out.println("\n"+num+"is already present");
				i--;
			}
			else
				aob.add(num);
		}
		System.out.println("\n\nBefore sorting arraylist:"+aob);
		
		Collections.sort(aob);
		System.out.println("\n\nAfter sorting arraylist:"+aob);
		System.out.println("\nEnter a number to search:");
		n=Integer.parseInt(br.readLine());
		
		int i=Collections.binarySearch(aob,n);
		if(i>=0)
		{
			System.out.println("\nNumber"+n+"is found at position"+i);
		}
		else
			System.out.println("\nNumber"+n+"Not found");
	}
}


