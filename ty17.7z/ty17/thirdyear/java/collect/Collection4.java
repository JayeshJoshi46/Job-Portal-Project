/*Shivani Kajave
 *   Collection
 *     Set B q1*/

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;


class Collection4 extends JFrame implements ActionListener
{
	JTable table;
	DefaultTableModel model;
	JScrollPane jsp;
	
	JTextField t_cityname1,t_code,t_cityname2,t_cityname3;
	JButton b_add,b_remove,b_search;

	Hahtable<STring,String>ht;
	
	Collection4()
	{
		setLayout(null);
		t_cityname1=new JTextField("");
		t_cityname1.setBounds(500,50,150,30);
		add(t_cityname1);
		
		t_code=new JTextField("");
		t_code.setBounds(700,50,150,30);
		add(t_code);
		
		 b_add=new JButton("Add");
                b_add.setBounds(620,100,100,30);
                add(b_add);
		b_add.addActionListener(this);
		
		 t_cityname2=new JTextField(""); 
                t_cityname2.setBounds(500,170,150,30);
                add(t_cityname2);

		 t_cityname3=new JTextField(""); 
                t_cityname3.setBounds(700,170,150,30);
                add(t_cityname1);

		b_remove=new JButton("Remove");
		b_remove.setBounds(530,220,100,30);
		add(b_remove);
		b_remove.addActionListener(this);
		
		b_search=new JButton("Search");
                b_search.setBounds(730,220,100,30);
                add(b_search);
                b_search.addActionListener(this);
