
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class b1q1 implements ActionListener 
{
	Hashtable<String, String> hashtable = new Hashtable<String, String>();
		JFrame frame;
		JTextField cityNameAdd , codeAdd , cityNameRemove , cityNameSearch; 
		JButton addButton , removeButton , searchButton; 
		JTextArea textArea;
		JPanel panel1,panel2,panel3,panel4,panel5;
		public b1q1() 
		{
			init();
			add();
			addListener();
		}
		
		public void addListener()
		{
			addButton.addActionListener(this);
			removeButton.addActionListener(this);
			searchButton.addActionListener(this);
		}
		
		public void add()
		{
			frame.add(panel1,BorderLayout.WEST);
			frame.add(panel2,BorderLayout.EAST);
			
			panel1.add(textArea);
			
			panel2.add(cityNameAdd);
			panel2.add(codeAdd);
			panel2.add(addButton);
			panel2.add(cityNameRemove);
			panel2.add(cityNameSearch);
			panel2.add(removeButton);
			panel2.add(searchButton);
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
			frame.pack();
		}
		
		public void init()
		{
			frame = new JFrame("City Application");
			frame.setBounds(400, 400, 400, 400);
			frame.setLayout(new BorderLayout());
			
			cityNameAdd = new JTextField(10);
			cityNameRemove = new JTextField(10);
			cityNameSearch = new JTextField(10);
			codeAdd = new JTextField(10);
			
			addButton = new JButton("ADD");
			addButton.setPreferredSize(new Dimension(200,25));
			removeButton = new JButton("REMOVE");
			searchButton = new JButton("SEARCH");
			
			textArea = new JTextArea(10,20);
			textArea.setEditable(false);
			panel1 = new JPanel(new BorderLayout());
			panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel2.setPreferredSize(new Dimension(300, 200));
			/*panel3 = new JPanel();
			panel4 = new JPanel();
			panel5 = new JPanel();*/
			//panel2 = new JPanel(new BorderLayout());
		}
		
		public void addText(String nameadd , String codeadd)
		{
			hashtable.put(nameadd , codeadd);
			display();
		}
		
		public void removeText(String cityName) 
		{
			if(hashtable.get(cityName) != null) {
				hashtable.remove(cityNameRemove.getText());
				display();
			}
			else JOptionPane.showMessageDialog(new JFrame(),"Not Found..");
		}
		
		private void searchText(String city) {
			if(hashtable.get(city) != null)
				JOptionPane.showMessageDialog(new JFrame(),hashtable.get(city) );
			else
				JOptionPane.showMessageDialog(new JFrame(),"Not Found..");
				
		}
		
		private void display() {
			Enumeration<String> keys = hashtable.keys();
			Enumeration<String> elements = hashtable.elements();
			textArea.setText(" ");
			while(keys.hasMoreElements() && elements.hasMoreElements()){
				String key = keys.nextElement();
				String element = elements.nextElement();
				textArea.append(key);
				textArea.append(" "+element+"\n");
			}
		}

		public void actionPerformed(ActionEvent e)
		{
			if(e.getSource()==addButton){
				String nameadd = cityNameAdd.getText();
				String codeadd = codeAdd.getText();
				
				addText(nameadd,codeadd);
			
			}
			
			else
				if(e.getSource() == removeButton){
					String cityname = cityNameRemove.getText();
					removeText(cityname);
					
			}
			
				else
					if(e.getSource() == searchButton){
						String city = cityNameSearch.getText();
						searchText(city);
					}
			
		}
		
	

	public static void main(String[] args) 
	{
		 new b1q1();
	}

}
