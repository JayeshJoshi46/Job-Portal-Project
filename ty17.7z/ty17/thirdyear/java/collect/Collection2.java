/*Shivani Kajave
 *   Collection
 *     Set A q1*/

import java.util.*;
import java.io.*;

class Collection2
{
	public static void main(String args[]) throws Exception
	{
		LinkedList<String>l1=new LinkedList<String>();
		l1.add("Red");
		l1.add("Blue");
		l1.add("Yellow");
		l1.add("Orange");
		
		ListIterator lr=l1.listIterator();
		System.out.println("Displaying LinkedList in given order:");
		
		while(lr.hasNext())
		{
			System.out.println(lr.next());
		}
		System.out.println("Displaying LinkedList in reverse order:");
		
		while(lr.hasPrevious())
		{
			System.out.println(lr.previous());
		}
		LinkedList<String>l2=new LinkedList<String>();
		l2.add("Pink");
		l2.add("Green");
		System.out.println("\nNew LinkedList is:"+l2);
		
		System.out.println("\nLinkedList1 before insertion is:"+l1);
		
		int i=l1.indexOf("Blue");
		l1.addAll(i+1,l2);
		System.out.println("\nLinkedList1 after insertion is:"+l1);
	}
}


