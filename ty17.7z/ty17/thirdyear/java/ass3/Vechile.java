/*Shivani kajave. roll no 17.div A.Ass 3 setA 3*/
import java.io.*;

 class Vechicle
 {
  String company;
  double price;
 
 Vechicle()
 {
  company="";
  price=0.0;
 }

 Vechicle(String c,double p)
 {
  company=c;
  price=p;
 }

 public void accept() throws Exception
 {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter Company name:");
  company=br.readLine();
 
  System.out.println("Enter price of vechile:");
  price=Double.parseDouble(br.readLine());
 }
 
 public void display()
 {
  System.out.println(company+"\t"+price+"\t");
 }
}//class vechile

 
 class LightMotorV extends Vechicle
 {
  double mileage;
 
 LightMotorV()
 {
  super();
  mileage=0.0;
 }

 LightMotorV(double m,String c,double p)
 {
  super(c,p);
  mileage=m;
 }

 public void accept() throws Exception
 {
  super.accept();
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("\nEnter mileage of a vechicle");
  mileage=Double.parseDouble(br.readLine());
 }

 public void display()
 {
  super.display();
  System.out.println(mileage+"\t");
 }
}

 class HeavyMotorV extends Vechicle
 {
  double capacity_in_tons;
  
 HeavyMotorV()
 {
  super();
  capacity_in_tons=0.0;
 }

 HeavyMotorV(double cit,String c,double p)
 {
  super(c,p);
  capacity_in_tons=cit;
 }
 
 public void accept() throws Exception
 {
  super.accept();
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("\nEnter Capacity(tons) of a Vechicle");
  capacity_in_tons=Double.parseDouble(br.readLine());
 }

 public void display()
 {
  super.display();
  System.out.println(capacity_in_tons+"\t");
 }
}

 class VechicleDemo
 {
  public static void main(String args[]) throws Exception
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   System.out.println("\n1.LightMotor\n2.Heavymotor\nSelect vechicle type");
   int type=Integer.parseInt(br.readLine());
  
   if(type==1)
   {
    LightMotorV lm=new LightMotorV();
    lm.accept();
    
   System.out.println("\nLight motor Vechile details\nCompany Name\nPrice\nMileage\n");
   lm.display();
  }
   
  if(type==2)
  {
   HeavyMotorV hm=new HeavyMotorV();
   hm.accept();
  
  System.out.println("\nHeavy MOtor vechicle deatils\ncompany name\nprice\ncapacity(tons)");
  hm.display();
 }
  System.out.println("\n");
}
}
