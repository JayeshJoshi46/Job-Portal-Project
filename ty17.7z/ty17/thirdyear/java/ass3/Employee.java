/*Shivani kajave. roll no 17.div A.Ass 3 setA 1*/

import java.io.*;

 class Employee
 {
  int id;
  String name,department;
  double salary;
 
 Employee()
 {
  id=0;
  name="";
  department="";
  salary=0.0;
 }

 Employee(int i_d,String nm,String dept,double sal)
 {
  id=i_d;
  name=nm;
  department=dept;
  salary=sal;
 }

 public void accept() throws Exception
 {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("\nEnter the id of employee:");
  id=Integer.parseInt(br.readLine());

  System.out.println("Enter name of the employee:");
  name=br.readLine();
 
  System.out.println("Enter the department:");
  department=br.readLine();
  
  System.out.println("Enter the salary of the employee:");
  salary=Double.parseDouble(br.readLine());
 }

 public void display()
 {
  System.out.println(id+"\t"+name+"\t"+department+"\t"+salary+"\t");
 }
 
 public double getsalary()
 {
  return salary;
 }

}//class Employee


 class Manager extends Employee
 { 
  double bonus;
 
 Manager()
 {
  super();
  bonus=0.0;
 }
 
 Manager(int i_d,String nm,String dept,double sal,double bon)
 {
  super(i_d,nm,dept,sal);
  bonus=bon;
 }
  
 public void accept() throws Exception
 {
  super.accept();
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter the bonus=");
  bonus=Double.parseDouble(br.readLine());
 }

 public double totalsalary()
 {
  double sal=getsalary();
  return (bonus+sal);
 }
 
 public void display()
 {
  System.out.println(bonus+"\t"+totalsalary());
 }
  
 static void maxsalaryemployee(Manager ob[])
 {
  Manager temp=null;
  double maxsal=ob[0].totalsalary();
  for(int i=0;i<ob.length;i++)
  {
   double sal=ob[i].totalsalary();
   if(sal>maxsal)
   temp=ob[i];
  }
  System.out.println("Employee with maximum salary");
  temp.display();
 }


}//Manager
   

  class ManagerDemo
 {
  public static void main(String args[]) throws Exception
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   System.out.println("Enter how many employees=");
   int n=Integer.parseInt(br.readLine());
   Manager obj[]=new Manager[n];
  
  for(int i=0;i<obj.length;i++)
  {
   obj[i]=new Manager();
   obj[i].accept();
  }
 
  for(int i=0;i<obj.length;i++)
  {
   obj[i].display();
  }
  
 Manager.maxsalaryemployee(obj);
 }
}
