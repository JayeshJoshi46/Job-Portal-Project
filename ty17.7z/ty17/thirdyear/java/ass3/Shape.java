/*Shivani kajave. roll no 17.div A.Ass 3 setA 2*/

import java.io.*;

abstract class Shape
{
 abstract double cal_area();
 abstract double cal_volume();
}

class Sphere extends Shape
{
 double radius;

 public Sphere()
 {
  radius=0.0;
 }

 public Sphere(double r) 
 {
  radius=r;
 }

 double cal_area()
 {
  return (4*3.14*radius*radius);
 }

 double cal_volume()
 {
  return ((4/3)*3.14*radius*radius*radius);
 }
}//class shape


class Cone extends Shape
{
 double radius,height;

 public Cone()
 {
  radius=0.0;
  height=0.0;
 }

 public Cone(double r,double h)
 {
  radius=r;
  height=h;
 }

 double cal_area()
 {
  return (3.14*radius*height);
 }

 double cal_volume()
 {
  return ((1/3)*3.14*radius*radius*height);
 }
}//class cone


class Box extends Shape
{
 double length,breadth,height;

 public Box()
 {
  length=0.0;
  breadth=0.0;
  height=0.0;
 }

 public Box(double l,double b,double h)
 {
  length=l;
  breadth=b;
  height=h;
 }

 double cal_area()
 {
  return ((2*(height*breadth))+(2*(height*length))+(2*(breadth*length)));
 }

 double cal_volume()
 {
  return (height*length*breadth);
 }
}//class box


  class Abstract_Demo
 {
  public static void main (String args[]) throws Exception
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  
   System.out.println("\nEnter radius of sphere\t");
   double r=Double.parseDouble(br.readLine());
   Sphere sob=new Sphere(r);
 
   System.out.println("\nEnter radius of cone\t");
   double r1=Double.parseDouble(br.readLine());
   System.out.println("\nEnter height of cone\t");
   double h=Double.parseDouble(br.readLine());
   Cone cob=new Cone(r1,h);
   
   System.out.println("\nEnter length of box\t");
  double l=Double.parseDouble(br.readLine());
   System.out.println("\nEnter breadth of box\t");
  double b=Double.parseDouble(br.readLine());
   System.out.println("\nEnter height of cone\t");
  double h1=Double.parseDouble(br.readLine());
   Box bob=new Box(l,b,h1);
 
   System.out.println("\nArea of Sphere"+sob.cal_area());
   System.out.println("\nVolume of Sphere"+sob.cal_volume());

   System.out.println("\nArea of cone"+cob.cal_area());
   System.out.println("\nVolume of cone"+cob.cal_area());

   System.out.println("\nArea of box"+bob.cal_area());
   System.out.println("\nVolume of box"+bob.cal_area());
  }
 } 



