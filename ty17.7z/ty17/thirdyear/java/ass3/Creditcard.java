/*Shivani Kajve. roll no 17.div A.Ass 3 setB 2*/
import java.io.*;
 
 interface Creditcard
 {
  void viewCreditAmount();
  void usecard(int Amt);
  void payCredit(int Amt);
  void increaseLimit();
 }

 class SilverCardCustomer implements Creditcard
 {
  static BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
  String name;
  long cardNumber;
  int creditAmount=0,creditlimit=50000;

 SilverCardCustomer()
 {
  name="";
  cardNumber=0;
  creditAmount=0;
 }
 
 SilverCardCustomer (String n,long cn,int ca)
 {
  name=n;
  cardNumber=cn;
  creditAmount=ca;
 }

 void accept() throws Exception
 {
  System.out.println("Customer Name:");
  name=br.readLine();
  
  System.out.println("Credit card number:");
  cardNumber=Long.parseLong(br.readLine());
  
  System.out.println("Credit card amount:");
  creditAmount=Integer.parseInt(br.readLine());
  
  System.out.println("Do you want to use usecard:?");
  int n=Integer.parseInt(br.readLine());
  if(n==1)
  {
   System.out.println("Enter amount:");
   int amt=Integer.parseInt(br.readLine());
   usecard(amt);
  }
  System.out.println("Do you want to make credit payment:(1/0)");
  n=Integer.parseInt(br.readLine());
  if(n==1)
  {
   System.out.println("Enter the amount");
   int amt=Integer.parseInt(br.readLine());
   paycredit(amt);
  }
  }

 public void viewCreditAmount()
 {
  System.out.println("The credit number:"+creditAmount+);
 }
 
 public void usecard(int amt)
 {
  if((creditAmount+Amt)>creditlimit)
  System.out.println("Transaction failed\nAmount exceeding credit Limit");
  else
   {
    System.out.println("Transaction successfull")
