/*Shivani kajave. roll no 17.div A.Ass 3 set B 1*/

import java.io.*;
 

 class Staff
 {
  String name,address;
  
  Staff()
  {
   name="";
   address="";
  }
  
 Staff(String n,String a)
 {
  name=n;
  address=a;
 }

 public void accept() throws Exception
 {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter the name=");
  name=br.readLine();
   
  System.out.println("Enter the address=");
  address=br.readLine();
 }
 
 public void display()
 {
  System.out.println(name+"\t"+address+"\t");
 }
}//class staff

 class Fulltimestaff extends Staff
 {
  String department;
  double salary;
 
  Fulltimestaff()
  {
   super();
   department="";
   salary=0.0;
  }
  
 Fulltimestaff(String n,String a,String d,double s)
 {
  super(n,a);
  department=d;
  salary=s;
 }

 public void accept() throws Exception
 {
  super.accept();
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter the department");
  department=br.readLine();
 
  System.out.println("Enter the salary:");
  salary=Double.parseDouble(br.readLine());
 }

 public void display()
 {
  super.display();
  System.out.println(department+"\t"+salary+"\t");
 }
 }//fulltimestaff

 class Parttimestaff extends Staff
 {
  int no_of_hrs;
  double rate_per_hour;
  
  Parttimestaff()
  {
   super();
   no_of_hrs=0;
   rate_per_hour=0.0;
  }

  Parttimestaff(String n,String a,int noh,double rph)
  {
   super(n,a);
   no_of_hrs=noh;
   rate_per_hour=rph;
  }

 public void accept() throws Exception
 {
  super.accept();
  BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
  System.out.println("enter the numner of hours worked");
  no_of_hrs=Integer.parseInt(br.readLine());
  
  System.out.println("enter the rate worked per hour=");
  rate_per_hour=Double.parseDouble(br.readLine());
 }

 public void display()
 {
  super.display();
  System.out.println(no_of_hrs+"\t"+rate_per_hour+"\t");
 }
}//parttimestaff
 

 class StaffDemo
 {
  public static void main(String args[]) throws Exception
  {
   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    System.out.println("\n1.fulltimestaff\n2.Parttimestaff\n");
   int type=Integer.parseInt(br.readLine());
  
     if(type==1)
   {
    System.out.println("enter how many staff members");
    int n=Integer.parseInt(br.readLine());
    Fulltimestaff fm[]=new Fulltimestaff[n];
  
    for(int i=0;i<n;i++)
    {
    fm[i]=new Fulltimestaff();  
    fm[i].accept();
    }
    for(int i=0;i<n;i++)
    {
   System.out.println("\nFull time staff details\nDepartment Name\nSalary\n");
   fm[i].display();
  }
  }   
  if(type==2)
  {
    System.out.println("enter how many staff members");
    int n=Integer.parseInt(br.readLine());
    
    Parttimestaff pm[]=new Parttimestaff[n];
    for(int i=0;i<pm.length;i++)
    {
    pm[i]=new Parttimestaff();
    pm[i].accept();
    }
    for(int i=0;i<pm.length;i++)
    {
  
    System.out.println("\nPart time staff deatils\nnumber_of_hours\nrate_per_hour\n");
    pm[i].display();
    }
 System.out.println("\n");
 }
}
}
