#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<dirent.h>
#include<ctype.h>
#include<stdbool.h>

void list(char *dn,char op)
{
	DIR *dirp;
	struct dirent *entry;
	int dc=0,fc=0;
	dirp=opendir(dn);
	if(dirp==NULL)
	{
		printf("Directory %s not found\n",dn);
		return;
	}
	switch(op)
	{
		case 'F':
		case 'f':
			while(entry=readdir(dirp))
			{
					printf("%s\n",entry->d_name);
			}
			break;
		case 'N':
		case 'n':
			while(entry=readdir(dirp))
                        {
                                if(entry->d_type==DT_REG)
					 fc++;
				if(entry->d_type==DT_DIR)
					dc++;
                        }
			printf("%d File(s)\t %d Dir(s)\n",fc,dc);
                        break;
		case 'I':
		case 'i':
			while(entry=readdir(dirp))
                        {
                                        printf("%s\t%u\n",entry->d_name,entry->d_fileno);
                        }
                        break;
		default:
			printf("Invalid parameter\n");
	}
}

int parse_cmd(char *cmd,char *args[])
{
	char *p,delim[]=" ";
	int i=0,cnt=0;
	p=strtok(cmd,delim);
	while(p!=NULL)
	{
		args[i++]=p;
		p=strtok(NULL,delim);
		cnt++;
	}
	args[i]=NULL;
	return cnt;
}

void typeline(char *fn,char *op)
{
	char ch;
	int fd,n,i,j;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("\nFile %s not found\n",fn);
		return;
	}
	if(strcasecmp(op,"a")==0)
	{
		while(read(fd,&ch,1)>0)
			printf("%c",ch);
		close(fd);
		return;
	}
	n=atoi(op);
	if(n>0)
	{
		i=0;
		while(read(fd,&ch,1)>0)
		{
			printf("%c",ch);
			if(ch=='\n')
				i++;
			if(i==n) 
				break;
		}
	}
	if(n<0)
	{
		i=0;
		while(read(fd,&ch,1)>0)
		{
			if(ch=='\n') 
				 i++;
		}
		lseek(fd,0,SEEK_SET);
			j=0;
		while(read(fd,&ch,1)>0)
		{
			if(ch=='\n') 
				 j++;
			if(j==i+n) 
			break;
		}
		while(read(fd,&ch,1)>0)
		{
			printf("%c",ch);
		}
	}
	close(fd);
}

void search(char *fn,char op,char *pattern)
{
	int fd,count=0,i=0,j=0;
	char ch,line[80],*p;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("File %s not found\n",fn);
                return;

	}
	switch(op)
	{
		case 'F':
		case 'f':
			while(read(fd,&ch,1)>0)
			{
				if(ch=='\n')
				{
					j++;
					line[i]='\0';
					i=0;
					if(strstr(line,pattern)!=NULL)
					{
						printf("%d:%s\n",j,line);
						break;
					}
					if(strstr(line,pattern)==NULL)
					{
						printf("Not found\n");
						break;
					}
				}
				else
					line[i++]=ch;
			}
			break;
		case 'A':
		case 'a':
			while(read(fd,&ch,1)>0)
                        {
				if(ch=='\n')
				{
					j++;
					line[i]='\0';
					i=0;
                                        if(strstr(line,pattern)!=NULL)
                                        {
                                                printf("%d:%s\n",j,line);
                                        }
				}
				else
					line[i++]=ch;
			}
			break;
		case 'C':
		case 'c':
			while(read(fd,&ch,1)>0)
                        {
                                if(ch=='\n')
                                {
                                        j++;
                                        line[i]='\0';
                                        i=0;
					p=line;
                                        while((p=strstr(p,pattern))!=NULL)
                                        {
						count++;
						p++;
                                        }
                                }
                                else
                                        line[i++]=ch;
                        }
			printf("%d\n",count);
                        break;
		default:
			printf("Invalid parameter\n");
	}
	close(fd);
}

void count(char *fn,char op)
{
	int cc=0,wc=0,lc=0,fd;
	char ch;
	bool inword=false;
	fd=open(fn,O_RDONLY);
	if(fd==-1)
	{
		printf("File %s not found\n",fn);
                return;

	}
	while(read(fd,&ch,1)>0)
	{
		cc++;
		if(ch=='\n')
			lc++;
		if(!isspace(ch)&&!inword)
		{
			inword=true;
			 wc++;
		}
		if(isspace(ch)&&inword)
			inword=false;
	}
	close(fd);

	switch(op)
	{
		case 'C':
		case 'c':
			printf("%d\t%s\n",cc,fn);
			break;		
		case 'W':
		case 'w':
                        printf("%d\t%s\n",wc,fn);
                        break;
		case 'L':
		case 'l':
                        printf("%d\t%s\n",lc,fn);
                        break;
		default:
			printf("Invalid parameter");

	}
}

void main()
{
	int pid,check;
	char command[80],*args[20];
	while(1)
	{
		printf("myshell$");
		fflush(stdin);
		fgets(command,80,stdin);
		command[strlen(command)-1]='\0';
		check=parse_cmd(command,args);
		if(strcasecmp(args[0],"list")==0)
		{
			if(check==3)
				list(args[2],args[1][0]);
			else
				printf("\nInvalid command for list\n");
		}
		else if(strcasecmp(args[0],"count")==0)
                {
			if(check==3)			
	                        count(args[2],args[1][0]);
			else
				printf("\nInvalid command for count\n");
                }
		else if(strcasecmp(args[0],"typeline")==0)
                {
			if(check==3)			
				typeline(args[2],args[1]);
			else
				printf("\nInvalid command for typeline\n");
                }

		else if(strcasecmp(args[0],"search")==0)
                {
			if(check==4)			
	                        search(args[2],args[1][0],args[3]);
			else
				printf("\nInvalid command for search\n");
                }
		else if(strcasecmp(args[0],"exit")==0)
			exit(0);
		else
		{
			pid=fork();
			if(pid>0)
			{
				wait();
			}
			else
				if(execvp(args[0],args)==-1)
				{
					printf("\nInvalid Command\n");
					exit(0);
				}
		}

	}
}
