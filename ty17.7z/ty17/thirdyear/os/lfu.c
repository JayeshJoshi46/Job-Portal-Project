/*Shivani kajave
 LFU
*/

#include<stdio.h>
#include<stdlib.h>

struct node
{
	int pno;
	struct node *next;
}*first,*last;


#define newnode (struct node *)malloc(sizeof(struct node));

int n,m,*frames,mem[10][20],sp,faults,count[10];

void accept()
{
        int i=0,k=0;
	struct node *p,*q;
	printf("\nEnter the references(Enter -1 to stop): ");

		while(1)
		{
			k=0;
			printf("ref[%d]=",i++);
			
			p=(struct node *)malloc(sizeof(struct node));
			scanf("%d",&p->pno);
			
			do{
				if(p->pno<0 && p->pno!=-1)
				  {
					printf("\nInvalid reference page..Please enter again\n");
					scanf("%d",&p->pno);
				  }				
			}while(p->pno<0 && p->pno!=-1);	

		
		p->next=NULL;
		if(first==NULL)
			first=p;
		else
			last->next=p;

		last=p;
		if(p->pno==-1) 
			break;
		m++;
		}

	p=first;
	if(first->pno==-1)
	{
		printf("\nReference String is not accepted");
		exit(0);
	}
	while(p->next!=NULL)
	{
		q=p;
		p=p->next;
	}
	q->next=p->next;
	free(p);
	do{
        	printf("\nEnter the number of frames");
        	scanf("%d",&n);
		if(n<=0)
			printf("\nInvalid number of frames");
	}while(n<=0);

	frames  = (int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
		frames[i] = -2;
}

int search(int pno)
{
        int i;
        for(i=0;i<n;i++)
                if(frames[i] == pno)
                        return i;
        return -1;
}


int get_lfu(int s)
{
	int i,min=999,min_pos;
	i=s;
	do
	{
		if(count[i]<min)
		{
			min = count[i];
			min_pos = i;
		}
		i=(i+1)%n;
	}while(i!=s);
	return min_pos;
}


void lfu()
{
	struct node *p;
	int i=0,j=0,k;
	p=first;
	for(i=0;i<10;i++)
	{
		for(j=0;j<20;j++)
			mem[i][j] = -5;
	}
        i=0,j=0;
	while(p!=NULL && sp < n)
	{
		k=search(p->pno);
		if(k == -1)
		{
			frames[sp] = p->pno;
			count[sp] = 1;
			faults++;
			sp++;
			for(j=0 ;j<n ;j++)
				mem[j][i] = frames[j];
		}
		else
			count[k]++;
		i++;
		p=p->next;
	}
	sp=0;
	while(p!=NULL)
        {
                k=search(p->pno);
                if(k == -1)
                {
			sp=get_lfu(sp);
                        frames[sp] = p->pno;
                        count[sp] = 1;
                        faults++;
                        sp=(sp+1)%n;
                        for(j=0 ;j<n ;j++)
                                mem[j][i] = frames[j];
                }
                else
                        count[k]++;
                i++;
                p=p->next;
        }
	for(p=first;p!=NULL;p=p->next)
		printf("%4d",p->pno);
	printf("\n\n");

	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			if(mem[i][j] >= 0)
				printf("%4d",mem[i][j]);
			else printf("    ");
		}
		printf("\n");
	}
	printf("\nTotal number of page faults = %d\n",faults);
}

main()
{
	accept();
	lfu();
}


