/*Linked allocation*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define Entry (struct info *)malloc(sizeof(struct info))

 struct info
{
  char fname[20];
	int n[20];
  int start, end,length;
  struct info *next;
};

struct info *E=NULL,*lastEntry=NULL;

int *D=NULL;
int used=0,dsize,fat[100],bno;

void init_disk()
{
	int i;
	D=(int *)malloc(dsize*sizeof(int));
	for(i=0;i<dsize;i++)
		D[i]=-2;
}

int search()
{
	int i;
	for(i=0;i<dsize;i++)
	{

		if(D[i]==-2)
		{
			return i;

		}
	}
	return -1;
}

void allocate()
{
	char fname[10];
	int length,blocknum,i,cnt=0,k,j;
	struct info *t,*s;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==0)
			cnt++;
	}

	if(cnt==dsize)
	{
		printf("\nBlock is Full\n");
		return;
	}
	do{
	printf("\nEnter the filename=");
	scanf("%s",fname);
	k=0;
	for(s=E;s!=NULL;s=s->next)
		{
			if(strcmp(s->fname,fname)==0)
			{
				printf("\nFile already exists\n");
				k++;
			}
		}
	}while(k!=0);
	do{
		printf("\nEnter the file size=");
		scanf("%d",&length);
		if(length<=0)
		{
			printf("Invalid file size!!\n");
		}
	}while(length<=0);
	if(length>dsize-used)
		printf("\nFile cannot be created.\n");
	else
	{
		printf("\nBlock is allocated");
		used+=length;
		t=Entry;
		blocknum=search();
		strcpy(t->fname,fname);
		t->start=blocknum;
		t->length=length;
		t->next=NULL;
		D[blocknum]=-1;
		j=0;
		t->n[j]=blocknum;
		j++;
		for(i=2;i<=length;i++)
		{
			D[blocknum]=search();
			blocknum=D[blocknum];
			D[blocknum]=-1;
			t->n[j++]=blocknum;
		}
		t->n[j]=-1;
		t->end=blocknum;
		if(E==NULL)
			E=lastEntry=t;
		else
		{
			lastEntry->next=t;
			lastEntry=lastEntry->next;
		}
		
	}
}

void deallocate()
{
	struct info *f,*s;
	char fname[30];
	int start,end,length,i,blocknum,flag=0,tempBlock;
	if(E==NULL)
	{
		printf("\nThe directory is empty");
		return;
	}	
	printf("\nEnter the filename to delete=");
	scanf("%s",fname);
	for(s=E;s!=NULL;s=s->next)
	{
		if(strcmp(s->fname,fname)==0)
		{
			flag=1;
			start=s->start;
			end=s->end;
			length=s->length;
			for(blocknum=start,i=1;i<=length;i++)
			{
				tempBlock=D[blocknum];
				D[blocknum]=-2;
				blocknum=tempBlock;
			}
			if(s==E)
			{
				E=E->next;
				free(s);
				used=used-length;
				break;
			}
			else if(s==lastEntry)
			{

				for(f=E;f->next!=lastEntry;f=f->next);
				{
					f->next=NULL;
					lastEntry=f;
					free(s);
					used=used-length;
				break;
				}
			}
			else
			{
				for(f=E;f->next!=s;f=f->next)
				{}
				f->next=s->next;
				free(s);
				used=used-length; break;
			}
			printf("\nFile Deleted successfully\n");
		}
	}
	if(flag==0)
		printf("\nFile does not exist");	
}

void display_entry()
{
	int i;
	struct info *t;
	if(E==NULL)
	{
		printf("\nNo contents");
		return;
	}
	printf ("\nName\tStart\tEnd\tBlocks\n");
	for(t=E;t!=NULL;t=t->next)
	{
		printf ("\n%s\t%d\t%d", t->fname, t->start, t->end);
		for(i=0;t->n[i]!=-1;i++)
			printf("\t%d->",t->n[i]);
		printf("NULL");
	}
	
	printf("\nUsed Block: %d",used);
	printf("\nFree Block: %d",dsize-used);
}

int main()
{
	struct info *s;
	int ch,k,i;
	for (i = 0; i < dsize; i++)
    		fat[i] = -999;
		do{
		k=0;
	  	printf ("\nEnter total block size:");
	  	scanf ("%d", &dsize);
		if(dsize<=0)
		{
			printf("\nInvalid block size..please enter again");
			k++;
		}
	  	}while(k!=0);
		init_disk();
		while(1)
		{
			      printf("Enter your choice=\n");
			      printf ("\n1.Create\n2.Delete.\n3.Display Free/Dir List\n4.Contents\n5.Exit.\n");
			      scanf ("%d", &ch);
			switch(ch)
			{
			case 1:
				if(used==dsize)
					printf("\nDisk full");
				else
					allocate();
				break;
			case 2:
				deallocate();
				break;
			case 3:
				display_entry();
				break;
			case 4:
			
			  	if(E==NULL)
			  	{
					printf("Directory is empty");
			  	}
			  	else
			  	{
					printf("\nThe contents of the directory are:");
			  		for(s=E;s!=NULL;s=s->next)
						printf("\n%s",s->fname);
			  	}
			   	break;
			case 5:
				exit(0);
			}
		}
	
}
