/*Shivani kajave
   Roll no 17.
   Div A
   Contiguous File Allocation */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define ENTRY (struct info *)malloc(sizeof(struct info))

struct info 
{
	char fname[10];
	int start,length;
	struct info *next;
};
struct info *E=NULL,*lastEntry=NULL;
int *D=NULL;
int used=0;

int dsize;  //disk size

void init_disk()
{
	int i;
	D=(int *)malloc(sizeof(int)*dsize);
	for(i=0;i<dsize;i++)
        D[i]=1;
}

int search(int length)
{
	int i,j,flag=1,blknum;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==1)
		{
			flag=1;
			for(blknum=i,j=0;j<length;j++)
			{
				if(D[blknum++]==1)
					continue;
				else  
				{
					flag=0;
					break;
				}
		}
		if(flag==1)
			return i;
		}
	}
 	return -1;
}

void allocate()
{
	char fname[10];
	int length,blknum,i,k,cnt=0;
	struct info *t,*s;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==0)
		cnt++;
	}
	if(cnt==dsize)
	{
		printf("Disk Full!");
		return;
	}
	        
	do
	{ 
		k=0;
		printf("\nEnter the file name=");
		scanf("%s",fname);
		for(s=E;s!=NULL;s=s->next)
		{
			if(strcmp(s->fname,fname)==0)
			{
				printf("\nFilename already exists");
				k++;
			}
		}
	}while(k!=0);
       
        do
	{
		printf("Enter the length of the file=");
		scanf("%d",&length);
		if(length<=0)
		{
			printf("Invalid length");
		}
	}while(length<=0);
       
	if(length<=dsize-used)
		blknum=search(length);

	else
		blknum=-1;
	
	if(blknum==-1)
		printf("\nError: No disk space available...");
	else
	{
		printf("\nBlock is allocated");
		used=used+length;
		t=ENTRY;
		strcpy(t->fname,fname);
		t->start=blknum;
		t->length=length;
		t->next=NULL;
		if(E==NULL)
			E=lastEntry=t;
		else
		{
			lastEntry->next=t;
			lastEntry=lastEntry->next;
		}

		/*Updating disk*/

		for(i=1;i<=length;i++)
			D[blknum++]=0;
			printf("\nBLock Status after allocation=");
			for(i=0;i<dsize;i++)
				printf("%d",D[i]);
			
	}

}

void deallocate()
{
	struct info *f,*s;
	char fname[10];
	int start,length,i,blknum,flag=0;
	if(E==NULL)
	{
		printf("No file in Directory!");
		return;
	}
	printf("\nEnter file name to delete=");
	scanf("%s",fname);
	

	for(s=E;s!=NULL;s=s->next)
	{
		if(strcmp(s->fname,fname)==0)
		{
			flag=1;
			start=s->start;
			length=s->length;
			for(blknum=start,i=0;i<length;i++)
				D[blknum++]=1;
			printf("\nBlock status after De-allocation=");
			for(i=0;i<dsize;i++)
				printf("%d",D[i]);
				if(s==E)
				{
					E=E->next;
					free(s);
					used=used-length;
					break;
				}
				for(f=E;f->next!=s;f=f->next)
				{
				}
				f->next=s->next;
				free(s);
				used=used-length;
				break;
		}
	}
	if(flag==0)
		printf("\nFile does not exist");
}

void display_entry()
{
	struct info *t;
        if(E==NULL)
	{
		printf("No File in Directory!");
		return;
	}

	printf("\nFname\tStart\tSize\n");
	for(t=E;t!=NULL;t=t->next)
	{
		printf("\n%s\t%d\t%d",t->fname,t->start,t->length);	
	}
	printf("\nUsed block =%d",used);
	printf("\nFRee block =%d",dsize-used);
}

int main()
{
	int choice,i,k=0;
	do
	{	k=0;
		printf("\nWhat is disk size=");
		scanf("%d",&dsize);
		if(dsize<=0)
               {	
  		printf("Inavlid size");
		k++;
		}
	}while(k!=0);


	init_disk();
	while(1)
	{
		printf("\nMenu\n1:Show Bit Vector\n2:Create New File\n3:Show Directory\n4:Delete file\n5:Exit\n");
		printf("\nEnter your choice:\n");
		scanf("%d",&choice);
		switch(choice)
		{	case 1:for(i=0;i<dsize;i++)
				printf("%d",D[i]);
				break;
			case 2: 
				allocate();
				break;
			case 4:
				deallocate(); break;
			case 3:
				display_entry(); break;
			case 5:
				exit(0);
		}
 	}
}
