/*Shivani kajave
  MRU
*/

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int pno;
	struct node *link;
}NODE;

NODE *first,*last;

int n,m,*frames,mem[10][20],sp,faults,time[10];

void accept_info()
{
		int i=0,k=0;
	NODE *p,*q;
	printf("\nEnter the references(Enter -1 to stop): ");

	while(1)
		{
			k=0;
			printf("ref[%d]=",i++);
			
			p=(struct node *)malloc(sizeof(struct node));
			
			do{
				scanf("%d",&p->pno);
				if(p->pno<0 && p->pno!=-1)
				  {
					printf("\nInvalid reference page..Please enter again\n");
					
				  }				
			}while(p->pno<0 && p->pno!=-1);	


		
			p->link=NULL;
			if(first==NULL)
				first=p;
			else
				last->link=p;

			last=p;
			if(p->pno==-1) 
				break;
			m++;
		}

	p=first;
	if(first->pno==-1)
	{
		printf("\nReference String is not accepted");
		exit(0);
	}
	while(p->link!=NULL)
	{
		q=p;
		p=p->link;
	}
	q->link=p->link;
	free(p);
	do{	
		k=0;
		printf("\nEnter the number of frames:");
		scanf("%d",&n);
		if(n<=0)
		{
			k++;
			printf("\nInvalid number of frames");
		}
	}while(k!=0);
	frames  = (int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++)
		frames[i] = -2;
}

int search(int pno)
{
	int i;
	for(i=0;i<n;i++)
		if(frames[i]==pno)
			return i;

	return -1;
}

int get_mru()
{
	int i,max=-999,max_pos;
	for(i=0;i<n;i++)
	{
		if(time[i]>max)
		{
			max=time[i];
			max_pos=i;
		}
	}
	return max_pos;
}
	
void mru()
{
	int i=0,j=0,k;
	NODE *p;
	p=first;
	for(i=0;i<10;i++)
	{
		for(j=0;j<20;j++)
			mem[i][j] = -5;
	}
        i=0,j=0;
	while(p!=NULL&&sp<n)
	{
		k=search(p->pno);
		if(k==-1)
		{
			frames[sp]=p->pno;
			time[sp]=i;
			sp++;
			faults++;
			for(j=0;j<n;j++)
				mem[j][i]=frames[j];
		}
		else
			time[k]=i;
		i++;
		p=p->link;
	}
	while(p!=NULL)
	{
		k=search(p->pno);
                if(k==-1)
                {
                        sp=get_mru();
                        frames[sp]=p->pno;
                        faults++;
			time[sp]=i;
                        for(j=0;j<n;j++)
                                mem[j][i]=frames[j];
                }
                else
                        time[k]=i;
                i++;
                p=p->link;

	}
	for(p=first;p!=NULL;p=p->link)
		printf("%4d",p->pno);
	printf("\n\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			if(mem[i][j]>=0)
				printf("%4d",mem[i][j]);
			else
				printf("    ");
		}
		printf("\n");
	}
	printf("\nTotal page Faults: %d\n",faults);
}

void main()
{
	system("clear");
	accept_info();
	mru();
}

